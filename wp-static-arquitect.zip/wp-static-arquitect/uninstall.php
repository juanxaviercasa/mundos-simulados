<?php
/**
 * Lógica de desinstalación de WP Static Architect.
 * Se ejecuta únicamente cuando el usuario elimina el plugin desde el panel de administración.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Opciones del plugin a eliminar
$options_to_delete = array(
	'wp_static_arquitect_netlify_pat',
	'wp_static_arquitect_netlify_site_id',
	'wp_static_arquitect_netlify_threshold_count',
	'wp_static_arquitect_netlify_threshold_mb',
	'wp_static_arquitect_supabase_url',
	'wp_static_arquitect_supabase_anon_key',
	'wp_static_arquitect_supabase_service_key',
	'wp_static_arquitect_supabase_auto_approve',
	'wp_static_arquitect_url_mode',
	'wp_static_arquitect_recent_logs',
	'wp_static_arquitect_last_export_info',
	'wp_static_arquitect_last_purge_info',
	'wp_static_arquitect_deploy_on_save',
	'wp_static_arquitect_netlify_build_hook',
	'wp_static_arquitect_scheduled_deploy_enabled',
	'wp_static_arquitect_scheduled_deploy_time',
	'wp_static_arquitect_scheduled_deploy_smart_check',
);

foreach ( $options_to_delete as $option ) {
	delete_option( $option );
}

// Limpieza de crons si persistiesen
$weekly_purge_ts = wp_next_scheduled( 'wp_static_arquitect_weekly_purge_cron' );
if ( $weekly_purge_ts ) {
	wp_unschedule_event( $weekly_purge_ts, 'wp_static_arquitect_weekly_purge_cron' );
}

$daily_deploy_ts = wp_next_scheduled( 'wp_static_arquitect_daily_scheduled_deploy_cron' );
if ( $daily_deploy_ts ) {
	wp_unschedule_event( $daily_deploy_ts, 'wp_static_arquitect_daily_scheduled_deploy_cron' );
}

// Función recursiva para eliminar directorio temporal
function wp_static_arquitect_rmdir_recursive( $dir ) {
	if ( ! is_dir( $dir ) ) {
		return;
	}
	$files = array_diff( scandir( $dir ), array( '.', '..' ) );
	foreach ( $files as $file ) {
		$target = $dir . DIRECTORY_SEPARATOR . $file;
		( is_dir( $target ) ) ? wp_static_arquitect_rmdir_recursive( $target ) : @unlink( $target );
	}
	@rmdir( $dir );
}

// Limpiar carpeta de uploads del plugin
$upload_dir = wp_upload_dir();
$plugin_dir = trailingslashit( $upload_dir['basedir'] ) . 'wp-static-arquitect';
if ( file_exists( $plugin_dir ) ) {
	wp_static_arquitect_rmdir_recursive( $plugin_dir );
}
