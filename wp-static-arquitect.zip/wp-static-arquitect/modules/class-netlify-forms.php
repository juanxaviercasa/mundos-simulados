<?php
/**
 * Integración con Netlify: inyección de formularios estáticos y gestión de purga de la API.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Netlify_Forms {

	/**
	 * Endpoint base de la API de Netlify.
	 */
	const NETLIFY_API_BASE = 'https://api.netlify.com/api/v1/';

	/**
	 * Transforma las etiquetas <form> del documento para habilitar Netlify Forms o Inboxes Serverless (Web3Forms / FormSubmit).
	 *
	 * @param DOMXPath    $xpath
	 * @param DOMDocument $dom
	 * @param string      $post_slug
	 */
	public function transform_forms( $xpath, $dom, $post_slug ) {
		if ( '0' === get_option( 'wp_static_arquitect_enable_forms', '1' ) ) {
			return;
		}

		$forms = $xpath->query( '//form' );
		if ( ! $forms ) {
			return;
		}

		$hosting_provider  = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );
		$form_provider     = get_option( 'wp_static_arquitect_form_provider', 'auto' );
		$google_sheets_url = trim( (string) get_option( 'wp_static_arquitect_google_sheets_url', '' ) );
		$web3forms_key     = trim( (string) get_option( 'wp_static_arquitect_web3forms_key', '' ) );
		$formsubmit_email  = trim( (string) get_option( 'wp_static_arquitect_formsubmit_email', get_option( 'admin_email' ) ) );

		// Determinar si usamos Google Sheets, Netlify o un Inbox Serverless (Web3Forms/FormSubmit)
		$use_google_sheets  = ( 'google_sheets' === $form_provider ) || ( ! empty( $google_sheets_url ) && 'auto' === $form_provider && 'netlify' !== $hosting_provider );
		$use_external_inbox = false;
		if ( ! $use_google_sheets ) {
			if ( 'web3forms' === $form_provider || 'formsubmit' === $form_provider ) {
				$use_external_inbox = true;
			} elseif ( 'auto' === $form_provider && 'netlify' !== $hosting_provider ) {
				$use_external_inbox = true;
			}
		}

		$form_index = 0;
		foreach ( $forms as $form ) {
			// Ignorar formularios de búsqueda estándar
			$class_attr = $form->getAttribute( 'class' );
			$role_attr  = $form->getAttribute( 'role' );
			if ( 'search' === $role_attr || strpos( $class_attr, 'search-form' ) !== false ) {
				continue;
			}

			$form_index++;

			// Asignar método POST
			$form->setAttribute( 'method', 'POST' );

			// Determinar nombre del formulario
			$form_name = $form->getAttribute( 'name' );
			if ( empty( $form_name ) ) {
				$form_name = ! empty( $form->getAttribute( 'id' ) )
					? $form->getAttribute( 'id' )
					: 'form-' . $post_slug . '-' . $form_index;
				$form->setAttribute( 'name', $form_name );
			}

			if ( $use_google_sheets ) {
				// MODALIDAD GOOGLE SHEETS / EXCEL CSV
				$form->setAttribute( 'action', ! empty( $google_sheets_url ) ? esc_url( $google_sheets_url ) : '#' );

				$name_input = $dom->createElement( 'input' );
				$name_input->setAttribute( 'type', 'hidden' );
				$name_input->setAttribute( 'name', '_form_name' );
				$name_input->setAttribute( 'value', $form_name );
				$form->insertBefore( $name_input, $form->firstChild );

				$url_input = $dom->createElement( 'input' );
				$url_input->setAttribute( 'type', 'hidden' );
				$url_input->setAttribute( 'name', '_source_url' );
				$url_input->setAttribute( 'value', esc_url( home_url( '/' . $post_slug ) ) );
				$form->insertBefore( $url_input, $name_input->nextSibling );
			} elseif ( $use_external_inbox ) {
				// MODALIDAD SERVERLESS INBOX (Cloudflare Pages, GitHub Pages, Render)
				if ( ! empty( $web3forms_key ) || 'web3forms' === $form_provider ) {
					// Web3Forms API (Inbox gratuito para Cloudflare / GitHub / Render)
					$form->setAttribute( 'action', 'https://api.web3forms.com/submit' );

					$key_input = $dom->createElement( 'input' );
					$key_input->setAttribute( 'type', 'hidden' );
					$key_input->setAttribute( 'name', 'access_key' );
					$key_input->setAttribute( 'value', $web3forms_key ? $web3forms_key : 'YOUR_ACCESS_KEY_HERE' );
					$form->insertBefore( $key_input, $form->firstChild );

					$subj_input = $dom->createElement( 'input' );
					$subj_input->setAttribute( 'type', 'hidden' );
					$subj_input->setAttribute( 'name', 'subject' );
					$subj_input->setAttribute( 'value', 'Nuevo mensaje de contacto desde el sitio web' );
					$form->insertBefore( $subj_input, $key_input->nextSibling );

					$bot_input = $dom->createElement( 'input' );
					$bot_input->setAttribute( 'type', 'checkbox' );
					$bot_input->setAttribute( 'name', 'botcheck' );
					$bot_input->setAttribute( 'style', 'display: none;' );
					$form->appendChild( $bot_input );
				} else {
					// FormSubmit Endpoint (100% gratuito sin registro, directo al correo del admin)
					$form->setAttribute( 'action', 'https://formsubmit.co/' . sanitize_email( $formsubmit_email ) );

					$subj_input = $dom->createElement( 'input' );
					$subj_input->setAttribute( 'type', 'hidden' );
					$subj_input->setAttribute( 'name', '_subject' );
					$subj_input->setAttribute( 'value', 'Nuevo mensaje de contacto [' . esc_attr( $form_name ) . ']' );
					$form->insertBefore( $subj_input, $form->firstChild );

					$cap_input = $dom->createElement( 'input' );
					$cap_input->setAttribute( 'type', 'hidden' );
					$cap_input->setAttribute( 'name', '_captcha' );
					$cap_input->setAttribute( 'value', 'false' );
					$form->insertBefore( $cap_input, $subj_input->nextSibling );
				}
			} else {
				// MODALIDAD NETLIFY FORMS NATIVO
				$form->removeAttribute( 'action' );
				$form->setAttribute( 'data-netlify', 'true' );
				$form->setAttribute( 'data-netlify-honeypot', 'bot-field' );

				$hidden_input = $dom->createElement( 'input' );
				$hidden_input->setAttribute( 'type', 'hidden' );
				$hidden_input->setAttribute( 'name', 'form-name' );
				$hidden_input->setAttribute( 'value', $form_name );

				if ( $form->firstChild ) {
					$form->insertBefore( $hidden_input, $form->firstChild );
				} else {
					$form->appendChild( $hidden_input );
				}

				$bot_container = $dom->createElement( 'p' );
				$bot_container->setAttribute( 'style', 'display: none;' );

				$bot_label = $dom->createElement( 'label' );
				$bot_label->nodeValue = 'No rellenes este campo si eres humano: ';

				$bot_input = $dom->createElement( 'input' );
				$bot_input->setAttribute( 'name', 'bot-field' );

				$bot_label->appendChild( $bot_input );
				$bot_container->appendChild( $bot_label );
				$form->insertBefore( $bot_container, $hidden_input->nextSibling );
			}

			// Eliminar campos dinámicos y tokens no utilizables de WP (_wpnonce, etc.)
			$nonce_inputs = $xpath->query( ".//input[@name='_wpnonce'] | .//input[@name='_wp_http_referer']", $form );
			if ( $nonce_inputs ) {
				foreach ( $nonce_inputs as $nonce_input ) {
					$nonce_input->parentNode->removeChild( $nonce_input );
				}
			}
		}
	}

	/**
	 * Obtiene las credenciales de Netlify almacenadas en opciones.
	 *
	 * @return array
	 */
	public function get_credentials() {
		return array(
			'pat'             => get_option( 'wp_static_arquitect_netlify_pat', '' ),
			'site_id'         => get_option( 'wp_static_arquitect_netlify_site_id', '' ),
			'threshold_count' => (int) get_option( 'wp_static_arquitect_netlify_threshold_count', 80 ),
			'threshold_mb'    => (int) get_option( 'wp_static_arquitect_netlify_threshold_mb', 8 ),
		);
	}

	/**
	 * Consulta estadísticas actuales de envíos en Netlify.
	 *
	 * @return array
	 */
	public function get_submissions_stats() {
		$creds = $this->get_credentials();
		if ( empty( $creds['pat'] ) || empty( $creds['site_id'] ) ) {
			return array(
				'success' => false,
				'message' => 'Credenciales de Netlify no configuradas.',
			);
		}

		$url      = self::NETLIFY_API_BASE . 'sites/' . rawurlencode( $creds['site_id'] ) . '/submissions';
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $creds['pat'],
					'User-Agent'    => 'WP-Static-Architect/1.0',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$status = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status ) {
			return array(
				'success' => false,
				'message' => sprintf( 'Error de Netlify API (HTTP %d). Revisa el Site ID y el Token.', $status ),
			);
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) ) {
			return array(
				'success' => false,
				'message' => 'Respuesta inesperada de la API de Netlify.',
			);
		}

		$total_count = count( $body );
		$total_bytes = 0;

		foreach ( $body as $submission ) {
			// Calcular adjuntos si están presentes
			if ( ! empty( $submission['data']['attachments'] ) && is_array( $submission['data']['attachments'] ) ) {
				foreach ( $submission['data']['attachments'] as $att ) {
					if ( isset( $att['size'] ) ) {
						$total_bytes += (int) $att['size'];
					}
				}
			}
		}

		$total_mb = round( $total_bytes / ( 1024 * 1024 ), 2 );

		return array(
			'success'     => true,
			'total_count' => $total_count,
			'total_mb'    => $total_mb,
			'total_bytes' => $total_bytes,
			'submissions' => $body,
		);
	}

	/**
	 * Ejecuta la lógica de retención y purga automática de envíos en Netlify.
	 *
	 * @param bool $force_purge Si es true, purga envíos antiguos aunque no alcance el umbral.
	 * @return array
	 */
	public function purge_submissions( $force_purge = false ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['pat'] ) || empty( $creds['site_id'] ) ) {
			WP_Static_Arquitect::log( 'Purga de Netlify cancelada: credenciales no configuradas.', 'warning' );
			return array(
				'success' => false,
				'message' => 'Credenciales de Netlify incompletas.',
			);
		}

		WP_Static_Arquitect::log( 'Consultando estado de envíos en Netlify...', 'info' );
		$stats = $this->get_submissions_stats();

		if ( ! $stats['success'] ) {
			WP_Static_Arquitect::log( 'Error al consultar envíos de Netlify: ' . $stats['message'], 'error' );
			return $stats;
		}

		$count           = $stats['total_count'];
		$mb              = $stats['total_mb'];
		$threshold_count = $creds['threshold_count'];
		$threshold_mb    = $creds['threshold_mb'];

		WP_Static_Arquitect::log(
			sprintf(
				'Estado Netlify: %d envíos (umbral: %d) | %.2f MB de adjuntos (umbral: %d MB)',
				$count,
				$threshold_count,
				$mb,
				$threshold_mb
			),
			'info'
		);

		// Comprobar si se encuentra en Modo Creador Pro o Modo Empresa / Plan Pago
		$service_tier = get_option( 'wp_static_arquitect_service_tier', 'creator_pro' );
		if ( in_array( $service_tier, array( 'creator_pro', 'enterprise' ), true ) && ! $force_purge ) {
			$msg = 'Modo Creador Pro / Ilimitado activo: La purga preventiva automática está deshabilitada para conservar el historial completo de envíos y archivos adjuntos.';
			WP_Static_Arquitect::log( $msg, 'info' );
			return array(
				'success'      => true,
				'purged_count' => 0,
				'message'      => $msg,
			);
		}

		// Comprobar si se sobrepasa alguno de los umbrales
		$needs_purge = $force_purge || ( $count >= $threshold_count ) || ( $mb >= $threshold_mb );

		if ( ! $needs_purge ) {
			$msg = 'El uso de formularios se encuentra dentro de los límites seguros. No se requiere purga.';
			WP_Static_Arquitect::log( $msg, 'info' );
			return array(
				'success'      => true,
				'purged_count' => 0,
				'message'      => $msg,
			);
		}

		$submissions = $stats['submissions'];

		// Ordenar submissions por fecha de creación (los más antiguos primero)
		usort(
			$submissions,
			function( $a, $b ) {
				$time_a = strtotime( isset( $a['created_at'] ) ? $a['created_at'] : 0 );
				$time_b = strtotime( isset( $b['created_at'] ) ? $b['created_at'] : 0 );
				return $time_a - $time_b;
			}
		);

		// Determinar cuántos elementos eliminar para quedar en un margen seguro (50% del umbral)
		$target_reduction = max( 1, (int) ceil( $threshold_count * 0.4 ) );
		if ( $force_purge && empty( $target_reduction ) ) {
			$target_reduction = min( 10, $count );
		}

		$to_delete = array_slice( $submissions, 0, $target_reduction );
		$purged    = 0;
		$errors    = 0;

		foreach ( $to_delete as $sub ) {
			if ( empty( $sub['id'] ) ) {
				continue;
			}

			$sub_id   = $sub['id'];
			$del_url  = self::NETLIFY_API_BASE . 'submissions/' . rawurlencode( $sub_id );
			$response = wp_remote_request(
				$del_url,
				array(
					'method'  => 'DELETE',
					'timeout' => 15,
					'headers' => array(
						'Authorization' => 'Bearer ' . $creds['pat'],
					),
				)
			);

			$code = wp_remote_retrieve_response_code( $response );
			if ( 200 === $code || 204 === $code ) {
				$purged++;
				WP_Static_Arquitect::log( sprintf( 'Envío purgado con éxito: ID %s', $sub_id ), 'info' );
			} else {
				$errors++;
				WP_Static_Arquitect::log( sprintf( 'Fallo al purgar envío ID %s (HTTP %d)', $sub_id, $code ), 'warning' );
			}
		}

		$purge_summary = array(
			'purged_count' => $purged,
			'error_count'  => $errors,
			'purged_at'    => current_time( 'Y-m-d H:i:s' ),
			'triggered_by' => $force_purge ? 'manual' : 'cron',
		);

		update_option( 'wp_static_arquitect_last_purge_info', $purge_summary, false );

		$res_msg = sprintf( 'Purga completada: %d envíos eliminados (%d errores).', $purged, $errors );
		WP_Static_Arquitect::log( $res_msg, 'success' );

		return array(
			'success'      => true,
			'purged_count' => $purged,
			'error_count'  => $errors,
			'message'      => $res_msg,
		);
	}

	/**
	 * Callback para ejecución programada por el cron de WordPress.
	 */
	public function execute_cron_purge() {
		WP_Static_Arquitect::log( 'Disparador cron activado: iniciando verificación de purga semanal...', 'info' );
		$this->purge_submissions( false );
	}

	/**
	 * Despliega un archivo .zip directamente a Netlify mediante la Deploy API v1.
	 *
	 * @param string $zip_path Ruta absoluta al archivo ZIP generado.
	 * @return array
	 */
	public function deploy_zip( $zip_path ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['pat'] ) || empty( $creds['site_id'] ) ) {
			return array(
				'success' => false,
				'message' => 'Credenciales de Netlify (PAT o Site ID) no configuradas.',
			);
		}

		if ( ! file_exists( $zip_path ) || ! is_readable( $zip_path ) ) {
			return array(
				'success' => false,
				'message' => 'El archivo ZIP a desplegar no existe o no es legible en el servidor.',
			);
		}

		WP_Static_Arquitect::log( sprintf( 'Iniciando despliegue directo a Netlify: %s (%s)...', basename( $zip_path ), size_format( filesize( $zip_path ), 2 ) ), 'info' );

		$url = self::NETLIFY_API_BASE . 'sites/' . rawurlencode( $creds['site_id'] ) . '/deploys';

		// Leer contenido binario del archivo ZIP
		$zip_data = @file_get_contents( $zip_path );
		if ( false === $zip_data ) {
			return array(
				'success' => false,
				'message' => 'No se pudo leer el contenido binario del archivo ZIP.',
			);
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout'    => 180, // Tiempo suficiente para subir archivos medianos/grandes
				'sslverify'  => false,
				'user-agent' => 'WP-Static-Architect/1.0',
				'headers'    => array(
					'Authorization' => 'Bearer ' . $creds['pat'],
					'Content-Type'  => 'application/zip',
				),
				'body'       => $zip_data,
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_Static_Arquitect::log( 'Error al desplegar en Netlify: ' . $response->get_error_message(), 'error' );
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body        = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 === $status_code || 201 === $status_code ) {
			$deploy_id       = isset( $body['id'] ) ? $body['id'] : '';
			$state           = isset( $body['state'] ) ? $body['state'] : 'ready';
			$ssl_url         = isset( $body['ssl_url'] ) ? $body['ssl_url'] : ( isset( $body['url'] ) ? $body['url'] : '' );
			$deploy_ssl_url  = isset( $body['deploy_ssl_url'] ) ? $body['deploy_ssl_url'] : $ssl_url;

			$deploy_info = array(
				'deploy_id'      => $deploy_id,
				'state'          => $state,
				'ssl_url'        => $ssl_url,
				'deploy_ssl_url' => $deploy_ssl_url,
				'deployed_at'    => current_time( 'Y-m-d H:i:s' ),
			);

			update_option( 'wp_static_arquitect_last_deploy_info', $deploy_info, false );

			WP_Static_Arquitect::log(
				sprintf( '¡Despliegue a Netlify exitoso! ID: %s | Estado: %s | URL: %s', $deploy_id, $state, $ssl_url ),
				'success'
			);

			return array(
				'success'     => true,
				'message'     => '¡Sitio estático desplegado en Netlify exitosamente!',
				'deploy_info' => $deploy_info,
			);
		} else {
			$err_msg = isset( $body['message'] ) ? $body['message'] : sprintf( 'Respuesta HTTP %d de Netlify.', $status_code );
			WP_Static_Arquitect::log( sprintf( 'Fallo en despliegue de Netlify (HTTP %d): %s', $status_code, $err_msg ), 'error' );
			return array(
				'success' => false,
				'message' => $err_msg,
			);
		}
	}

	/**
	 * Consulta el estado actual de un despliegue en Netlify.
	 *
	 * @param string $deploy_id ID del despliegue en Netlify.
	 * @return array
	 */
	public function check_deploy_status( $deploy_id ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['pat'] ) || empty( $creds['site_id'] ) || empty( $deploy_id ) ) {
			return array(
				'success' => false,
				'message' => 'Parámetros insuficientes para consultar estado de despliegue.',
			);
		}

		$url = self::NETLIFY_API_BASE . 'sites/' . rawurlencode( $creds['site_id'] ) . '/deploys/' . rawurlencode( $deploy_id );

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 15,
				'headers' => array(
					'Authorization' => 'Bearer ' . $creds['pat'],
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) ) {
			return array(
				'success' => false,
				'message' => 'Respuesta inesperada al consultar estado.',
			);
		}

		return array(
			'success' => true,
			'state'   => isset( $body['state'] ) ? $body['state'] : 'unknown',
			'data'    => $body,
		);
	}

	/**
	 * Dispara un Netlify Build Hook por webhook HTTP POST.
	 *
	 * @param string $hook_url URL del Build Hook de Netlify.
	 * @return array
	 */
	public function trigger_build_hook( $hook_url = '' ) {
		if ( empty( $hook_url ) ) {
			$hook_url = get_option( 'wp_static_arquitect_netlify_build_hook', '' );
		}
		if ( empty( $hook_url ) ) {
			return array(
				'success' => false,
				'message' => 'No se ha configurado la URL del Build Hook de Netlify.',
			);
		}

		WP_Static_Arquitect::log( sprintf( 'Disparando Netlify Build Hook: %s', $hook_url ), 'info' );

		$response = wp_remote_post(
			$hook_url,
			array(
				'timeout' => 15,
				'body'    => array( 'trigger_title' => 'WP Static Architect Auto Deploy on Save' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			WP_Static_Arquitect::log( 'Error al disparar Netlify Build Hook: ' . $response->get_error_message(), 'error' );
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 === $code || 201 === $code || 202 === $code ) {
			WP_Static_Arquitect::log( 'Netlify Build Hook activado con éxito. Reconstrucción en curso en Netlify.', 'success' );
			return array(
				'success' => true,
				'message' => 'Netlify Build Hook activado con éxito.',
			);
		}

		return array(
			'success' => false,
			'message' => 'Código de respuesta de Netlify: ' . $code,
		);
	}
}

