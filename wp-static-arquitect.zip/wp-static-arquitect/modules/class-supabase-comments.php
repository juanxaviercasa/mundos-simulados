<?php
/**
 * Integración con Supabase: bootstrap de base de datos, políticas RLS e inyección frontend.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Supabase_Comments {

	/**
	 * Retorna la consulta SQL DDL para crear la tabla y configurar las políticas RLS en Supabase.
	 *
	 * @return string Código SQL.
	 */
	public function get_schema_sql() {
		$auto_approve = get_option( 'wp_static_arquitect_supabase_auto_approve', '0' ) === '1';
		$default_val  = $auto_approve ? 'true' : 'false';

		return <<<SQL
-- Habilitar extensión para UUIDs automáticos
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 1. Crear tabla de comentarios si no existe
CREATE TABLE IF NOT EXISTS public.comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_slug TEXT NOT NULL,
    author_name TEXT NOT NULL,
    author_email TEXT,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_approved BOOLEAN NOT NULL DEFAULT {$default_val}
);

-- 2. Índice optimizado para búsquedas por post_slug
CREATE INDEX IF NOT EXISTS idx_comments_post_slug ON public.comments(post_slug);

-- 3. Habilitar seguridad de nivel de fila (Row Level Security)
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- 4. Política de Lectura pública: permite a cualquiera ver los comentarios aprobados
DROP POLICY IF EXISTS "Permitir lectura de comentarios aprobados" ON public.comments;
CREATE POLICY "Permitir lectura de comentarios aprobados"
ON public.comments FOR SELECT
TO anon, authenticated
USING (is_approved = true);

-- 5. Política de Inserción pública: permite a los visitantes enviar nuevos comentarios
DROP POLICY IF EXISTS "Permitir insercion anonima de comentarios" ON public.comments;
CREATE POLICY "Permitir insercion anonima de comentarios"
ON public.comments FOR INSERT
TO anon, authenticated
WITH CHECK (true);
SQL;
	}

	/**
	 * Retorna los pasos individuales estructurados del esquema SQL para Supabase.
	 * Cada paso contiene su número, título, descripción explicativa y sentencia SQL ejecutable.
	 *
	 * @return array
	 */
	public function get_schema_steps() {
		$auto_approve = get_option( 'wp_static_arquitect_supabase_auto_approve', '0' ) === '1';
		$default_val  = $auto_approve ? 'true' : 'false';

		return array(
			array(
				'step'        => 1,
				'title'       => 'Habilitar Extensión Criptográfica (UUIDs)',
				'description' => 'Habilita pgcrypto para generar automáticamente identificadores universales únicos mediante gen_random_uuid().',
				'badge'       => 'Prerrequisito',
				'sql'         => 'CREATE EXTENSION IF NOT EXISTS "pgcrypto";',
			),
			array(
				'step'        => 2,
				'title'       => 'Crear Tabla de Comentarios (public.comments)',
				'description' => 'Estructura relacional con autor, email, contenido, post_slug, fecha de creación y estado de aprobación moderado.',
				'badge'       => 'Estructura de Datos',
				'sql'         => "CREATE TABLE IF NOT EXISTS public.comments (\n    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n    post_slug TEXT NOT NULL,\n    author_name TEXT NOT NULL,\n    author_email TEXT,\n    content TEXT NOT NULL,\n    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),\n    is_approved BOOLEAN NOT NULL DEFAULT {$default_val}\n);",
			),
			array(
				'step'        => 3,
				'title'       => 'Crear Índice de Búsqueda Rápida',
				'description' => 'Optimiza las consultas por post_slug para que la carga de comentarios en el frontend estático sea instantánea (< 15ms).',
				'badge'       => 'Rendimiento / Índice',
				'sql'         => 'CREATE INDEX IF NOT EXISTS idx_comments_post_slug ON public.comments(post_slug);',
			),
			array(
				'step'        => 4,
				'title'       => 'Habilitar Seguridad de Nivel de Fila (RLS)',
				'description' => 'Activa Row Level Security en PostgreSQL para bloquear manipulaciones no autorizadas en la base de datos.',
				'badge'       => 'Seguridad RLS',
				'sql'         => 'ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;',
			),
			array(
				'step'        => 5,
				'title'       => 'Políticas RLS: Lectura e Inserción Anónima',
				'description' => 'Autoriza a los visitantes del sitio estático a leer comentarios aprobados y enviar nuevos mensajes a la bandeja de moderación.',
				'badge'       => 'Políticas de Acceso',
				'sql'         => "-- Lectura pública de comentarios aprobados\nDROP POLICY IF EXISTS \"Permitir lectura de comentarios aprobados\" ON public.comments;\nCREATE POLICY \"Permitir lectura de comentarios aprobados\"\nON public.comments FOR SELECT\nTO anon, authenticated\nUSING (is_approved = true);\n\n-- Inserción anónima de nuevos comentarios\nDROP POLICY IF EXISTS \"Permitir insercion anonima de comentarios\" ON public.comments;\nCREATE POLICY \"Permitir insercion anonima de comentarios\"\nON public.comments FOR INSERT\nTO anon, authenticated\nWITH CHECK (true);",
			),
		);
	}

	/**
	 * Obtiene las credenciales de Supabase.
	 *
	 * @return array
	 */
	public function get_credentials() {
		return array(
			'url'                => untrailingslashit( get_option( 'wp_static_arquitect_supabase_url', '' ) ),
			'anon_key'           => get_option( 'wp_static_arquitect_supabase_anon_key', '' ),
			'service_key'        => get_option( 'wp_static_arquitect_supabase_service_key', '' ),
			'auto_approve'       => get_option( 'wp_static_arquitect_supabase_auto_approve', '0' ) === '1',
			'turnstile_site_key' => get_option( 'wp_static_arquitect_turnstile_site_key', '' ),
		);
	}

	/**
	 * Prueba la conectividad con Supabase consultando la tabla comments.
	 *
	 * @return array
	 */
	public function test_connection() {
		$creds = $this->get_credentials();
		if ( empty( $creds['url'] ) || empty( $creds['anon_key'] ) ) {
			return array(
				'success' => false,
				'message' => 'Falta configurar la URL del proyecto o la Anon Key de Supabase.',
			);
		}

		$endpoint = $creds['url'] . '/rest/v1/comments?select=count';
		$response = wp_remote_get(
			$endpoint,
			array(
				'timeout' => 15,
				'headers' => array(
					'apikey'        => $creds['anon_key'],
					'Authorization' => 'Bearer ' . $creds['anon_key'],
					'Range'         => '0-0',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => 'Error de conexión HTTP: ' . $response->get_error_message(),
			);
		}

		$status = wp_remote_retrieve_response_code( $response );
		if ( 200 === $status || 206 === $status ) {
			return array(
				'success' => true,
				'message' => '¡Conexión exitosa! La tabla "comments" existe y responde correctamente.',
			);
		} elseif ( 404 === $status ) {
			return array(
				'success' => false,
				'message' => 'Conexión alcanzada, pero la tabla "comments" aún no ha sido creada. Ejecuta el Bootstrap.',
			);
		} else {
			$body = wp_remote_retrieve_body( $response );
			return array(
				'success' => false,
				'message' => sprintf( 'Supabase respondió con código HTTP %d: %s', $status, substr( $body, 0, 200 ) ),
			);
		}
	}

	/**
	 * Ejecuta el Bootstrap automático de la base de datos en Supabase.
	 * Utiliza la Service Role Key si está provista, o la API de Supabase Management.
	 *
	 * @return array
	 */
	public function run_bootstrap() {
		$creds = $this->get_credentials();
		if ( empty( $creds['url'] ) ) {
			return array(
				'success' => false,
				'message' => 'Debes ingresar la URL de tu proyecto Supabase.',
			);
		}

		$sql = $this->get_schema_sql();

		// Extraer el project ref de la URL (ej. https://abcdefgh.supabase.co -> abcdefgh)
		$host  = wp_parse_url( $creds['url'], PHP_URL_HOST );
		$parts = explode( '.', $host );
		$ref   = $parts[0];

		// Método 1: Si hay Service Role Key, usar endpoint SQL pg/admin o rpc
		$auth_token = ! empty( $creds['service_key'] ) ? $creds['service_key'] : $creds['anon_key'];

		// Intentar primero con la Management API si es un token de gestión
		$management_url = 'https://api.supabase.com/v1/projects/' . $ref . '/database/query';
		$response       = wp_remote_post(
			$management_url,
			array(
				'timeout' => 25,
				'headers' => array(
					'Authorization' => 'Bearer ' . $auth_token,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( array( 'query' => $sql ) ),
			)
		);

		$status = wp_remote_retrieve_response_code( $response );

		if ( 200 === $status || 201 === $status ) {
			WP_Static_Arquitect::log( 'Bootstrap de base de datos en Supabase completado con éxito vía API.', 'success' );
			return array(
				'success' => true,
				'message' => '¡Tabla "comments" y políticas RLS configuradas exitosamente en Supabase!',
			);
		}

		// Si la API directa requiere token de gestión específico, verificamos si la tabla ya existe
		$check = $this->test_connection();
		if ( $check['success'] ) {
			return array(
				'success' => true,
				'message' => 'La tabla "comments" ya está creada y operativa.',
			);
		}

		// Si no se pudo crear automáticamente, se instruye el uso asistido de SQL
		return array(
			'success'     => false,
			'manual_sql'  => true,
			'sql_code'    => $sql,
			'message'     => 'No se pudo crear automáticamente la tabla vía REST (requiere token administrativo de Supabase). Puedes copiar el script SQL generado abajo y ejecutarlo en el "SQL Editor" de tu panel de Supabase con 1 solo clic.',
		);
	}

	/**
	 * Inyecta el contenedor y los scripts de Supabase Comments en el documento DOM.
	 *
	 * @param DOMXPath    $xpath
	 * @param DOMDocument $dom
	 * @param string      $post_slug
	 * @param string      $current_url
	 */
	public function inject_comments_section( $xpath, $dom, $post_slug, $current_url ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['url'] ) || empty( $creds['anon_key'] ) ) {
			return; // Si no hay credenciales, no inyectar
		}

		// Localizar contenedores tradicionales de comentarios de WordPress
		$selectors = array(
			"//*[@id='comments']",
			"//*[contains(@class, 'comments-area')]",
			"//*[@id='respond']",
			"//*[contains(@class, 'comment-respond')]",
		);

		$found_container = null;
		foreach ( $selectors as $sel ) {
			$nodes = $xpath->query( $sel );
			if ( $nodes && $nodes->length > 0 ) {
				$found_container = $nodes->item( 0 );
				break;
			}
		}

		// Generar el bloque HTML de comentarios
		$comments_block_html = $this->render_comments_container_html( $post_slug, $creds );

		if ( $found_container ) {
			// Crear nodo contenedor temporal
			$temp_doc = new DOMDocument();
			libxml_use_internal_errors( true );
			$temp_doc->loadHTML(
				mb_encode_numericentity( $comments_block_html, array( 0x80, 0x10FFFF, 0, 0x1FFFFF ), 'UTF-8' ),
				LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
			);
			libxml_clear_errors();

			$imported_node = $dom->importNode( $temp_doc->documentElement, true );
			$found_container->parentNode->replaceChild( $imported_node, $found_container );
		}

		// Inyectar etiquetas CSS y JS
		$this->inject_head_css( $dom );
		$this->inject_footer_js( $dom );
	}

	/**
	 * Renderiza el HTML del contenedor de comentarios.
	 *
	 * @param string $post_slug
	 * @param array  $creds
	 * @return string
	 */
	private function render_comments_container_html( $post_slug, $creds ) {
		$template_path = WP_STATIC_ARQUITECT_PATH . 'templates/supabase-comments.html';
		$html          = '';

		if ( file_exists( $template_path ) ) {
			$html = file_get_contents( $template_path );
		}

		// Si no existe la plantilla, usar marcado base
		if ( empty( $html ) ) {
			$html = '<div id="wp-static-comments-container"></div>';
		}

		// Reemplazar placeholders de configuración
		$html = str_replace( '{{POST_SLUG}}', esc_attr( $post_slug ), $html );
		$html = str_replace( '{{SUPABASE_URL}}', esc_url( $creds['url'] ), $html );
		$html = str_replace( '{{SUPABASE_ANON_KEY}}', esc_attr( $creds['anon_key'] ), $html );
		$html = str_replace( '{{AUTO_APPROVE}}', $creds['auto_approve'] ? 'true' : 'false', $html );

		// Turnstile Anti-Spam
		$turnstile_html = '';
		if ( ! empty( $creds['turnstile_site_key'] ) ) {
			$turnstile_html = '<div class="wpsa-turnstile-wrapper" style="margin-bottom: 16px;"><div class="cf-turnstile" data-sitekey="' . esc_attr( $creds['turnstile_site_key'] ) . '" data-theme="auto"></div></div>';
		}
		$html = str_replace( '{{TURNSTILE_CONTAINER}}', $turnstile_html, $html );

		return $html;
	}

	/**
	 * Inyecta el archivo CSS de comentarios en el <head>.
	 *
	 * @param DOMDocument $dom
	 */
	private function inject_head_css( $dom ) {
		$head = $dom->getElementsByTagName( 'head' )->item( 0 );
		if ( ! $head ) {
			return;
		}

		$link = $dom->createElement( 'link' );
		$link->setAttribute( 'rel', 'stylesheet' );
		$link->setAttribute( 'href', '/wp-static-arquitect-assets/supabase-comments.css' );

		$head->appendChild( $link );
	}

	/**
	 * Inyecta el script JS de comentarios antes de cerrar el <body>.
	 *
	 * @param DOMDocument $dom
	 */
	private function inject_footer_js( $dom ) {
		$body = $dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			return;
		}

		$creds = $this->get_credentials();

		// Si Cloudflare Turnstile está configurado, inyectar su script oficial
		if ( ! empty( $creds['turnstile_site_key'] ) ) {
			$turnstile_script = $dom->createElement( 'script' );
			$turnstile_script->setAttribute( 'src', 'https://challenges.cloudflare.com/turnstile/v0/api.js' );
			$turnstile_script->setAttribute( 'async', 'async' );
			$turnstile_script->setAttribute( 'defer', 'defer' );
			$body->appendChild( $turnstile_script );
		}

		$script = $dom->createElement( 'script' );
		$script->setAttribute( 'src', '/wp-static-arquitect-assets/supabase-comments.js' );
		$script->setAttribute( 'defer', 'defer' );

		$body->appendChild( $script );
	}

	/**
	 * Obtiene los comentarios de Supabase para la bandeja de moderación.
	 *
	 * @param string $status 'all', 'pending' o 'approved'.
	 * @param int    $limit
	 * @param int    $offset
	 * @return array
	 */
	public function get_admin_comments( $status = 'all', $limit = 50, $offset = 0 ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['url'] ) ) {
			return array(
				'success' => false,
				'message' => 'Falta configurar la URL de Supabase.',
			);
		}

		$auth_token = ! empty( $creds['service_key'] ) ? $creds['service_key'] : $creds['anon_key'];
		if ( empty( $auth_token ) ) {
			return array(
				'success' => false,
				'message' => 'Se requiere la Service Role Key o Anon Key para acceder a los comentarios.',
			);
		}

		$query_params = array(
			'select' => '*',
			'order'  => 'created_at.desc',
			'limit'  => (int) $limit,
			'offset' => (int) $offset,
		);

		if ( 'pending' === $status ) {
			$query_params['is_approved'] = 'eq.false';
		} elseif ( 'approved' === $status ) {
			$query_params['is_approved'] = 'eq.true';
		}

		$endpoint = $creds['url'] . '/rest/v1/comments?' . http_build_query( $query_params );

		$response = wp_remote_get(
			$endpoint,
			array(
				'timeout' => 15,
				'headers' => array(
					'apikey'        => $auth_token,
					'Authorization' => 'Bearer ' . $auth_token,
					'Content-Type'  => 'application/json',
					'Prefer'        => 'count=exact',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status_code && 206 !== $status_code ) {
			return array(
				'success' => false,
				'message' => sprintf( 'Error de Supabase (HTTP %d). Revisa que la tabla "comments" exista y que uses la Service Role Key si RLS está activo.', $status_code ),
			);
		}

		$comments = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $comments ) ) {
			$comments = array();
		}

		return array(
			'success'  => true,
			'comments' => $comments,
			'total'    => count( $comments ),
		);
	}

	/**
	 * Actualiza el estado de aprobación de un comentario.
	 *
	 * @param string $comment_id  UUID del comentario.
	 * @param bool   $is_approved True para aprobar, false para desaprobar.
	 * @return array
	 */
	public function update_comment_status( $comment_id, $is_approved ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['url'] ) ) {
			return array( 'success' => false, 'message' => 'Falta configurar URL de Supabase.' );
		}

		$auth_token = ! empty( $creds['service_key'] ) ? $creds['service_key'] : $creds['anon_key'];
		$endpoint   = $creds['url'] . '/rest/v1/comments?id=eq.' . rawurlencode( $comment_id );

		$response = wp_remote_request(
			$endpoint,
			array(
				'method'  => 'PATCH',
				'timeout' => 15,
				'headers' => array(
					'apikey'        => $auth_token,
					'Authorization' => 'Bearer ' . $auth_token,
					'Content-Type'  => 'application/json',
					'Prefer'        => 'return=representation',
				),
				'body'    => wp_json_encode( array( 'is_approved' => (bool) $is_approved ) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'message' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 === $code || 204 === $code ) {
			return array(
				'success' => true,
				'message' => $is_approved ? 'Comentario aprobado con éxito.' : 'Comentario marcado como pendiente.',
			);
		}

		return array(
			'success' => false,
			'message' => sprintf( 'Fallo al actualizar estado (HTTP %d). Revisa permisos de Service Role.', $code ),
		);
	}

	/**
	 * Elimina un comentario de Supabase.
	 *
	 * @param string $comment_id UUID del comentario.
	 * @return array
	 */
	public function delete_comment( $comment_id ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['url'] ) ) {
			return array( 'success' => false, 'message' => 'Falta configurar URL de Supabase.' );
		}

		$auth_token = ! empty( $creds['service_key'] ) ? $creds['service_key'] : $creds['anon_key'];
		$endpoint   = $creds['url'] . '/rest/v1/comments?id=eq.' . rawurlencode( $comment_id );

		$response = wp_remote_request(
			$endpoint,
			array(
				'method'  => 'DELETE',
				'timeout' => 15,
				'headers' => array(
					'apikey'        => $auth_token,
					'Authorization' => 'Bearer ' . $auth_token,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'message' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 === $code || 204 === $code ) {
			return array(
				'success' => true,
				'message' => 'Comentario eliminado exitosamente.',
			);
		}

		return array(
			'success' => false,
			'message' => sprintf( 'Fallo al eliminar comentario (HTTP %d). Revisa permisos de Service Role.', $code ),
		);
	}
}
