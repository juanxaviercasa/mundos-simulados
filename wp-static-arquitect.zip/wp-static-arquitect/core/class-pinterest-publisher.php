<?php
/**
 * Conector y Publicador Automático de Pines con la API v5 de Pinterest.
 *
 * Permite publicar de forma programada y dosificada (Drip-Feed) pines en tableros de Pinterest
 * con imagen destacada, título, extracto y enlace canónico hacia el sitio estático.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Pinterest_Publisher {

	/**
	 * Endpoint base de la API REST v5 de Pinterest.
	 */
	const PINTEREST_API_BASE = 'https://api.pinterest.com/v5/';

	/**
	 * Obtiene las credenciales de Pinterest configuradas en las opciones.
	 *
	 * @return array
	 */
	public function get_credentials() {
		return array(
			'token'       => trim( (string) get_option( 'wp_static_arquitect_pinterest_token', '' ) ),
			'board_id'    => trim( (string) get_option( 'wp_static_arquitect_pinterest_board_id', '' ) ),
			'auto_pin'    => '1' === get_option( 'wp_static_arquitect_pinterest_auto_pin', '0' ),
			'multi_pin'   => '0' !== get_option( 'wp_static_arquitect_pinterest_multi_pin', '1' ),
			'drip_count'  => (int) get_option( 'wp_static_arquitect_drip_posts_count', 5 ),
		);
	}

	/**
	 * Comprueba la validez del token y el acceso al tablero en Pinterest API v5.
	 *
	 * @param string $token_override
	 * @param string $board_override
	 * @return array
	 */
	public function test_connection( $token_override = '', $board_override = '' ) {
		$creds    = $this->get_credentials();
		$token    = ! empty( $token_override ) ? $token_override : $creds['token'];
		$board_id = ! empty( $board_override ) ? $board_override : $creds['board_id'];

		if ( empty( $token ) ) {
			return array(
				'success' => false,
				'message' => 'Token de acceso a Pinterest no configurado.',
			);
		}

		WP_Static_Arquitect::log( 'Verificando credenciales con la API v5 de Pinterest...', 'info' );

		// 1. Probar cuenta de usuario
		$user_url = self::PINTEREST_API_BASE . 'user_account';
		$response = wp_remote_get(
			$user_url,
			array(
				'timeout'    => 15,
				'sslverify'  => false,
				'user-agent' => 'WP-Static-Architect/1.0',
				'headers'    => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => 'Error de conexión con Pinterest: ' . $response->get_error_message(),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$err_msg = ! empty( $body['message'] ) ? $body['message'] : sprintf( 'Error HTTP %d de Pinterest API', $code );
			return array(
				'success' => false,
				'message' => $err_msg,
			);
		}

		$username = isset( $body['username'] ) ? $body['username'] : 'Usuario';

		// 2. Si se proporcionó Board ID, verificar acceso al tablero
		$board_info = null;
		if ( ! empty( $board_id ) ) {
			$board_url  = self::PINTEREST_API_BASE . 'boards/' . rawurlencode( $board_id );
			$board_resp = wp_remote_get(
				$board_url,
				array(
					'timeout'    => 15,
					'sslverify'  => false,
					'headers'    => array(
						'Authorization' => 'Bearer ' . $token,
					),
				)
			);

			if ( ! is_wp_error( $board_resp ) && 200 === wp_remote_retrieve_response_code( $board_resp ) ) {
				$b_body     = json_decode( wp_remote_retrieve_body( $board_resp ), true );
				$board_info = isset( $b_body['name'] ) ? $b_body['name'] : $board_id;
			}
		}

		return array(
			'success'    => true,
			'username'   => $username,
			'board_name' => $board_info,
			'message'    => sprintf(
				'¡Conexión exitosa con Pinterest! Cuenta: @%s%s.',
				$username,
				$board_info ? sprintf( ' | Tablero: "%s"', $board_info ) : ''
			),
		);
	}

	/**
	 * Extrae hasta 3 imágenes distintas de un post (destacada + 2 internas).
	 *
	 * @param WP_Post $post
	 * @return array Lista de imágenes con url, tipo y sufijo de título.
	 */
	public function extract_post_images( $post ) {
		$images = array();
		$seen   = array();

		// 1. Imagen destacada (Pin #1)
		$thumb_id = get_post_thumbnail_id( $post->ID );
		if ( $thumb_id ) {
			$img_src = wp_get_attachment_image_src( $thumb_id, 'full' );
			if ( $img_src && ! empty( $img_src[0] ) ) {
				$images[] = array(
					'url'          => $img_src[0],
					'type'         => 'featured',
					'title_suffix' => '',
					'desc_suffix'  => '',
				);
				$seen[] = $img_src[0];
			}
		}

		// 2. Imágenes internas dentro del contenido (Pines #2 y #3)
		preg_match_all( '/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches );
		if ( ! empty( $matches[1] ) ) {
			$internal_count = 1;
			foreach ( $matches[1] as $src ) {
				if ( in_array( $src, $seen, true ) ) {
					continue;
				}
				$seen[] = $src;

				$title_suffix = 1 === $internal_count ? ' | Concepto & Detalles' : ' | Guía Visual';
				$desc_suffix  = 1 === $internal_count ? ' Explora los detalles y conceptos clave en nuestro artículo.' : ' Revisa la guía visual completa y recursos recomendados.';

				$images[] = array(
					'url'          => $src,
					'type'         => 'internal_' . $internal_count,
					'title_suffix' => $title_suffix,
					'desc_suffix'  => $desc_suffix,
				);

				$internal_count++;
				if ( count( $images ) >= 3 ) {
					break;
				}
			}
		}

		return $images;
	}

	/**
	 * Crea Pines en Pinterest para una entrada específica de WordPress.
	 *
	 * Soporta la Estrategia Multi-Pin (3 pines por artículo: portada + 2 imágenes internas),
	 * maximizando el tráfico orgánico y la cobertura de búsqueda en Pinterest.
	 *
	 * @param int|WP_Post $post
	 * @param string      $board_id_override
	 * @return array
	 */
	public function create_pin_for_post( $post, $board_id_override = '' ) {
		if ( is_numeric( $post ) ) {
			$post = get_post( $post );
		}
		if ( ! ( $post instanceof WP_Post ) ) {
			return array( 'success' => false, 'message' => 'Entrada no válida.' );
		}

		$creds     = $this->get_credentials();
		$token     = $creds['token'];
		$board_id  = ! empty( $board_id_override ) ? $board_id_override : $creds['board_id'];
		$multi_pin = $creds['multi_pin'];

		if ( empty( $token ) || empty( $board_id ) ) {
			return array(
				'success' => false,
				'message' => 'Credenciales de Pinterest incompletas (Token o Board ID faltantes).',
			);
		}

		// 1. Extraer hasta 3 imágenes del artículo
		$images = $this->extract_post_images( $post );

		if ( empty( $images ) ) {
			return array(
				'success' => false,
				'message' => sprintf( 'La entrada [#%d: %s] no contiene ninguna imagen para generar un Pin.', $post->ID, $post->post_title ),
			);
		}

		// Si multi-pin está desactivado, limitarse solo a la primera imagen
		if ( ! $multi_pin ) {
			$images = array_slice( $images, 0, 1 );
		}

		// 2. Determinar URL canónica de destino (priorizando el dominio estático de producción)
		$canonical_domain = get_option( 'wp_static_arquitect_custom_domain', '' );
		if ( empty( $canonical_domain ) ) {
			$canonical_domain = get_option( 'wp_static_arquitect_production_url', '' );
		}

		$post_permalink = get_permalink( $post->ID );
		if ( ! empty( $canonical_domain ) ) {
			$parsed_canonical = wp_parse_url( $canonical_domain );
			$target_host      = isset( $parsed_canonical['host'] ) ? $parsed_canonical['host'] : $canonical_domain;
			$target_scheme    = isset( $parsed_canonical['scheme'] ) ? $parsed_canonical['scheme'] : 'https';
			$target_base      = untrailingslashit( $target_scheme . '://' . $target_host );

			$parsed_local = wp_parse_url( home_url() );
			$local_base   = untrailingslashit( ( isset( $parsed_local['scheme'] ) ? $parsed_local['scheme'] : 'http' ) . '://' . ( isset( $parsed_local['host'] ) ? $parsed_local['host'] : '' ) );

			$post_permalink = str_replace( $local_base, $target_base, $post_permalink );
		}

		// 3. Textos base
		$base_title = wp_strip_all_tags( $post->post_title );
		$base_desc  = wp_strip_all_tags( get_the_excerpt( $post ) );
		if ( empty( $base_desc ) ) {
			$base_desc = wp_trim_words( wp_strip_all_tags( $post->post_content ), 35, '...' );
		}

		$pin_ids      = array();
		$success_pins = 0;
		$url          = self::PINTEREST_API_BASE . 'pins';

		foreach ( $images as $idx => $img_info ) {
			$pin_title = substr( $base_title . $img_info['title_suffix'], 0, 100 );
			$pin_desc  = substr( $base_desc . $img_info['desc_suffix'], 0, 500 );

			WP_Static_Arquitect::log( sprintf( 'Creando Pin #%d (%s) en Pinterest para [#%d: %s]...', $idx + 1, $img_info['type'], $post->ID, $pin_title ), 'info' );

			$pin_data = array(
				'title'        => $pin_title,
				'description'  => $pin_desc,
				'link'         => esc_url_raw( $post_permalink ),
				'board_id'     => $board_id,
				'media_source' => array(
					'source_type' => 'image_url',
					'url'         => esc_url_raw( $img_info['url'] ),
				),
			);

			$response = wp_remote_post(
				$url,
				array(
					'timeout'    => 25,
					'sslverify'  => false,
					'user-agent' => 'WP-Static-Architect/1.0',
					'headers'    => array(
						'Authorization' => 'Bearer ' . $token,
						'Content-Type'  => 'application/json',
					),
					'body'       => wp_json_encode( $pin_data ),
				)
			);

			if ( ! is_wp_error( $response ) && ( 201 === wp_remote_retrieve_response_code( $response ) || 200 === wp_remote_retrieve_response_code( $response ) ) ) {
				$body   = json_decode( wp_remote_retrieve_body( $response ), true );
				$pin_id = isset( $body['id'] ) ? $body['id'] : '';
				if ( $pin_id ) {
					$pin_ids[] = $pin_id;
					$success_pins++;
				}
			}

			// Pausa entre pines de 300ms para respetar límites de Pinterest
			if ( count( $images ) > 1 ) {
				usleep( 300000 );
			}
		}

		if ( $success_pins > 0 ) {
			update_post_meta( $post->ID, '_wpsa_pinterest_pin_id', $pin_ids[0] );
			update_post_meta( $post->ID, '_wpsa_pinterest_pin_ids', $pin_ids );
			update_post_meta( $post->ID, '_wpsa_pinterest_pinned_at', current_time( 'Y-m-d H:i:s' ) );

			WP_Static_Arquitect::log( sprintf( '¡%d Pin(es) creado(s) con éxito en Pinterest para [#%d: %s]!', $success_pins, $post->ID, $base_title ), 'success' );

			return array(
				'success'  => true,
				'pin_ids'  => $pin_ids,
				'post_id'  => $post->ID,
				'title'    => $base_title,
				'link'     => $post_permalink,
				'message'  => sprintf( '%d Pin(es) publicado(s) en Pinterest para esta entrada.', $success_pins ),
			);
		}

		return array(
			'success' => false,
			'message' => 'No se pudo crear los pines en Pinterest. Verifica que las URLs de las imágenes sean accesibles públicamente.',
		);
	}

	/**
	 * Sincroniza un lote dosificado (Drip-Feed) de entradas hacia Pinterest.
	 *
	 * @param int  $limit Límite de pines a crear en esta ejecución (por defecto 3 a 5).
	 * @param bool $force Si es true, publica incluso si ya fue pineado previamente.
	 * @return array
	 */
	public function sync_recent_posts( $limit = 3, $force = false ) {
		$creds = $this->get_credentials();
		if ( empty( $creds['token'] ) || empty( $creds['board_id'] ) ) {
			return array(
				'success' => false,
				'message' => 'Credenciales de Pinterest no configuradas.',
			);
		}

		$limit = max( 1, min( 10, (int) $limit ) );

		// Buscar posts publicados que tengan imagen destacada
		$args = array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => $limit * 3, // Tomamos un margen amplio
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		if ( ! $force ) {
			$args['meta_query'] = array(
				array(
					'key'     => '_wpsa_pinterest_pin_id',
					'compare' => 'NOT EXISTS',
				),
			);
		}

		$posts = get_posts( $args );

		if ( empty( $posts ) ) {
			return array(
				'success'      => true,
				'pinned_count' => 0,
				'message'      => 'No hay entradas pendientes de pinear en este ciclo Drip-Feed.',
			);
		}

		$pinned_count = 0;
		$results      = array();

		foreach ( $posts as $p ) {
			if ( $pinned_count >= $limit ) {
				break;
			}

			$res = $this->create_pin_for_post( $p );
			if ( ! empty( $res['success'] ) ) {
				$pinned_count++;
				$results[] = $res;
				// Pausa preventiva de 400ms para respetar límites de tasa de Pinterest
				usleep( 400000 );
			}
		}

		$msg = sprintf( 'Ciclo Drip-Feed de Pinterest completado: %d pin(es) publicado(s).', $pinned_count );
		WP_Static_Arquitect::log( $msg, 'info' );

		return array(
			'success'      => true,
			'pinned_count' => $pinned_count,
			'details'      => $results,
			'message'      => $msg,
		);
	}
}
