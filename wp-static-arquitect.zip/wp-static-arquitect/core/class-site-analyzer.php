<?php
/**
 * Motor de Diagnóstico y Recomendación Inteligente de Hosting Serverless.
 *
 * Analiza el volumen de contenido, peso de la biblioteca de medios, presencia de formularios
 * de contacto y dinamismo (comentarios) para recomendar de forma automática la plataforma
 * gratuita más adecuada (Cloudflare Pages, Netlify, GitHub Pages, Render).
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Site_Analyzer {

	/**
	 * Ejecuta el análisis completo del sitio WordPress y genera recomendaciones.
	 *
	 * @return array
	 */
	public function analyze_site() {
		$stats           = $this->gather_site_stats();
		$recommendations = $this->calculate_recommendations( $stats );
		$combos          = $this->generate_top_combos( $stats, $recommendations );

		return array(
			'success'         => true,
			'timestamp'       => current_time( 'Y-m-d H:i:s' ),
			'stats'           => $stats,
			'recommendations' => $recommendations,
			'combos'          => $combos,
			'best_match'      => ! empty( $recommendations[0] ) ? $recommendations[0] : null,
			'best_combo'      => ! empty( $combos[0] ) ? $combos[0] : null,
		);
	}

	/**
	 * Recopila estadísticas del sitio de WordPress: contenidos, medios, formularios y comentarios.
	 *
	 * @return array
	 */
	public function gather_site_stats() {
		// 1. Conteo de publicaciones y páginas
		$post_counts = wp_count_posts( 'post' );
		$page_counts = wp_count_posts( 'page' );
		$att_counts  = wp_count_posts( 'attachment' );

		$published_posts = isset( $post_counts->publish ) ? (int) $post_counts->publish : 0;
		$published_pages = isset( $page_counts->publish ) ? (int) $page_counts->publish : 0;
		$attachments     = isset( $att_counts->inherit ) ? (int) $att_counts->inherit : 0;
		$total_content   = $published_posts + $published_pages;

		// 2. Peso y tamaño de la carpeta de uploads
		$upload_dir_info = wp_upload_dir();
		$uploads_basedir = $upload_dir_info['basedir'];
		$uploads_size    = $this->estimate_directory_size( $uploads_basedir );
		$uploads_mb      = round( $uploads_size / ( 1024 * 1024 ), 2 );

		// 3. Detección de plugins de formularios activos o etiquetas de formulario
		$detected_form_plugins = $this->detect_form_plugins();
		$has_forms             = ! empty( $detected_form_plugins ) || $this->has_form_shortcodes();

		// 4. Detección de dinamismo (comentarios y Supabase)
		$comments_open       = 'open' === get_option( 'default_comment_status', 'closed' );
		$enable_comments_opt = '0' !== get_option( 'wp_static_arquitect_enable_comments', '1' );
		$supabase_url        = get_option( 'wp_static_arquitect_supabase_url', '' );
		$supabase_connected  = ! empty( $supabase_url );

		// 5. Configuración actual de hosting
		$current_provider = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );
		$custom_domain    = get_option( 'wp_static_arquitect_custom_domain', '' );

		return array(
			'published_posts'       => $published_posts,
			'published_pages'       => $published_pages,
			'total_content'         => $total_content,
			'attachments_count'     => $attachments,
			'uploads_size_bytes'    => $uploads_size,
			'uploads_size_mb'       => $uploads_mb,
			'uploads_formatted'     => size_format( $uploads_size, 2 ),
			'has_forms'             => $has_forms,
			'form_plugins'          => $detected_form_plugins,
			'comments_open'         => $comments_open && $enable_comments_opt,
			'supabase_connected'    => $supabase_connected,
			'current_provider'      => $current_provider,
			'custom_domain'         => $custom_domain,
		);
	}

	/**
	 * Detecta plugins populares de formularios instalados y activos.
	 *
	 * @return array Nombres de plugins de formularios encontrados.
	 */
	private function detect_form_plugins() {
		$form_plugins = array();

		$known_plugins = array(
			'contact-form-7/wp-contact-form-7.php'        => 'Contact Form 7',
			'wpforms-lite/wpforms.php'                   => 'WPForms Lite',
			'wpforms/wpforms.php'                        => 'WPForms Pro',
			'ninja-forms/ninja-forms.php'                => 'Ninja Forms',
			'formidable/formidable.php'                  => 'Formidable Forms',
			'fluentform/fluentform.php'                  => 'Fluent Forms',
			'gravityforms/gravityforms.php'              => 'Gravity Forms',
			'kali-forms/kali-forms.php'                  => 'Kali Forms',
			'formulator/formulator.php'                  => 'Formulator',
		);

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		foreach ( $known_plugins as $plugin_path => $plugin_name ) {
			if ( is_plugin_active( $plugin_path ) ) {
				$form_plugins[] = $plugin_name;
			}
		}

		return $form_plugins;
	}

	/**
	 * Verifica si en los últimos posts/páginas existen shortcodes de formulario.
	 *
	 * @return bool
	 */
	private function has_form_shortcodes() {
		global $wpdb;
		$shortcode_query = $wpdb->get_var(
			"SELECT ID FROM {$wpdb->posts} 
			 WHERE post_status = 'publish' 
			 AND (post_content LIKE '%[contact-form%' OR post_content LIKE '%[wpforms%' OR post_content LIKE '%[formidable%' OR post_content LIKE '%[fluentform%') 
			 LIMIT 1"
		);

		return ! empty( $shortcode_query );
	}

	/**
	 * Estima el tamaño en bytes de un directorio con límite de tiempo seguro.
	 *
	 * @param string $dir Ruta al directorio.
	 * @return int Tamaño en bytes.
	 */
	private function estimate_directory_size( $dir ) {
		if ( ! is_dir( $dir ) || ! is_readable( $dir ) ) {
			return 0;
		}

		$size       = 0;
		$file_count = 0;
		$max_files  = 10000; // Límite de seguridad para evitar demoras en directorios gigantescos

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);

			foreach ( $iterator as $file ) {
				if ( $file->isFile() ) {
					$size += $file->getSize();
					$file_count++;
					if ( $file_count >= $max_files ) {
						break;
					}
				}
			}
		} catch ( Exception $e ) {
			// En caso de permisos denegados en subcarpetas
		}

		return $size;
	}

	/**
	 * Calcula las puntuaciones de compatibilidad y genera la matriz de recomendaciones.
	 *
	 * @param array $stats Estadísticas recopiladas.
	 * @return array
	 */
	public function calculate_recommendations( $stats ) {
		$recommendations = array();

		// ========================================================
		// 1. CLOUDFLARE PAGES
		// ========================================================
		$cf_score   = 85;
		$cf_reasons = array();
		$cf_pros    = array(
			'Ancho de banda mensual 100% ILIMITADO en su capa gratuita (sin costos sorpresa).',
			'Red Anycast global en más de 300 ciudades (la CDN estática más veloz del mundo).',
			'Soporte nativo para reglas _redirects, _headers y _routes.json.',
			'Deploy Hooks HTTP instantáneos y compatibilidad con inboxes de correo serverless (Web3Forms/FormSubmit).',
		);
		$cf_cons    = array(
			'Requiere un servicio de inbox serverless (como Web3Forms o FormSubmit) para procesar formularios de contacto.',
		);

		if ( $stats['uploads_size_mb'] > 50 ) {
			$cf_score    += 12;
			$cf_reasons[] = sprintf( 'Tu biblioteca de medios pesa %s MB: Cloudflare Pages es la única plataforma que ofrece ancho de banda 100%% ilimitado sin límites de transferencia.', $stats['uploads_size_mb'] );
		}
		if ( $stats['total_content'] > 100 ) {
			$cf_score    += 5;
			$cf_reasons[] = sprintf( 'Tu sitio cuenta con %d páginas/entradas: la red global de Cloudflare garantiza carga instantánea en cualquier país.', $stats['total_content'] );
		}
		if ( empty( $cf_reasons ) ) {
			$cf_reasons[] = 'Excelente velocidad, alta disponibilidad y sin restricciones de ancho de banda.';
		}

		$recommendations[] = array(
			'provider'       => 'cloudflare',
			'name'           => 'Cloudflare Pages',
			'score'          => min( 99, $cf_score ),
			'badge'          => '⭐ Máxima Capacidad & Ancho de Banda Ilimitado',
			'badge_class'    => 'wpsa-badge-best',
			'reasons'        => $cf_reasons,
			'pros'           => $cf_pros,
			'cons'           => $cf_cons,
			'deploy_methods' => array( 'Deploy Hook (HTTP POST)', 'Direct Upload API', 'Git Sync (GitHub/GitLab)' ),
		);

		// ========================================================
		// 2. NETLIFY
		// ========================================================
		$net_score   = 82;
		$net_reasons = array();
		$net_pros    = array(
			'Formularios serverless nativos con detección automática (data-netlify="true") sin configurar servicios externos.',
			'1-Click Deploy API directo desde el panel de WordPress (subida directa de ZIP).',
			'Protección Honeypot integrada y visor de envíos.',
		);
		$net_cons    = array(
			'Límite de 100 GB de ancho de banda al mes en el plan gratuito.',
			'Límite de 100 envíos de formulario al mes en la capa gratuita (gestionado por la purga del plugin).',
		);

		if ( $stats['has_forms'] ) {
			$net_score    += 14;
			$net_reasons[] = 'Detectamos formularios de contacto en tu sitio: Netlify procesa los envíos de forma nativa sin requerir ningún servicio externo.';
		}
		if ( $stats['uploads_size_mb'] > 150 ) {
			$net_score    -= 10;
			$net_reasons[] = sprintf( 'Tu sitio tiene %s MB en medios: vigila el límite de 100 GB/mes de la capa gratuita de Netlify.', $stats['uploads_size_mb'] );
		}
		if ( empty( $net_reasons ) ) {
			$net_reasons[] = 'Ideal para despliegues rápidos en 1 clic y sitios con formularios nativos.';
		}

		$recommendations[] = array(
			'provider'       => 'netlify',
			'name'           => 'Netlify',
			'score'          => min( 98, max( 50, $net_score ) ),
			'badge'          => $stats['has_forms'] ? '✉️ Mejor para Formularios Nativos' : '⚡ 1-Click Binary Deploy',
			'badge_class'    => 'wpsa-badge-forms',
			'reasons'        => $net_reasons,
			'pros'           => $net_pros,
			'cons'           => $net_cons,
			'deploy_methods' => array( '1-Click Binary ZIP Deploy API', 'Netlify Build Hooks', 'Git Sync' ),
		);

		// ========================================================
		// 3. GITHUB PAGES / ACTIONS
		// ========================================================
		$gh_score   = 76;
		$gh_reasons = array();
		$gh_pros    = array(
			'100% integrado con tu flujo de control de versiones Git y repositorios.',
			'Dominio *.github.io gratuito incluido con soporte SSL automático.',
			'Sin costos de servidor ni mantenimiento.',
		);
		$gh_cons    = array(
			'Límite de 1 GB de tamaño por repositorio y 100 GB de transferencia mensual.',
			'Requiere configurar un Personal Access Token (PAT) o workflow de GitHub Actions.',
		);

		if ( $stats['uploads_size_mb'] < 80 ) {
			$gh_score    += 8;
			$gh_reasons[] = 'Tu sitio es ligero y encaja perfectamente en el límite de repositorio de 1 GB de GitHub.';
		}
		if ( empty( $gh_reasons ) ) {
			$gh_reasons[] = 'Excelente opción si prefieres mantener todo el código y despliegue versionado en GitHub.';
		}

		$recommendations[] = array(
			'provider'       => 'github',
			'name'           => 'GitHub Pages & Actions',
			'score'          => min( 90, $gh_score ),
			'badge'          => '🐙 Ideal para Desarrolladores & Git',
			'badge_class'    => 'wpsa-badge-git',
			'reasons'        => $gh_reasons,
			'pros'           => $gh_pros,
			'cons'           => $gh_cons,
			'deploy_methods' => array( 'GitHub Actions (workflow_dispatch)', 'Git Commit / Push API' ),
		);

		// ========================================================
		// 4. RENDER
		// ========================================================
		$ren_score   = 72;
		$ren_reasons = array(
			'Plataforma moderna en la nube con soporte de sitios estáticos gratuitos y Deploy Hooks rápidos.',
		);
		$ren_pros    = array(
			'Despliegue automático vía Deploy Hook HTTP POST.',
			'Certificados SSL automáticos y dominio .onrender.com gratuito.',
		);
		$ren_cons    = array(
			'Límite de 100 GB/mes de ancho de banda gratuito.',
			'Requiere repositorio Git vinculado para los despliegues de Render.',
		);

		$recommendations[] = array(
			'provider'       => 'render',
			'name'           => 'Render',
			'score'          => $ren_score,
			'badge'          => '☁️ Despliegue Estático Moderno',
			'badge_class'    => 'wpsa-badge-modern',
			'reasons'        => $ren_reasons,
			'pros'           => $ren_pros,
			'cons'           => $ren_cons,
			'deploy_methods' => array( 'Render Deploy Hook (HTTP POST)' ),
		);

		// Ordenar recomendaciones por puntuación descendente
		usort(
			$recommendations,
			function( $a, $b ) {
				return $b['score'] - $a['score'];
			}
		);

		// Marcar la opción número 1 como la recomendada
		if ( ! empty( $recommendations[0] ) ) {
			$recommendations[0]['is_recommended'] = true;
		}

		return $recommendations;
	}

	/**
	 * Genera las 3 mejores combinaciones estratégicas de Hosting Gratuito + Servicio de Email/Leads.
	 *
	 * @param array $stats
	 * @param array $recommendations
	 * @return array
	 */
	public function generate_top_combos( $stats, $recommendations = array() ) {
		$combos = array();

		// COMBO 1: Máximo Rendimiento, Tráfico Ilimitado & Email de Dominio
		$combos[] = array(
			'id'             => 'combo_cloudflare_sheets',
			'rank'           => 1,
			'title'          => 'Cloudflare Pages + Email de Dominio (Cloudflare Email Routing) o Sheets',
			'badge'          => '⭐ Opción 1: Máximo Rendimiento, Tráfico Ilimitado & Email de Dominio Gratis',
			'badge_class'    => 'wpsa-badge-best',
			'hosting'        => 'cloudflare',
			'hosting_name'   => 'Cloudflare Pages',
			'form_provider'  => 'google_sheets',
			'form_name'      => 'Cloudflare Email Routing / FormSubmit (o Google Sheets)',
			'description'    => sprintf(
				'La combinación más potente y económica: aprovecha el <strong>ancho de banda 100%% ilimitado</strong> de Cloudflare para tus %s en medios, y el servicio nativo gratuito <strong>Cloudflare Email Routing</strong> para crear correos corporativos (ej. <code>contacto@tudominio.com</code>) reenviados directamente a tu Gmail personal. Puedes recibir formularios directo en tu bandeja vía FormSubmit o guardarlos en Google Sheets.',
				$stats['uploads_formatted']
			),
			'highlights'     => array(
				'Ancho de banda mensual 100% ilimitado (sin cuotas de 100 GB).',
				'Cloudflare Email Routing nativo gratis: crea correos @tudominio.com reenviados a tu Gmail sin pagar Google Workspace.',
				'Alternativas flexibles: formularios directos a tu email con FormSubmit/Web3Forms o base de datos en Google Sheets.',
			),
			'criteria'       => array(
				'hosting' => sprintf( 'Tu sitio tiene %d entradas y %s en medios. Cloudflare ofrece ancho de banda 100%% ilimitado (evita los límites de 100 GB/mes de Netlify o GitHub).', $stats['total_content'], $stats['uploads_formatted'] ),
				'leads'   => 'Cloudflare Email Routing permite reenviar correos corporativos gratis a tu Gmail, compatible con FormSubmit para formularios directos al buzón, o con Google Sheets para recolectar leads en Excel/CSV.',
			),
			'is_top'         => true,
		);

		// COMBO 2: Desarrollador & Automatización Drip-Feed
		$combos[] = array(
			'id'             => 'combo_github_formsubmit',
			'rank'           => 2,
			'title'          => 'GitHub Pages & Actions + FormSubmit',
			'badge'          => '🐙 Opción 2: Desarrollador & Flujo Git Drip-Feed',
			'badge_class'    => 'wpsa-badge-git',
			'hosting'        => 'github',
			'hosting_name'   => 'GitHub Pages & Actions',
			'form_provider'  => 'formsubmit',
			'form_name'      => 'FormSubmit (Directo a tu correo sin registro)',
			'description'    => 'Ideal para control de versiones y automatizaciones: todo el sitio se aloja en GitHub, con soporte para cron de GitHub Actions (Drip-Feed editorial configurable) y formularios enviados directo a tu bandeja de correo.',
			'highlights'     => array(
				'100% integrado con repositorios Git y GitHub Actions.',
				'Formularios sin registro enviados a tu correo inmediatamente.',
				'Soporte nativo para dominios *.github.io o dominio propio con SSL.',
			),
			'criteria'       => array(
				'hosting' => sprintf( 'Sitio de %s apto para repositorios Git (< 1 GB). Despliegues automáticos mediante GitHub Actions y cron diario.', $stats['uploads_formatted'] ),
				'leads'   => 'FormSubmit entrega los contactos directamente a tu email de administración sin requerir registrar cuentas externas ni configurar API keys.',
			),
			'is_top'         => false,
		);

		// COMBO 3: Todo-en-Uno sin Servicios Externos
		$combos[] = array(
			'id'             => 'combo_netlify_native',
			'rank'           => 3,
			'title'          => 'Netlify + Netlify Forms Nativos',
			'badge'          => '⚡ Opción 3: Todo-en-Uno Sin Servicios Externos',
			'badge_class'    => 'wpsa-badge-forms',
			'hosting'        => 'netlify',
			'hosting_name'   => 'Netlify',
			'form_provider'  => 'netlify',
			'form_name'      => 'Netlify Forms (data-netlify="true")',
			'description'    => 'La máxima comodidad para quien no desea crear cuentas externas: subida directa de archivo ZIP desde el panel de WordPress y detección automática de formularios con protección Honeypot y purga automática.',
			'highlights'     => array(
				'Despliegue binario ZIP directo en 1 Clic desde WordPress.',
				'Formularios nativos con Honeypot anti-spam sin scripts externos.',
				'Purga preventiva programada para mantenerse en la capa gratuita.',
			),
			'criteria'       => array(
				'hosting' => 'Subida binaria de ZIP en 1 Clic directamente desde el panel de WordPress sin necesidad de Git ni líneas de comandos.',
				'leads'   => 'Netlify Forms procesa envíos nativamente con data-netlify="true" y bandeja de entrada integrada en el panel de Netlify.',
			),
			'is_top'         => false,
		);

		return $combos;
	}

	/**
	 * Retorna la matriz de compatibilidad bidireccional entre proveedores de Hosting y Formularios/Leads.
	 *
	 * @return array
	 */
	public function get_compatibility_matrix() {
		return array(
			'hosting_to_forms' => array(
				'cloudflare' => array(
					'allowed'      => array( 'google_sheets', 'web3forms', 'formsubmit' ),
					'disallowed'   => array( 'netlify' ),
					'disallow_msg' => 'Netlify Forms requiere alojar el sitio en Netlify para procesar envíos. Para Cloudflare Pages utiliza Google Sheets (Excel CSV), Web3Forms o FormSubmit.',
				),
				'github'     => array(
					'allowed'      => array( 'google_sheets', 'web3forms', 'formsubmit' ),
					'disallowed'   => array( 'netlify' ),
					'disallow_msg' => 'Netlify Forms solo funciona en Netlify. Para GitHub Pages utiliza Google Sheets, Web3Forms o FormSubmit.',
				),
				'render'     => array(
					'allowed'      => array( 'google_sheets', 'web3forms', 'formsubmit' ),
					'disallowed'   => array( 'netlify' ),
					'disallow_msg' => 'Netlify Forms solo funciona en Netlify. Para Render utiliza Google Sheets, Web3Forms o FormSubmit.',
				),
				'netlify'    => array(
					'allowed'      => array( 'netlify', 'google_sheets', 'web3forms', 'formsubmit' ),
					'disallowed'   => array(),
					'disallow_msg' => '',
				),
			),
			'form_to_hostings' => array(
				'netlify'       => array(
					'allowed'      => array( 'netlify' ),
					'disallowed'   => array( 'cloudflare', 'github', 'render' ),
					'disallow_msg' => 'El procesador nativo de Netlify Forms requiere que el hosting sea Netlify.',
				),
				'google_sheets' => array(
					'allowed'      => array( 'cloudflare', 'github', 'render', 'netlify' ),
					'disallowed'   => array(),
					'disallow_msg' => '',
				),
				'web3forms'     => array(
					'allowed'      => array( 'cloudflare', 'github', 'render', 'netlify' ),
					'disallowed'   => array(),
					'disallow_msg' => '',
				),
				'formsubmit'    => array(
					'allowed'      => array( 'cloudflare', 'github', 'render', 'netlify' ),
					'disallowed'   => array(),
					'disallow_msg' => '',
				),
			),
		);
	}

	/**
	 * Análisis Semántico y Editorial Inteligente con la API de Google AI Studio (Gemini).
	 *
	 * Descubre dinámicamente qué modelos están disponibles en la cuenta y capa gratuita
	 * (GET /v1beta/models) para evitar errores 404 por versiones obsoletas o cambiantes.
	 *
	 * @param string $api_key Clave de API de Google AI Studio (Gemini).
	 * @return array
	 */
	public function analyze_with_gemini( $api_key = '' ) {
		if ( empty( $api_key ) ) {
			$api_key = get_option( 'wp_static_arquitect_gemini_api_key', '' );
		}
		if ( empty( $api_key ) ) {
			return array(
				'success' => false,
				'message' => 'Clave de API de Google AI Studio (Gemini) no configurada. Ingrésala en la pestaña "Buscador, SEO & GEO (IAs)".',
			);
		}

		// 1. Descubrir dinámicamente los modelos activos en la cuenta y capa gratuita
		$models_endpoint = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . rawurlencode( $api_key );
		$models_resp     = wp_remote_get(
			$models_endpoint,
			array(
				'timeout'   => 15,
				'sslverify' => false,
			)
		);

		$chosen_model = 'models/gemini-1.5-flash'; // Fallback por defecto

		if ( ! is_wp_error( $models_resp ) && 200 === wp_remote_retrieve_response_code( $models_resp ) ) {
			$models_body = json_decode( wp_remote_retrieve_body( $models_resp ), true );
			if ( ! empty( $models_body['models'] ) && is_array( $models_body['models'] ) ) {
				$available_models = array();
				foreach ( $models_body['models'] as $m ) {
					if ( ! empty( $m['supportedGenerationMethods'] ) && in_array( 'generateContent', $m['supportedGenerationMethods'], true ) ) {
						$available_models[] = $m['name'];
					}
				}

				// Priorizar modelos Flash y de alto rendimiento gratuitos
				$preferred_order = array(
					'gemini-2.0-flash',
					'gemini-1.5-flash',
					'gemini-1.5-pro',
					'gemini-pro',
				);

				$found = false;
				foreach ( $preferred_order as $pref ) {
					foreach ( $available_models as $avail ) {
						if ( false !== strpos( $avail, $pref ) ) {
							$chosen_model = $avail;
							$found        = true;
							break 2;
						}
					}
				}

				if ( ! $found && ! empty( $available_models ) ) {
					$chosen_model = $available_models[0];
				}
			}
		}

		// Limpiar prefijo 'models/' si ya viene incluido
		$clean_model_name = preg_replace( '#^models/#', '', $chosen_model );

		// 2. Recopilar muestra de datos del sitio
		$categories = get_categories( array( 'number' => 8, 'orderby' => 'count', 'order' => 'DESC' ) );
		$cat_names  = array();
		foreach ( $categories as $cat ) {
			$cat_names[] = $cat->name . ' (' . $cat->count . ' entradas)';
		}

		$recent_posts = get_posts( array( 'numberposts' => 10, 'post_status' => 'publish' ) );
		$post_titles  = array();
		foreach ( $recent_posts as $p ) {
			$post_titles[] = $p->post_title;
		}

		$stats = $this->gather_site_stats();

		$prompt = "Eres un arquitecto web senior y estratega de contenido Jamstack. Analiza el siguiente sitio web de WordPress:\n"
			. "- Total de entradas y páginas: {$stats['total_content']}\n"
			. "- Peso en medios: {$stats['uploads_formatted']}\n"
			. "- Categorías principales: " . implode( ', ', $cat_names ) . "\n"
			. "- Títulos de muestra recientes: " . implode( ' | ', $post_titles ) . "\n"
			. "- Formularios detectados: " . ( $stats['has_forms'] ? 'Sí' : 'No' ) . "\n\n"
			. "Responde EXCLUSIVAMENTE un objeto JSON válido (sin bloques markdown de código ```json) con esta estructura exacta:\n"
			. "{\n"
			. '  "niche": "Nombre del nicho detectado",' . "\n"
			. '  "target_audience": "Descripción breve del público objetivo",' . "\n"
			. '  "recommended_cadence": "Número de entradas/día recomendado (ej. 3 a 5) y por qué",' . "\n"
			. '  "hosting_verdict": "Por qué Cloudflare Pages, GitHub o Netlify es mejor para este nicho específico",' . "\n"
			. '  "lead_magnet_idea": "Sugerencia de formulario/recurso descargable en Google Sheets para capturar leads",' . "\n"
			. '  "seo_advice": "Consejo editorial clave para evitar penalizaciones de contenido masivo por IA"' . "\n"
			. "}";

		$endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $clean_model_name ) . ':generateContent?key=' . rawurlencode( $api_key );

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'    => 25,
				'sslverify'  => false,
				'headers'    => array( 'Content-Type' => 'application/json' ),
				'body'       => wp_json_encode(
					array(
						'contents' => array(
							array(
								'parts' => array(
									array( 'text' => $prompt ),
								),
							),
						),
						'generationConfig' => array(
							'temperature'     => 0.2,
							'responseMimeType' => 'application/json',
						),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => 'Error de conexión con Google AI Studio: ' . $response->get_error_message(),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code ) {
			$err_msg = isset( $body['error']['message'] ) ? $body['error']['message'] : sprintf( 'Error HTTP %d de Google AI Studio', $code );
			return array(
				'success' => false,
				'message' => $err_msg,
			);
		}

		$raw_text = '';
		if ( isset( $body['candidates'][0]['content']['parts'][0]['text'] ) ) {
			$raw_text = trim( $body['candidates'][0]['content']['parts'][0]['text'] );
		}

		$parsed = json_decode( $raw_text, true );
		if ( ! is_array( $parsed ) ) {
			// Intentar limpiar posibles backticks
			$clean_json = preg_replace( '/^```json\s*|\s*```$/i', '', $raw_text );
			$parsed     = json_decode( trim( $clean_json ), true );
		}

		if ( ! is_array( $parsed ) ) {
			return array(
				'success'    => true,
				'model_used' => $clean_model_name,
				'raw_text'   => $raw_text,
				'message'    => 'Análisis completado (formato texto).',
			);
		}

		return array(
			'success'    => true,
			'data'       => $parsed,
			'model_used' => $clean_model_name,
			'message'    => sprintf( '¡Análisis editorial completado con éxito mediante Gemini (%s)!', $clean_model_name ),
		);
	}
}

