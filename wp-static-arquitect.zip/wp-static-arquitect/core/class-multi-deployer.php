<?php
/**
 * Gestor Unificado de Despliegue Multi-Hosting Serverless.
 *
 * Administra el despliegue automático y bajo demanda hacia:
 * - Netlify (Direct ZIP API + Build Hooks)
 * - Cloudflare Pages (Deploy Hooks + Direct Upload API)
 * - GitHub Pages / Actions (workflow_dispatch)
 * - Render (Deploy Hooks)
 * - Webhooks Personalizados
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Multi_Deployer {

	/**
	 * Despliega el sitio al proveedor de hosting actualmente configurado.
	 *
	 * @param string $zip_path Ruta al archivo ZIP generado (opcional según el método).
	 * @param string $provider_override Forzar un proveedor específico.
	 * @return array
	 */
	public function deploy( $zip_path = '', $provider_override = '' ) {
		$provider = ! empty( $provider_override ) 
			? $provider_override 
			: get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );

		WP_Static_Arquitect::log( sprintf( 'Iniciando proceso de despliegue hacia proveedor: %s...', strtoupper( $provider ) ), 'info' );

		switch ( $provider ) {
			case 'cloudflare':
				return $this->deploy_to_cloudflare( $zip_path );

			case 'github':
				return $this->deploy_to_github( $zip_path );

			case 'render':
				return $this->deploy_to_render();

			case 'netlify':
			default:
				return $this->deploy_to_netlify( $zip_path );
		}
	}

	/**
	 * Despliegue hacia Cloudflare Pages.
	 * Soporta Deploy Hook (Webhook POST) o Direct Upload API.
	 *
	 * @param string $zip_path
	 * @return array
	 */
	public function deploy_to_cloudflare( $zip_path = '' ) {
		$deploy_hook = trim( (string) get_option( 'wp_static_arquitect_cloudflare_deploy_hook', '' ) );
		$account_id  = trim( (string) get_option( 'wp_static_arquitect_cloudflare_account_id', '' ) );
		$project_name = trim( (string) get_option( 'wp_static_arquitect_cloudflare_project_name', '' ) );
		$api_token   = trim( (string) get_option( 'wp_static_arquitect_cloudflare_api_token', '' ) );

		// Método 1: Cloudflare Deploy Hook (Recomendado y más directo)
		if ( ! empty( $deploy_hook ) ) {
			WP_Static_Arquitect::log( sprintf( 'Disparando Cloudflare Pages Deploy Hook: %s', $deploy_hook ), 'info' );

			$response = wp_remote_post(
				$deploy_hook,
				array(
					'timeout'    => 25,
					'sslverify'  => false,
					'user-agent' => 'WP-Static-Architect/1.0',
					'headers'    => array(
						'Content-Type' => 'application/json',
					),
					'body'       => wp_json_encode( array(
						'trigger'   => 'WP Static Architect Auto-Deploy',
						'timestamp' => current_time( 'c' ),
					) ),
				)
			);

			if ( is_wp_error( $response ) ) {
				$err_msg = 'Error al conectar con Cloudflare Pages Hook: ' . $response->get_error_message();
				WP_Static_Arquitect::log( $err_msg, 'error' );
				return array( 'success' => false, 'provider' => 'cloudflare', 'message' => $err_msg );
			}

			$code = wp_remote_retrieve_response_code( $response );
			if ( $code >= 200 && $code < 300 ) {
				$custom_domain = get_option( 'wp_static_arquitect_custom_domain', '' );
				$live_url      = ! empty( $custom_domain ) ? esc_url( $custom_domain ) : sprintf( 'https://%s.pages.dev', $project_name ? $project_name : 'tu-proyecto' );

				$deploy_info = array(
					'provider'    => 'cloudflare',
					'method'      => 'deploy_hook',
					'state'       => 'triggered',
					'ssl_url'     => $live_url,
					'deployed_at' => current_time( 'Y-m-d H:i:s' ),
				);
				update_option( 'wp_static_arquitect_last_deploy_info', $deploy_info, false );

				WP_Static_Arquitect::log( '¡Cloudflare Pages Deploy Hook disparado con éxito! Compilación iniciada en la red Anycast.', 'success' );
				return array(
					'success'     => true,
					'provider'    => 'cloudflare',
					'message'     => '¡Despliegue a Cloudflare Pages iniciado con éxito!',
					'deploy_info' => $deploy_info,
				);
			}

			$err_msg = sprintf( 'Respuesta HTTP %d de Cloudflare Pages Deploy Hook.', $code );
			WP_Static_Arquitect::log( $err_msg, 'error' );
			return array( 'success' => false, 'provider' => 'cloudflare', 'message' => $err_msg );
		}

		// Método 2: Cloudflare Pages Direct API (si se proporcionan credenciales API)
		if ( ! empty( $account_id ) && ! empty( $project_name ) && ! empty( $api_token ) ) {
			WP_Static_Arquitect::log( sprintf( 'Iniciando despliegue directo a Cloudflare Pages API: Proyecto %s...', $project_name ), 'info' );

			$api_url = sprintf(
				'https://api.cloudflare.com/client/v4/accounts/%s/pages/projects/%s/deployments',
				rawurlencode( $account_id ),
				rawurlencode( $project_name )
			);

			$response = wp_remote_post(
				$api_url,
				array(
					'timeout'    => 45,
					'sslverify'  => false,
					'user-agent' => 'WP-Static-Architect/1.0',
					'headers'    => array(
						'Authorization' => 'Bearer ' . $api_token,
						'Content-Type'  => 'application/json',
					),
				)
			);

			if ( is_wp_error( $response ) ) {
				return array( 'success' => false, 'provider' => 'cloudflare', 'message' => $response->get_error_message() );
			}

			$code = wp_remote_retrieve_response_code( $response );
			$body = json_decode( wp_remote_retrieve_body( $response ), true );

			if ( 200 === $code || 201 === $code ) {
				$dep_data = isset( $body['result'] ) ? $body['result'] : array();
				$site_url = isset( $dep_data['url'] ) ? $dep_data['url'] : sprintf( 'https://%s.pages.dev', $project_name );

				$deploy_info = array(
					'provider'    => 'cloudflare',
					'method'      => 'api',
					'deploy_id'   => isset( $dep_data['id'] ) ? $dep_data['id'] : '',
					'state'       => isset( $dep_data['latest_stage']['status'] ) ? $dep_data['latest_stage']['status'] : 'active',
					'ssl_url'     => $site_url,
					'deployed_at' => current_time( 'Y-m-d H:i:s' ),
				);
				update_option( 'wp_static_arquitect_last_deploy_info', $deploy_info, false );

				return array(
					'success'     => true,
					'provider'    => 'cloudflare',
					'message'     => '¡Despliegue a Cloudflare Pages completado con éxito!',
					'deploy_info' => $deploy_info,
				);
			}

			$err_desc = ! empty( $body['errors'][0]['message'] ) ? $body['errors'][0]['message'] : sprintf( 'Error HTTP %d', $code );
			return array( 'success' => false, 'provider' => 'cloudflare', 'message' => 'Cloudflare API: ' . $err_desc );
		}

		return array(
			'success'  => false,
			'provider' => 'cloudflare',
			'message'  => 'No se han configurado el Deploy Hook ni las credenciales API de Cloudflare Pages. Por favor ingresa el Deploy Hook en la pestaña "Hosting, Dominio & APIs".',
		);
	}

	/**
	 * Despliegue hacia GitHub Pages / GitHub Actions.
	 * Dispara un workflow_dispatch o repository_dispatch.
	 *
	 * @param string $zip_path
	 * @param string $token_override
	 * @param string $repo_override
	 * @param string $branch_override
	 * @param string $workflow_override
	 * @return array
	 */
	public function deploy_to_github( $zip_path = '', $token_override = '', $repo_override = '', $branch_override = '', $workflow_override = '' ) {
		$token    = ! empty( $token_override ) ? $token_override : trim( (string) get_option( 'wp_static_arquitect_github_token', '' ) );
		$repo     = ! empty( $repo_override ) ? $repo_override : trim( (string) get_option( 'wp_static_arquitect_github_repo', '' ) );
		$branch   = ! empty( $branch_override ) ? $branch_override : trim( (string) get_option( 'wp_static_arquitect_github_branch', 'main' ) );
		$workflow = ! empty( $workflow_override ) ? $workflow_override : trim( (string) get_option( 'wp_static_arquitect_github_workflow', 'deploy.yml' ) );

		if ( empty( $token ) || empty( $repo ) ) {
			return array(
				'success'  => false,
				'provider' => 'github',
				'message'  => 'Credenciales de GitHub incompletas. Configura el Token Personal (PAT) y el repositorio (usuario/repo) en los ajustes.',
			);
		}

		WP_Static_Arquitect::log( sprintf( 'Disparando GitHub Actions workflow_dispatch en %s (rama: %s)...', $repo, $branch ), 'info' );

		// Endpoint de workflow dispatch
		$url = sprintf(
			'https://api.github.com/repos/%s/actions/workflows/%s/dispatches',
			trim( $repo, '/' ),
			rawurlencode( $workflow )
		);

		$response = wp_remote_post(
			$url,
			array(
				'timeout'    => 25,
				'sslverify'  => false,
				'user-agent' => 'WP-Static-Architect/1.0',
				'headers'    => array(
					'Authorization' => 'Bearer ' . $token,
					'Accept'        => 'application/vnd.github.v3+json',
					'Content-Type'  => 'application/json',
				),
				'body'       => wp_json_encode( array(
					'ref'    => $branch,
					'inputs' => array(
						'trigger' => 'WP Static Architect Auto-Deploy',
					),
				) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'provider' => 'github', 'message' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		// 204 No Content indica éxito en GitHub workflow_dispatch
		if ( 204 === $code || 200 === $code ) {
			$repo_parts = explode( '/', trim( $repo, '/' ) );
			$owner      = isset( $repo_parts[0] ) ? $repo_parts[0] : '';
			$reponame   = isset( $repo_parts[1] ) ? $repo_parts[1] : '';
			$gh_pages_url = sprintf( 'https://%s.github.io/%s/', strtolower( $owner ), strtolower( $reponame ) );

			$deploy_info = array(
				'provider'    => 'github',
				'state'       => 'dispatched',
				'ssl_url'     => $gh_pages_url,
				'deployed_at' => current_time( 'Y-m-d H:i:s' ),
			);
			update_option( 'wp_static_arquitect_last_deploy_info', $deploy_info, false );

			WP_Static_Arquitect::log( '¡GitHub Actions workflow disparado con éxito!', 'success' );
			return array(
				'success'     => true,
				'provider'    => 'github',
				'message'     => '¡Despliegue a GitHub Pages / Actions iniciado con éxito!',
				'deploy_info' => $deploy_info,
			);
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$err_msg = isset( $body['message'] ) ? $body['message'] : sprintf( 'Error HTTP %d de GitHub API', $code );
		return array( 'success' => false, 'provider' => 'github', 'message' => $err_msg );
	}

	/**
	 * Despliegue hacia Render.
	 * Dispara el Deploy Hook de Render (HTTP POST).
	 *
	 * @return array
	 */
	public function deploy_to_render() {
		$hook_url = trim( (string) get_option( 'wp_static_arquitect_render_deploy_hook', '' ) );

		if ( empty( $hook_url ) ) {
			return array(
				'success'  => false,
				'provider' => 'render',
				'message'  => 'No se ha configurado la URL del Deploy Hook de Render.',
			);
		}

		WP_Static_Arquitect::log( sprintf( 'Disparando Render Deploy Hook: %s', $hook_url ), 'info' );

		$response = wp_remote_post(
			$hook_url,
			array(
				'timeout'    => 25,
				'sslverify'  => false,
				'user-agent' => 'WP-Static-Architect/1.0',
			)
		);

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'provider' => 'render', 'message' => $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			$deploy_info = array(
				'provider'    => 'render',
				'state'       => 'triggered',
				'ssl_url'     => get_option( 'wp_static_arquitect_custom_domain', '' ),
				'deployed_at' => current_time( 'Y-m-d H:i:s' ),
			);
			update_option( 'wp_static_arquitect_last_deploy_info', $deploy_info, false );

			WP_Static_Arquitect::log( '¡Render Deploy Hook activado con éxito!', 'success' );
			return array(
				'success'     => true,
				'provider'    => 'render',
				'message'     => '¡Despliegue a Render activado con éxito!',
				'deploy_info' => $deploy_info,
			);
		}

		return array(
			'success'  => false,
			'provider' => 'render',
			'message'  => sprintf( 'Respuesta HTTP %d de Render Deploy Hook.', $code ),
		);
	}

	/**
	 * Despliegue hacia Netlify (Binary ZIP Deploy o Build Hook).
	 *
	 * @param string $zip_path
	 * @return array
	 */
	public function deploy_to_netlify( $zip_path = '' ) {
		$netlify_module = WP_Static_Arquitect::get_instance()->netlify_forms;

		// 1. Si hay archivo ZIP y credenciales de Netlify (PAT + Site ID), despliegue binario directo
		if ( ! empty( $zip_path ) && file_exists( $zip_path ) ) {
			$creds = $netlify_module->get_credentials();
			if ( ! empty( $creds['pat'] ) && ! empty( $creds['site_id'] ) ) {
				$res = $netlify_module->deploy_zip( $zip_path );
				$res['provider'] = 'netlify';
				return $res;
			}
		}

		// 2. Si hay un Build Hook configurado, dispararlo
		$build_hook = get_option( 'wp_static_arquitect_netlify_build_hook', '' );
		if ( ! empty( $build_hook ) ) {
			$res = $netlify_module->trigger_build_hook( $build_hook );
			$res['provider'] = 'netlify';
			return $res;
		}

		return array(
			'success'  => false,
			'provider' => 'netlify',
			'message'  => 'Credenciales de Netlify (PAT + Site ID o Build Hook) no configuradas.',
		);
	}
}
