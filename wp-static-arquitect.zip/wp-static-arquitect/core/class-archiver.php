<?php
/**
 * Empaquetador final en formato .ZIP para distribución y despliegue.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Archiver {

	/**
	 * Número de exports antiguos a conservar (ampliado a 20 para Modo Creador Pro).
	 */
	const MAX_RETAINED_EXPORTS = 20;

	/**
	 * Comprime un directorio completo en un archivo .zip con aceleración de alto rendimiento.
	 *
	 * @param string $source_dir Carpeta origen a comprimir.
	 * @param string $zip_name   Nombre deseado para el archivo ZIP.
	 * @return array Resultado con rutas, tamaño y hash.
	 */
	public function create_archive( $source_dir, $zip_name = '' ) {
		@set_time_limit( 300 );
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}

		$source_dir = wp_normalize_path( untrailingslashit( $source_dir ) );
		if ( ! is_dir( $source_dir ) ) {
			return array(
				'success' => false,
				'message' => 'El directorio origen especificado no existe o no es accesible.',
			);
		}

		$exports_dir = WP_Static_Arquitect::get_upload_dir( 'exports' );
		if ( empty( $zip_name ) ) {
			$zip_name = 'static-site-' . current_time( 'Y-m-d-His' ) . '.zip';
		}

		$target_zip_path = trailingslashit( $exports_dir ) . $zip_name;
		$target_zip_url  = WP_Static_Arquitect::get_upload_url( 'exports/' . $zip_name );

		// 1. Intentar compresión nativa ultrarrápida con ZipArchive
		if ( class_exists( 'ZipArchive' ) ) {
			$res = $this->create_archive_ziparchive( $source_dir, $target_zip_path, $zip_name, $target_zip_url, $exports_dir );
			if ( $res['success'] ) {
				return $res;
			}
			WP_Static_Arquitect::log( 'Aviso: ZipArchive reportó un fallo, intentando fallback con PclZip: ' . $res['message'], 'warning' );
		}

		// 2. Fallback de respaldo con PclZip de WordPress Core
		return $this->create_archive_pclzip( $source_dir, $target_zip_path, $zip_name, $target_zip_url, $exports_dir );
	}

	/**
	 * Crea el archivo ZIP utilizando la extensión nativa ZipArchive optimizada.
	 *
	 * @param string $source_dir
	 * @param string $target_zip_path
	 * @param string $zip_name
	 * @param string $target_zip_url
	 * @param string $exports_dir
	 * @return array
	 */
	private function create_archive_ziparchive( $source_dir, $target_zip_path, $zip_name, $target_zip_url, $exports_dir ) {
		try {
			$zip = new ZipArchive();
			$open_status = $zip->open( $target_zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE );

			if ( true !== $open_status ) {
				return array(
					'success' => false,
					'message' => sprintf( 'No se pudo inicializar el archivo ZIP. Código de estado: %d', $open_status ),
				);
			}

			$directory_iterator = new RecursiveDirectoryIterator( $source_dir, RecursiveDirectoryIterator::SKIP_DOTS );
			$files              = new RecursiveIteratorIterator( $directory_iterator, RecursiveIteratorIterator::LEAVES_ONLY );

			// Extensiones ya comprimidas por naturaleza: no gastar ciclos de CPU recomprimiéndolas
			$no_compress_exts = array(
				'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'ico',
				'woff', 'woff2', 'ttf', 'eot', 'otf',
				'mp4', 'webm', 'mp3', 'ogg', 'wav', 'flac',
				'zip', 'gz', 'tar', 'tgz', 'rar', '7z',
				'pdf', 'doc', 'docx'
			);

			$files_count = 0;

			foreach ( $files as $file ) {
				if ( ! $file->isDir() ) {
					// Obtener la sub-ruta relativa directamente del iterador (100% inmune a symlinks y diferencias de volumen en Pantheon)
					$relative_path = wp_normalize_path( $files->getSubPathname() );
					$relative_path = ltrim( $relative_path, '/' );

					if ( empty( $relative_path ) ) {
						continue;
					}

					$index     = $files_count;
					$file_path = wp_normalize_path( $file->getPathname() );
					$zip->addFile( $file_path, $relative_path );

					// Aceleración de compresión O(1) usando índice directo
					$ext = strtolower( pathinfo( $relative_path, PATHINFO_EXTENSION ) );
					if ( in_array( $ext, $no_compress_exts, true ) && method_exists( $zip, 'setCompressionIndex' ) ) {
						$zip->setCompressionIndex( $index, ZipArchive::CM_STORE );
					}

					$files_count++;
				}
			}

			$zip->close();

			if ( ! file_exists( $target_zip_path ) || filesize( $target_zip_path ) === 0 ) {
				return array(
					'success' => false,
					'message' => 'Falló el guardado del archivo ZIP en el disco.',
				);
			}

			return $this->finalize_archive_metadata( $target_zip_path, $zip_name, $target_zip_url, $files_count, $exports_dir );

		} catch ( Throwable $e ) {
			WP_Static_Arquitect::log( 'Excepción capturada en ZipArchive: ' . $e->getMessage(), 'error' );
			return array(
				'success' => false,
				'message' => 'Error durante el empaquetado ZIP: ' . $e->getMessage(),
			);
		}
	}

	/**
	 * Fallback utilizando la biblioteca PclZip de WordPress en caso de fallo de ZipArchive.
	 *
	 * @param string $source_dir
	 * @param string $target_zip_path
	 * @param string $zip_name
	 * @param string $target_zip_url
	 * @param string $exports_dir
	 * @return array
	 */
	private function create_archive_pclzip( $source_dir, $target_zip_path, $zip_name, $target_zip_url, $exports_dir ) {
		if ( ! defined( 'PCLZIP_TEMPORARY_DIR' ) ) {
			define( 'PCLZIP_TEMPORARY_DIR', WP_Static_Arquitect::get_upload_dir( 'temp' ) );
		}
		require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';

		$archive = new PclZip( $target_zip_path );
		$v_list  = $archive->create( $source_dir, PCLZIP_OPT_REMOVE_PATH, $source_dir );

		if ( 0 === $v_list ) {
			return array(
				'success' => false,
				'message' => 'Error en PclZip: ' . $archive->errorInfo( true ),
			);
		}

		$files_count = is_array( $v_list ) ? count( $v_list ) : 1;
		return $this->finalize_archive_metadata( $target_zip_path, $zip_name, $target_zip_url, $files_count, $exports_dir );
	}

	/**
	 * Registra metadatos, rotación y log del paquete generado.
	 *
	 * @param string $target_zip_path
	 * @param string $zip_name
	 * @param string $target_zip_url
	 * @param int    $files_count
	 * @param string $exports_dir
	 * @return array
	 */
	private function finalize_archive_metadata( $target_zip_path, $zip_name, $target_zip_url, $files_count, $exports_dir ) {
		$file_size = filesize( $target_zip_path );
		$sha256    = hash_file( 'sha256', $target_zip_path );

		// Rotación de archivos antiguos
		$this->rotate_old_archives( $exports_dir );

		// Guardar info del último export
		$export_info = array(
			'file_name'   => $zip_name,
			'file_path'   => $target_zip_path,
			'file_url'    => $target_zip_url,
			'file_size'   => size_format( $file_size, 2 ),
			'bytes'       => $file_size,
			'sha256'      => $sha256 ? $sha256 : 'N/A',
			'files_count' => $files_count,
			'created_at'  => current_time( 'Y-m-d H:i:s' ),
		);

		update_option( 'wp_static_arquitect_last_export_info', $export_info, false );

		WP_Static_Arquitect::log(
			sprintf(
				'Archivo ZIP generado con éxito: %s (%s, %d archivos). SHA256: %s',
				$zip_name,
				$export_info['file_size'],
				$files_count,
				substr( (string) $sha256, 0, 12 ) . '...'
			),
			'success'
		);

		return array(
			'success' => true,
			'data'    => $export_info,
		);
	}

	/**
	 * Mantiene únicamente los últimos archivos comprimidos para no agotar espacio en disco.
	 *
	 * @param string $exports_dir
	 */
	private function rotate_old_archives( $exports_dir ) {
		$zip_files = glob( trailingslashit( $exports_dir ) . '*.zip' );
		if ( ! $zip_files || count( $zip_files ) <= self::MAX_RETAINED_EXPORTS ) {
			return;
		}

		// Ordenar por fecha de modificación, más recientes primero
		usort(
			$zip_files,
			function( $a, $b ) {
				return filemtime( $b ) - filemtime( $a );
			}
		);

		$files_to_remove = array_slice( $zip_files, self::MAX_RETAINED_EXPORTS );
		foreach ( $files_to_remove as $old_file ) {
			@unlink( $old_file );
		}
	}
}

