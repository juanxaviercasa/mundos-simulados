<?php
/**
 * Analizador DOM y transformador de código HTML para despliegue estático.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_HTML_Parser {

	/**
	 * URL base del sitio WordPress.
	 *
	 * @var string
	 */
	private $site_url;

	/**
	 * Modo de URL ('root-relative' por defecto o 'relative').
	 *
	 * @var string
	 */
	private $url_mode;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->site_url = trailingslashit( home_url() );
		$this->url_mode = get_option( 'wp_static_arquitect_url_mode', 'root-relative' );
	}

	/**
	 * Procesa y transforma el contenido HTML completo de una página.
	 *
	 * @param string $html        Código HTML sin procesar.
	 * @param string $current_url URL actual de la página siendo procesada.
	 * @param string $site_url    URL raíz de WordPress.
	 * @return string Código HTML transformado y listo para producción estática.
	 */
	public function process_html( $html, $current_url, $site_url ) {
		if ( empty( $html ) ) {
			return $html;
		}

		// Obtener slug de la página actual para los comentarios
		$post_slug = $this->extract_post_slug( $current_url );

		// Uso de DOMDocument con encoding UTF-8 preservado
		$dom = new DOMDocument();
		libxml_use_internal_errors( true );

		// Prevenir problemas de charset inyectando meta si no existe
		$encoded_html = mb_encode_numericentity( $html, array( 0x80, 0x10FFFF, 0, 0x1FFFFF ), 'UTF-8' );
		$dom->loadHTML( $encoded_html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		$xpath = new DOMXPath( $dom );

		// 1. Eliminar artefactos dinámicos y cabeceras de WordPress
		$this->remove_wp_artifacts( $xpath, $dom );

		// 2. Inyección de formularios de Netlify (si está habilitado)
		$enable_forms   = '0' !== get_option( 'wp_static_arquitect_enable_forms', '1' );
		$netlify_module = WP_Static_Arquitect::get_instance()->netlify_forms;
		if ( $enable_forms && $netlify_module ) {
			$netlify_module->transform_forms( $xpath, $dom, $post_slug );
		}

		// 3. Inyección del sistema de comentarios de Supabase (si está habilitado)
		$enable_comments = '0' !== get_option( 'wp_static_arquitect_enable_comments', '1' );
		if ( $enable_comments ) {
			$supabase_module = WP_Static_Arquitect::get_instance()->supabase_comments;
			if ( $supabase_module ) {
				$supabase_module->inject_comments_section( $xpath, $dom, $post_slug, $current_url );
			}
		} else {
			// Si los comentarios están deshabilitados, eliminar cualquier sección de comentarios remanente en el DOM
			$comment_selectors = array(
				"//*[@id='comments']",
				"//*[contains(@class, 'comments-area')]",
				"//*[@id='respond']",
				"//*[contains(@class, 'comment-respond')]",
			);
			foreach ( $comment_selectors as $sel ) {
				$nodes = $xpath->query( $sel );
				if ( $nodes ) {
					foreach ( $nodes as $node ) {
						$node->parentNode->removeChild( $node );
					}
				}
			}
		}

		// 3.1 Inyección del buscador estático instantáneo
		$this->inject_search_modal( $xpath, $dom, $current_url );

		// 3.2 Inyección de datos estructurados para Motores de IA (GEO)
		$this->inject_geo_structured_data( $xpath, $dom, $current_url, $post_slug );

		// 4. Reescribir URLs absolutas a relativas o root-relative
		$this->rewrite_internal_links( $xpath, $dom, $current_url );

		// Guardar HTML resultante
		$output = $dom->saveHTML();

		// Limpieza de caracteres numéricos de vuelta a UTF-8
		$output = mb_decode_numericentity( $output, array( 0x80, 0x10FFFF, 0, 0x1FFFFF ), 'UTF-8' );

		return $output;
	}

	/**
	 * Extrae el identificador slug de una URL para indexar comentarios.
	 *
	 * @param string $url
	 * @return string
	 */
	public function extract_post_slug( $url ) {
		$path = wp_parse_url( $url, PHP_URL_PATH );
		$slug = trim( (string) $path, '/' );

		if ( empty( $slug ) ) {
			return 'home';
		}

		// Si tiene múltiples niveles, sustituir barras por guiones o mantener último segmento
		$parts = explode( '/', $slug );
		return sanitize_title( end( $parts ) );
	}

	/**
	 * Elimina scripts y etiquetas no necesarios o incompatibles con un sitio estático.
	 *
	 * @param DOMXPath    $xpath
	 * @param DOMDocument $dom
	 */
	private function remove_wp_artifacts( $xpath, $dom ) {
		// 1. Enlaces a la API REST (wp-json) y metadatos dinámicos en <head>
		$selectors = array(
			"//link[@rel='https://api.w.org/']",
			"//link[@rel='EditURI']",
			"//link[@rel='wlwmanifest']",
			"//link[@rel='shortlink']",
			"//meta[@name='generator']",
			"//script[contains(@src, 'comment-reply')]",
			"//div[@id='wpadminbar']",
			"//style[@id='wp-admin-bar-css']",
		);

		foreach ( $selectors as $selector ) {
			$nodes = $xpath->query( $selector );
			if ( $nodes ) {
				foreach ( $nodes as $node ) {
					$node->parentNode->removeChild( $node );
				}
			}
		}
	}

	/**
	 * Reescribe todos los enlaces internos y fuentes de recursos.
	 *
	 * @param DOMXPath    $xpath
	 * @param DOMDocument $dom
	 * @param string      $current_url
	 */
	private function rewrite_internal_links( $xpath, $dom, $current_url ) {
		$base_url_trimmed = rtrim( $this->site_url, '/' );

		// Atributos a verificar: href, src, action
		$attributes = array(
			'//a[@href]'      => 'href',
			'//link[@href]'   => 'href',
			'//img[@src]'     => 'src',
			'//script[@src]'  => 'src',
			'//source[@src]'  => 'src',
			'//audio[@src]'   => 'src',
			'//video[@src]'   => 'src',
		);

		foreach ( $attributes as $query => $attr_name ) {
			$elements = $xpath->query( $query );
			if ( ! $elements ) {
				continue;
			}

			foreach ( $elements as $element ) {
				$val = $element->getAttribute( $attr_name );
				if ( empty( $val ) || 0 === strpos( $val, '#' ) || 0 === strpos( $val, 'data:' ) || 0 === strpos( $val, 'javascript:' ) ) {
					continue;
				}

				// Solo reescribir si coincide con la URL del sitio
				if ( 0 === strpos( $val, $base_url_trimmed ) ) {
					$relative = substr( $val, strlen( $base_url_trimmed ) );
					if ( empty( $relative ) ) {
						$relative = '/';
					}

					if ( 'relative' === $this->url_mode ) {
						// Convertir a relativo estricto según la profundidad de la URL actual
						$computed = $this->calculate_relative_depth_path( $current_url, $relative );
						$element->setAttribute( $attr_name, $computed );
					} else {
						// Modo root-relative (recomendado para Netlify, GitHub Pages, Vercel)
						$element->setAttribute( $attr_name, $relative );
					}
				}
			}
		}

		// Limpiar parámetros dinámicos de versiones en CSS y JS (ej. ?ver=6.4)
		$asset_links = $xpath->query( "//link[@rel='stylesheet'] | //script[@src]" );
		if ( $asset_links ) {
			foreach ( $asset_links as $link ) {
				$attr = $link->hasAttribute( 'href' ) ? 'href' : 'src';
				$url  = $link->getAttribute( $attr );
				if ( strpos( $url, '?ver=' ) !== false ) {
					$clean_url = preg_replace( '/\?ver=[^&"\']*/i', '', $url );
					$link->setAttribute( $attr, $clean_url );
				}
			}
		}
	}

	/**
	 * Calcula la ruta relativa basada en la profundidad de la URL actual.
	 *
	 * @param string $current_url URL de la página que contiene el enlace.
	 * @param string $target_path Ruta destino con respecto a la raíz (ej. '/blog/post-1/').
	 * @return string Ruta relativa (ej. '../../blog/post-1/index.html').
	 */
	private function calculate_relative_depth_path( $current_url, $target_path ) {
		$current_path = wp_parse_url( $current_url, PHP_URL_PATH );
		$current_path = trim( (string) $current_path, '/' );

		$depth = empty( $current_path ) ? 0 : count( explode( '/', $current_path ) );

		$prefix = '';
		for ( $i = 0; $i < $depth; $i++ ) {
			$prefix .= '../';
		}

		if ( empty( $prefix ) ) {
			$prefix = './';
		}

		return $prefix . ltrim( $target_path, '/' );
	}

	/**
	 * Inyecta el modal y recursos del buscador estático instantáneo en el DOM.
	 *
	 * @param DOMXPath    $xpath
	 * @param DOMDocument $dom
	 * @param string      $current_url URL de la página actual.
	 */
	public function inject_search_modal( $xpath, $dom, $current_url ) {
		$enable_search = '0' !== get_option( 'wp_static_arquitect_enable_search', '1' );
		if ( ! $enable_search ) {
			return;
		}

		$body = $dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			return;
		}

		// Asignar atributo con la raíz para el buscador en modo relativo
		$root_path = '/';
		if ( 'relative' === $this->url_mode ) {
			$root_path = $this->calculate_relative_depth_path( $current_url, '/' );
		}
		$body->setAttribute( 'data-wpsa-root', $root_path );

		$template_path = WP_STATIC_ARQUITECT_PATH . 'templates/search-modal.html';
		if ( ! file_exists( $template_path ) ) {
			return;
		}

		$search_html = file_get_contents( $template_path );
		if ( empty( $search_html ) ) {
			return;
		}

		// Importar nodos del modal de búsqueda
		$search_doc = new DOMDocument();
		libxml_use_internal_errors( true );
		$encoded = mb_encode_numericentity( $search_html, array( 0x80, 0x10FFFF, 0, 0x1FFFFF ), 'UTF-8' );
		$search_doc->loadHTML( $encoded, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
		libxml_clear_errors();

		if ( $search_doc->hasChildNodes() ) {
			foreach ( $search_doc->childNodes as $child ) {
				$imported = $dom->importNode( $child, true );
				$body->appendChild( $imported );
			}
		}

		// Inyectar CSS en <head>
		$head = $dom->getElementsByTagName( 'head' )->item( 0 );
		if ( $head ) {
			$link = $dom->createElement( 'link' );
			$link->setAttribute( 'rel', 'stylesheet' );
			$css_url = 'relative' === $this->url_mode
				? $this->calculate_relative_depth_path( $current_url, '/wp-static-arquitect-assets/search-modal.css' )
				: '/wp-static-arquitect-assets/search-modal.css';
			$link->setAttribute( 'href', $css_url );
			$head->appendChild( $link );
		}

		// Inyectar JS al final de <body>
		$script = $dom->createElement( 'script' );
		$js_url = 'relative' === $this->url_mode
			? $this->calculate_relative_depth_path( $current_url, '/wp-static-arquitect-assets/search-client.js' )
			: '/wp-static-arquitect-assets/search-client.js';
		$script->setAttribute( 'src', $js_url );
		$script->setAttribute( 'defer', 'defer' );
		$body->appendChild( $script );
	}

	/**
	 * Inyecta microdatos Schema.org JSON-LD para motores de búsqueda de IA (GEO).
	 *
	 * @param DOMXPath    $xpath
	 * @param DOMDocument $dom
	 * @param string      $current_url
	 * @param string      $post_slug
	 */
	private function inject_geo_structured_data( $xpath, $dom, $current_url, $post_slug ) {
		$enable_geo = '0' !== get_option( 'wp_static_arquitect_enable_geo', '1' );
		if ( ! $enable_geo ) {
			return;
		}

		$head = $dom->getElementsByTagName( 'head' )->item( 0 );
		if ( ! $head ) {
			return;
		}

		// Obtener título y descripción
		$title_nodes = $xpath->query( '//title' );
		$page_title  = ( $title_nodes && $title_nodes->length > 0 ) ? trim( $title_nodes->item( 0 )->textContent ) : get_bloginfo( 'name' );

		$desc_nodes = $xpath->query( "//meta[@name='description']/@content" );
		$page_desc  = ( $desc_nodes && $desc_nodes->length > 0 ) ? trim( $desc_nodes->item( 0 )->nodeValue ) : get_bloginfo( 'description' );

		// Determinar URL canónica
		$custom_domain  = get_option( 'wp_static_arquitect_custom_domain', '' );
		$prod_url       = get_option( 'wp_static_arquitect_production_url', '' );
		$base_canonical = ! empty( $custom_domain ) ? 'https://' . preg_replace( '#^https?://#', '', rtrim( $custom_domain, '/' ) ) : ( ! empty( $prod_url ) ? untrailingslashit( $prod_url ) : untrailingslashit( home_url() ) );

		$canonical_url = $base_canonical . ( 'home' === $post_slug ? '/' : '/' . $post_slug . '/' );
		$is_home       = ( 'home' === $post_slug || '/' === wp_parse_url( $current_url, PHP_URL_PATH ) );

		if ( $is_home ) {
			$schema = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'WebSite',
				'name'        => get_bloginfo( 'name' ),
				'url'         => $base_canonical . '/',
				'description' => $page_desc,
				'publisher'   => array(
					'@type' => 'Organization',
					'name'  => get_bloginfo( 'name' ),
					'url'   => $base_canonical . '/',
				),
			);
		} else {
			$schema = array(
				'@context'         => 'https://schema.org',
				'@type'            => 'Article',
				'headline'         => $page_title,
				'description'      => $page_desc,
				'mainEntityOfPage' => array(
					'@type' => 'WebPage',
					'@id'   => $canonical_url,
				),
				'publisher'        => array(
					'@type' => 'Organization',
					'name'  => get_bloginfo( 'name' ),
					'url'   => $base_canonical . '/',
				),
			);
		}

		// Crear elemento script json-ld
		$script = $dom->createElement( 'script' );
		$script->setAttribute( 'type', 'application/ld+json' );
		$script->appendChild( $dom->createTextNode( wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) ) );
		$head->appendChild( $script );

		// Añadir o actualizar enlace canónico si se configuró dominio personalizado
		if ( ! empty( $custom_domain ) || ! empty( $prod_url ) ) {
			$canonical_nodes = $xpath->query( "//link[@rel='canonical']" );
			if ( $canonical_nodes && $canonical_nodes->length > 0 ) {
				$canonical_nodes->item( 0 )->setAttribute( 'href', $canonical_url );
			} else {
				$canon_link = $dom->createElement( 'link' );
				$canon_link->setAttribute( 'rel', 'canonical' );
				$canon_link->setAttribute( 'href', $canonical_url );
				$head->appendChild( $canon_link );
			}
		}
	}
}
