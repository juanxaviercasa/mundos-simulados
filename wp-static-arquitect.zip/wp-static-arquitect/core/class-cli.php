<?php
/**
 * Integración con WP-CLI para WP Static Architect.
 *
 * Permite ejecutar exportaciones estáticas, verificar estados y gestionar purgas
 * desde la línea de comandos en entornos headless, servidores y pipelines CI/CD.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
	return;
}

/**
 * Comandos WP-CLI para WP Static Architect.
 */
class WP_Static_Arquitect_CLI_Command {

	/**
	 * Ejecuta una exportación estática completa del sitio WordPress.
	 *
	 * ## OPCIONES
	 *
	 * [--deploy]
	 * : Despliega automáticamente a Netlify al finalizar si las credenciales están configuradas.
	 *
	 * [--provider=<provider>]
	 * : Sobrescribe el proveedor de hosting ('netlify', 'cloudflare', 'vercel', 'github', 'custom').
	 *
	 * ## EJEMPLOS
	 *
	 *     wp static-architect export
	 *     wp static-architect export --deploy
	 *     wp static-architect export --provider=cloudflare
	 *
	 * @param array $args
	 * @param array $assoc_args
	 */
	public function export( $args, $assoc_args ) {
		WP_CLI::line( WP_CLI::colorize( '%G[WP Static Architect]%n Iniciando exportación estática por consola...' ) );

		$main    = WP_Static_Arquitect::get_instance();
		$crawler = $main->crawler;

		// Sobrescribir hosting provider si se especifica
		if ( ! empty( $assoc_args['provider'] ) ) {
			$valid_providers = array( 'netlify', 'cloudflare', 'vercel', 'github', 'custom' );
			if ( in_array( $assoc_args['provider'], $valid_providers, true ) ) {
				update_option( 'wp_static_arquitect_hosting_provider', sanitize_text_field( $assoc_args['provider'] ) );
				WP_CLI::line( sprintf( 'Destino de hosting temporal fijado a: %s', $assoc_args['provider'] ) );
			}
		}

		$start_time = microtime( true );
		$result     = $crawler->run();

		if ( is_wp_error( $result ) ) {
			WP_CLI::error( 'Error durante la exportación: ' . $result->get_error_message() );
		}

		$elapsed = round( microtime( true ) - $start_time, 2 );

		WP_CLI::success( sprintf( 'Exportación completada en %s segundos.', $elapsed ) );
		WP_CLI::line( sprintf( 'Archivo ZIP: %s', $result['file_path'] ) );
		WP_CLI::line( sprintf( 'Tamaño: %s (%d archivos)', $result['file_size'], $result['files_count'] ) );
		WP_CLI::line( sprintf( 'SHA-256: %s', $result['sha256'] ) );

		// Auto-deploy si se solicita
		if ( isset( $assoc_args['deploy'] ) ) {
			WP_CLI::line( 'Iniciando despliegue directo a Netlify...' );
			$deploy_result = $main->netlify_forms->deploy_zip( $result['file_path'] );
			if ( is_wp_error( $deploy_result ) ) {
				WP_CLI::warning( 'Error en el despliegue: ' . $deploy_result->get_error_message() );
			} else {
				WP_CLI::success( sprintf( 'Sitio desplegado con éxito en Netlify: %s', $deploy_result['ssl_url'] ) );
			}
		}
	}

	/**
	 * Muestra el estado del sistema, diagnóstico y último paquete generado.
	 *
	 * ## EJEMPLOS
	 *
	 *     wp static-architect status
	 *
	 * @param array $args
	 * @param array $assoc_args
	 */
	public function status( $args, $assoc_args ) {
		WP_CLI::line( WP_CLI::colorize( '%B=================================================%n' ) );
		WP_CLI::line( WP_CLI::colorize( '%G WP Static Architect - Estado del Sistema%n' ) );
		WP_CLI::line( WP_CLI::colorize( '%B=================================================%n' ) );

		$health = WP_Static_Arquitect_Admin::get_system_health();
		WP_CLI::line( sprintf( 'Diagnóstico de Servidor: %d/%d pruebas superadas (%s)', $health['passed'], $health['total'], $health['all_ok'] ? 'ÓPTIMO' : 'ATENCIÓN' ) );

		$provider = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );
		$domain   = get_option( 'wp_static_arquitect_custom_domain', '' );
		$geo      = get_option( 'wp_static_arquitect_enable_geo', '1' );
		$forms    = get_option( 'wp_static_arquitect_enable_forms', '1' );
		$comments = get_option( 'wp_static_arquitect_enable_comments', '1' );
		$tier     = get_option( 'wp_static_arquitect_service_tier', 'creator_pro' );

		WP_CLI::line( sprintf( 'Proveedor de Hosting: %s', strtoupper( $provider ) ) );
		WP_CLI::line( sprintf( 'Dominio Canónico:     %s', ! empty( $domain ) ? $domain : 'No configurado (usa localhost)' ) );
		WP_CLI::line( sprintf( 'GEO (IAs / llms.txt): %s', '1' === $geo ? 'Activo' : 'Desactivado' ) );
		WP_CLI::line( sprintf( 'Formularios:          %s', '1' === $forms ? 'Habilitados' : 'Desactivados (Brochure)' ) );
		WP_CLI::line( sprintf( 'Comentarios:          %s', '1' === $comments ? 'Habilitados (Supabase)' : 'Desactivados' ) );
		WP_CLI::line( sprintf( 'Perfil de Servicio:   %s', ( 'creator_pro' === $tier || 'enterprise' === $tier ) ? 'Modo Creador Pro (Ilimitado)' : 'Estándar' ) );

		$last_export = get_option( 'wp_static_arquitect_last_export_info', null );
		if ( $last_export ) {
			WP_CLI::line( '' );
			WP_CLI::line( WP_CLI::colorize( '%CÚltimo Paquete Generado:%n' ) );
			WP_CLI::line( sprintf( '  Nombre:  %s', $last_export['file_name'] ) );
			WP_CLI::line( sprintf( '  Tamaño:  %s', $last_export['file_size'] ) );
			WP_CLI::line( sprintf( '  Fecha:   %s', $last_export['created_at'] ) );
		}
	}

	/**
	 * Ejecuta una purga inmediata de formularios antiguos en Netlify.
	 *
	 * ## EJEMPLOS
	 *
	 *     wp static-architect purge-forms
	 *
	 * @param array $args
	 * @param array $assoc_args
	 */
	public function purge_forms( $args, $assoc_args ) {
		WP_CLI::line( 'Ejecutando purga en la API de Netlify...' );
		$main   = WP_Static_Arquitect::get_instance();
		$result = $main->netlify_forms->purge_submissions();

		if ( is_wp_error( $result ) ) {
			WP_CLI::error( $result->get_error_message() );
		}

		WP_CLI::success( sprintf( 'Purga completada. %d envíos eliminados.', $result['purged_count'] ) );
	}
}

WP_CLI::add_command( 'static-architect', 'WP_Static_Arquitect_CLI_Command' );
