<?php
/**
 * Generador Autónomo y Asistido de Artículos con IA (SEO & GEO)
 * para Mundos Simulados.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_AI_Article_Generator {

	/**
	 * Categorías oficiales del sitio.
	 */
	public static $categories = array(
		'astrofisica' => 'Astrofísica y Espacio',
		'tecnologia'  => 'Tecnología y Futuro',
		'biosfera'    => 'Biosfera, Naturaleza y Clima',
		'economia'    => 'Economía y Sociedad Global',
	);

	/**
	 * Obtiene la clave de API de Gemini desde las opciones de WordPress o constante.
	 */
	public function get_gemini_api_key() {
		$options = get_option( 'wp_static_arquitect_options', array() );
		if ( ! empty( $options['gemini_api_key'] ) ) {
			return trim( $options['gemini_api_key'] );
		}
		if ( defined( 'GEMINI_API_KEY' ) && ! empty( constant( 'GEMINI_API_KEY' ) ) ) {
			return trim( constant( 'GEMINI_API_KEY' ) );
		}
		return '';
	}

	/**
	 * Descubre dinámicamente el modelo Flash disponible en la cuenta y capa gratuita.
	 */
	public function get_active_model( $api_key ) {
		$models_endpoint = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . rawurlencode( $api_key );
		$resp            = wp_remote_get(
			$models_endpoint,
			array(
				'timeout'   => 15,
				'sslverify' => false,
			)
		);

		$chosen_model = 'gemini-3.5-flash-lite'; // Modelo por defecto estándar gratuito 2026

		if ( ! is_wp_error( $resp ) && 200 === wp_remote_retrieve_response_code( $resp ) ) {
			$data = json_decode( wp_remote_retrieve_body( $resp ), true );
			if ( ! empty( $data['models'] ) && is_array( $data['models'] ) ) {
				$available = array();
				foreach ( $data['models'] as $m ) {
					if ( ! empty( $m['supportedGenerationMethods'] ) && in_array( 'generateContent', $m['supportedGenerationMethods'], true ) ) {
						$available[] = preg_replace( '#^models/#', '', $m['name'] );
					}
				}

				$priority = array(
					'gemini-3.5-flash-lite',
					'gemini-flash-lite-latest',
					'gemini-3.5-flash',
					'gemini-3.6-flash',
					'gemini-flash-latest',
					'gemini-2.5-flash',
					'gemini-2.0-flash',
					'gemini-1.5-flash',
				);

				foreach ( $priority as $pref ) {
					foreach ( $available as $avail ) {
						if ( false !== strpos( $avail, $pref ) ) {
							return $avail;
						}
					}
				}

				if ( ! empty( $available ) ) {
					return $available[0];
				}
			}
		}

		return $chosen_model;
	}

	/**
	 * Consulta en tiempo real motores de búsqueda (Google Suggest) y Wikipedia
	 * para que la IA se base en consultas reales de usuarios y datos científicos verificados.
	 */
	public function search_engine_grounding( $query, $category_slug = '' ) {
		$results = array(
			'search_suggestions' => array(),
			'scientific_facts'   => array(),
		);

		// 1. Google Suggest: Consultas reales que la gente busca
		$search_queries = array( $query );
		if ( ! empty( $category_slug ) ) {
			$search_queries[] = 'que pasaria si ' . $query;
			$search_queries[] = 'que pasaria si en ' . $category_slug;
		}

		$suggestions = array();
		foreach ( $search_queries as $sq ) {
			$url  = 'https://suggestqueries.google.com/complete/search?client=chrome&q=' . rawurlencode( $sq );
			$resp = wp_remote_get(
				$url,
				array(
					'timeout'    => 6,
					'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
				)
			);

			if ( ! is_wp_error( $resp ) && 200 === wp_remote_retrieve_response_code( $resp ) ) {
				$data = json_decode( wp_remote_retrieve_body( $resp ), true );
				if ( ! empty( $data[1] ) && is_array( $data[1] ) ) {
					foreach ( array_slice( $data[1], 0, 5 ) as $item ) {
						$suggestions[] = sanitize_text_field( $item );
					}
				}
			}
		}
		$results['search_suggestions'] = array_values( array_unique( $suggestions ) );

		// 2. Wikipedia: Hechos científicos verificados y constantes físicas reales
		preg_match_all( '/\b[A-Za-zÁ-ú]{4,}\b/u', $query, $words_matches );
		$terms = array();
		if ( ! empty( $words_matches[0] ) ) {
			$stop_words = array( 'como', 'este', 'esta', 'para', 'pero', 'seria', 'mundo', 'tierra', 'pasaria', 'sobre' );
			foreach ( $words_matches[0] as $w ) {
				$wl = mb_strtolower( $w, 'UTF-8' );
				if ( ! in_array( $wl, $stop_words, true ) ) {
					$terms[] = $w;
				}
			}
		}

		foreach ( array_slice( $terms, 0, 2 ) as $term ) {
			$wiki_url = 'https://es.wikipedia.org/api/rest_v1/page/summary/' . rawurlencode( $term );
			$resp     = wp_remote_get(
				$wiki_url,
				array(
					'timeout'    => 6,
					'user-agent' => 'MundosSimulados/1.0 (contacto@mundossimulados.online)',
				)
			);
			if ( ! is_wp_error( $resp ) && 200 === wp_remote_retrieve_response_code( $resp ) ) {
				$wdata = json_decode( wp_remote_retrieve_body( $resp ), true );
				if ( ! empty( $wdata['extract'] ) ) {
					$results['scientific_facts'][] = array(
						'term'    => $term,
						'extract' => mb_substr( $wdata['extract'], 0, 350, 'UTF-8' ),
					);
				}
			}
		}

		return $results;
	}

	/**
	 * Realiza una petición REST a Gemini con reintentos y JSON opcional.
	 */
	public function call_gemini( $prompt, $api_key, $system_instruction = '', $json_mode = false ) {
		$model    = $this->get_active_model( $api_key );
		$endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $api_key );

		$payload = array(
			'contents'         => array(
				array(
					'parts' => array(
						array( 'text' => $prompt ),
					),
				),
			),
			'generationConfig' => array(
				'temperature' => $json_mode ? 0.3 : 0.7,
			),
		);

		if ( ! empty( $system_instruction ) ) {
			$payload['systemInstruction'] = array(
				'parts' => array(
					array( 'text' => $system_instruction ),
				),
			);
		}

		if ( $json_mode ) {
			$payload['generationConfig']['responseMimeType'] = 'application/json';
		}

		$response = wp_remote_post(
			$endpoint,
			array(
				'timeout'   => 90,
				'sslverify' => false,
				'headers'   => array( 'Content-Type' => 'application/json' ),
				'body'      => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => 'Error de conexión con Gemini: ' . $response->get_error_message(),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		if ( 200 !== $code ) {
			return array(
				'success' => false,
				'message' => "Gemini API devolvió código {$code}: " . mb_substr( $body, 0, 200 ),
			);
		}

		$data      = json_decode( $body, true );
		$candidate = ! empty( $data['candidates'][0]['content']['parts'][0]['text'] ) ? $data['candidates'][0]['content']['parts'][0]['text'] : '';

		return array(
			'success' => true,
			'text'    => $candidate,
		);
	}

	/**
	 * Descubre temas nuevos en motores de búsqueda garantizando cero duplicados
	 * contra todos los posts existentes en WordPress.
	 */
	public function discover_topics( $category_slug = 'astrofisica', $count = 6 ) {
		$api_key = $this->get_gemini_api_key();
		if ( empty( $api_key ) ) {
			return array(
				'success' => false,
				'message' => 'Falta configurar la clave de API de Gemini.',
			);
		}

		$cat_name = isset( self::$categories[ $category_slug ] ) ? self::$categories[ $category_slug ] : 'Astrofísica y Espacio';

		// 1. Investigación en Motores de Búsqueda
		$search_data = $this->search_engine_grounding( "que pasaria si {$category_slug}", $category_slug );

		// 2. Obtener títulos de posts existentes para evitar duplicidad
		$existing_posts = get_posts(
			array(
				'numberposts' => 150,
				'post_status' => array( 'publish', 'draft', 'pending', 'future' ),
				'fields'      => 'post_title',
			)
		);
		$existing_titles = array();
		foreach ( $existing_posts as $p ) {
			$existing_titles[] = is_object( $p ) ? $p->post_title : (string) $p;
		}

		// 3. Prompt para descubrir temas
		$prompt = "Actúa como editor en jefe de 'Mundos Simulados'.\n"
			. "Queremos descubrir {$count} NUEVOS temas de artículos para la categoría '{$cat_name}' ({$category_slug}).\n\n"
			. "REGLAS ESTRICTAS:\n"
			. "1. Ninguna propuesta puede repetir ni ser similar a estos títulos ya existentes en el sitio:\n"
			. wp_json_encode( array_slice( $existing_titles, 0, 40 ), JSON_UNESCAPED_UNICODE ) . "\n\n"
			. "2. Basa las propuestas en estas intenciones y preguntas reales detectadas en motores de búsqueda:\n"
			. wp_json_encode( $search_data['search_suggestions'], JSON_UNESCAPED_UNICODE ) . "\n\n"
			. "3. Cada propuesta debe cumplir el método editorial de Mundos Simulados:\n"
			. "- Partir de un dato medible real (ley física, cifra exacta, tasa verificada).\n"
			. "- Alterar UNA sola variable del mundo real.\n"
			. "- Formato GEO: planteado como pregunta con respuesta directa para motores de IA.\n\n"
			. "Responde EXCLUSIVAMENTE un array JSON con {$count} objetos con este formato exacto:\n"
			. "[\n"
			. "  {\n"
			. '    "titulo": "Título H1 magnético optimizado para búsqueda",' . "\n"
			. '    "palabra_clave": "palabra clave principal de 3 a 5 palabras",' . "\n"
			. '    "dato_medible_base": "Dato o ley científica real de partida (ej: La velocidad de rotación ecuatorial es de 1670 km/h)",' . "\n"
			. '    "variable_alterada": "Qué variable cambia exactamente",' . "\n"
			. '    "categoria": "' . esc_js( $category_slug ) . '"' . "\n"
			. "  }\n"
			. "]";

		$res = $this->call_gemini( $prompt, $api_key, '', true );
		if ( ! $res['success'] ) {
			return $res;
		}

		$topics = json_decode( $res['text'], true );
		if ( ! is_array( $topics ) ) {
			// Intentar extraer de bloques de código
			if ( preg_match( '/\[.*\]/s', $res['text'], $m ) ) {
				$topics = json_decode( $m[0], true );
			}
		}

		if ( ! is_array( $topics ) ) {
			return array(
				'success' => false,
				'message' => 'No se pudo interpretar la respuesta de la IA en formato JSON.',
			);
		}

		return array(
			'success' => true,
			'topics'  => $topics,
		);
	}

	/**
	 * Genera el artículo completo con rigor editorial, formato GEO,
	 * interlinking interno y lo inserta como borrador en WordPress con RankMath SEO.
	 */
	public function generate_article( $idea_or_topic, $category_slug = 'astrofisica', $custom_keyword = '' ) {
		$api_key = $this->get_gemini_api_key();
		if ( empty( $api_key ) ) {
			return array(
				'success' => false,
				'message' => 'Falta configurar la clave de API de Gemini.',
			);
		}

		// 1. Investigación en motores de búsqueda
		$search_data = $this->search_engine_grounding( $idea_or_topic, $category_slug );

		// 2. Interlinking: Obtener posts publicados de la misma categoría
		$related_posts = get_posts(
			array(
				'numberposts' => 5,
				'category_name' => $category_slug,
				'post_status' => 'publish',
			)
		);
		if ( empty( $related_posts ) ) {
			$related_posts = get_posts( array( 'numberposts' => 5, 'post_status' => 'publish' ) );
		}

		$interlinks = array();
		foreach ( $related_posts as $rp ) {
			$interlinks[] = '- [' . $rp->post_title . '](' . get_permalink( $rp->ID ) . ')';
		}
		$interlinks_text = implode( "\n", $interlinks );

		// 3. Ficha Técnica y Arquitectura GEO
		$prompt_plan = "Actúa como Director Editorial y Especialista en GEO (Generative Engine Optimization) de 'Mundos Simulados'.\n"
			. "Para la premisa: \"{$idea_or_topic}\" (Categoría: {$category_slug})\n\n"
			. "Resultados de investigación de motores de búsqueda:\n"
			. wp_json_encode( $search_data, JSON_UNESCAPED_UNICODE ) . "\n\n"
			. "Diseña la arquitectura en JSON con estos campos exactos:\n"
			. "{\n"
			. '  "title": "H1 optimizado para búsqueda (máx 65 caracteres)",' . "\n"
			. '  "slug": "url-slug-amigable-sin-acentos",' . "\n"
			. '  "focus_keyword": "' . ( ! empty( $custom_keyword ) ? esc_js( $custom_keyword ) : 'palabra clave objetivo' ) . '",' . "\n"
			. '  "meta_description": "Meta descripción de 145-155 caracteres con gancho científico",' . "\n"
			. '  "tags": ["Tag1", "Tag2", "Tag3", "Tag4"],' . "\n"
			. '  "dato_medible_real": "Dato científico real verificable con cifra exacta",' . "\n"
			. '  "h2_geo": [' . "\n"
			. '    "H2 pregunta 1 (Fase inicial)",' . "\n"
			. '    "H2 pregunta 2 (Impacto en la física o ecosistema)",' . "\n"
			. '    "H2 pregunta 3 (Consecuencias a medio y largo plazo)",' . "\n"
			. '    "H2 pregunta 4 (¿Es reversible o nueva normalidad?)"' . "\n"
			. '  ],' . "\n"
			. '  "alt_destacada": "Descripción en español para alt text imagen destacada",' . "\n"
			. '  "prompt_destacada": "Cinematic photo in 16:9 ratio, photorealistic, Unreal Engine 5 style...",' . "\n"
			. '  "alt_interna_1": "Descripción en español imagen interna 1",' . "\n"
			. '  "prompt_interna_1": "Detailed realistic photography of...",' . "\n"
			. '  "alt_interna_2": "Descripción en español imagen interna 2",' . "\n"
			. '  "prompt_interna_2": "Macro cinematic shot of...",' . "\n"
			. '  "pinterest_title": "Título para Pin de Pinterest",' . "\n"
			. '  "pinterest_desc": "Descripción atractiva para Pinterest con hashtags"' . "\n"
			. "}";

		$plan_res = $this->call_gemini( $prompt_plan, $api_key, '', true );
		if ( ! $plan_res['success'] ) {
			return $plan_res;
		}

		$plan = json_decode( $plan_res['text'], true );
		if ( ! is_array( $plan ) && preg_match( '/\{.*\}/s', $plan_res['text'], $m ) ) {
			$plan = json_decode( $m[0], true );
		}

		if ( empty( $plan['title'] ) ) {
			return array(
				'success' => false,
				'message' => 'No se pudo planificar la estructura del artículo.',
			);
		}

		// 4. Redacción del Cuerpo según el Método Editorial
		$prompt_maestro = "Eres el redactor editorial de Mundos Simulados, un sitio en español que explica escenarios "
			. "hipotéticos ('qué pasaría si...') con rigor científico, no como ciencia ficción de entretenimiento.\n\n"
			. "MÉTODO EDITORIAL:\n"
			. "1. Parte de un dato medible real antes de imaginar nada.\n"
			. "2. Cambia UNA sola variable del mundo real y sigue la cadena de consecuencias en orden temporal.\n"
			. "3. Tono directo, en español neutro, sin exclamaciones, sin em-dash (—), sin frases de marketing.\n"
			. "4. No repitas el H1, ya está puesto por WordPress.\n"
			. "5. Usa exactamente los H2 que te doy en el brief como subtítulos Markdown ('## '). Responde de inmediato en el primer párrafo de cada H2 con precisión para que motores de respuesta como Perplexity o Google SGE extraigan la cita.\n"
			. "6. Extensión: entre 1400 y 1900 palabras.\n"
			. "7. Inserta exactamente la línea: {{IMAGEN_INTERNA_1}} después del primer o segundo H2.\n"
			. "8. Inserta exactamente la línea: {{IMAGEN_INTERNA_2}} antes del cierre.\n"
			. "9. Cierra con un párrafo breve que responda 'qué nos dice esto del mundo real'.\n"
			. "10. Responde solo con el cuerpo del artículo en Markdown.";

		$h2_list = '';
		if ( ! empty( $plan['h2_geo'] ) && is_array( $plan['h2_geo'] ) ) {
			foreach ( $plan['h2_geo'] as $h2 ) {
				$h2_list .= "## {$h2}\n";
			}
		}

		$prompt_cuerpo = "H1 del artículo: {$plan['title']}\n"
			. "Palabra clave objetivo: {$plan['focus_keyword']}\n"
			. "Categoría: {$category_slug}\n"
			. "Dato medible de partida: {$plan['dato_medible_real']}\n\n"
			. "Estructura H2 GEO obligatoria:\n{$h2_list}\n\n"
			. "Interlinking contextual sugerido (incluye 1 o 2 en enlaces Markdown fluidos si encajan):\n"
			. "{$interlinks_text}\n\n"
			. "Contexto de imágenes:\n"
			. "- Imagen 1: {$plan['alt_interna_1']}\n"
			. "- Imagen 2: {$plan['alt_interna_2']}\n";

		$cuerpo_res = $this->call_gemini( $prompt_cuerpo, $api_key, $prompt_maestro, false );
		if ( ! $cuerpo_res['success'] ) {
			return $cuerpo_res;
		}

		$cuerpo_md = trim( $cuerpo_res['text'] );
		$words     = str_word_count( wp_strip_all_tags( $cuerpo_md ) );

		// Asegurar marcadores de imágenes si faltasen
		if ( false === strpos( $cuerpo_md, '{{IMAGEN_INTERNA_1}}' ) ) {
			$h2_parts = explode( '## ', $cuerpo_md, 3 );
			if ( count( $h2_parts ) >= 3 ) {
				$cuerpo_md = $h2_parts[0] . '## ' . $h2_parts[1] . "\n\n{{IMAGEN_INTERNA_1}}\n\n## " . $h2_parts[2];
			}
		}
		if ( false === strpos( $cuerpo_md, '{{IMAGEN_INTERNA_2}}' ) ) {
			$pos = strrpos( $cuerpo_md, '## ' );
			if ( false !== $pos ) {
				$cuerpo_md = substr( $cuerpo_md, 0, $pos ) . "\n\n{{IMAGEN_INTERNA_2}}\n\n" . substr( $cuerpo_md, $pos );
			}
		}

		// Convertir Markdown a HTML básico
		$cuerpo_html = wpautop( $cuerpo_md );
		// Reemplazar encabezados markdown a h2/h3 si quedaron literales
		$cuerpo_html = preg_replace( '/^##\s+(.+)$/m', '<h2>$1</h2>', $cuerpo_html );
		$cuerpo_html = preg_replace( '/^###\s+(.+)$/m', '<h3>$1</h3>', $cuerpo_html );

		// 5. Insertar Borrador en WordPress
		$slug = ! empty( $plan['slug'] ) ? sanitize_title( $plan['slug'] ) : sanitize_title( $plan['title'] );

		// Resolver categoría en WP
		$cat_id = 0;
		$term   = get_term_by( 'slug', $category_slug, 'category' );
		if ( $term ) {
			$cat_id = $term->term_id;
		} else {
			$cat_created = wp_create_category( isset( self::$categories[ $category_slug ] ) ? self::$categories[ $category_slug ] : $category_slug );
			if ( ! is_wp_error( $cat_created ) ) {
				$cat_id = $cat_created;
			}
		}

		$post_data = array(
			'post_title'   => sanitize_text_field( $plan['title'] ),
			'post_name'    => $slug,
			'post_content' => $cuerpo_html,
			'post_status'  => 'draft',
			'post_type'    => 'post',
		);

		if ( $cat_id > 0 ) {
			$post_data['post_category'] = array( $cat_id );
		}

		$post_id = wp_insert_post( $post_data );
		if ( is_wp_error( $post_id ) ) {
			return array(
				'success' => false,
				'message' => 'Error al crear el post en WordPress: ' . $post_id->get_error_message(),
			);
		}

		// Asignar etiquetas
		if ( ! empty( $plan['tags'] ) && is_array( $plan['tags'] ) ) {
			wp_set_post_tags( $post_id, $plan['tags'], true );
		}

		// Asignar Metadatos RankMath SEO
		update_post_meta( $post_id, 'rank_math_title', $plan['title'] );
		update_post_meta( $post_id, 'rank_math_description', $plan['meta_description'] );
		update_post_meta( $post_id, 'rank_math_focus_keyword', $plan['focus_keyword'] );

		// Guardar metadatos visuales y de Pinterest para posterior generación de imágenes
		$prompts_data = array(
			'destacada' => array(
				'alt'    => $plan['alt_destacada'],
				'prompt' => $plan['prompt_destacada'],
			),
			'interna_1' => array(
				'alt'    => $plan['alt_interna_1'],
				'prompt' => $plan['prompt_interna_1'],
			),
			'interna_2' => array(
				'alt'    => $plan['alt_interna_2'],
				'prompt' => $plan['prompt_interna_2'],
			),
			'pinterest' => array(
				'title' => isset( $plan['pinterest_title'] ) ? $plan['pinterest_title'] : '',
				'desc'  => isset( $plan['pinterest_desc'] ) ? $plan['pinterest_desc'] : '',
			),
		);
		update_post_meta( $post_id, '_wpsa_image_prompts', $prompts_data );

		return array(
			'success'     => true,
			'post_id'     => $post_id,
			'title'       => $plan['title'],
			'slug'        => $slug,
			'word_count'  => $words,
			'edit_url'    => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
			'prompts'     => $prompts_data,
		);
	}
}
