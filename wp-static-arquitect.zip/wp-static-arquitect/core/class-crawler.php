<?php
/**
 * Motor de rastreo y descarga de recursos (HTML, CSS, JS, imágenes).
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Crawler {

	/**
	 * Dominio base del sitio WordPress.
	 *
	 * @var string
	 */
	private $site_url;

	/**
	 * Dominio normalizado (host).
	 *
	 * @var string
	 */
	private $site_host;

	/**
	 * Lista de URLs de páginas rastreadas para evitar bucles.
	 *
	 * @var array
	 */
	private $visited_urls = array();

	/**
	 * Lista de activos descargados.
	 *
	 * @var array
	 */
	private $downloaded_assets = array();

	/**
	 * Directorio temporal actual de exportación.
	 *
	 * @var string
	 */
	private $temp_dir;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->site_url  = trailingslashit( home_url() );
		$this->site_host = wp_parse_url( $this->site_url, PHP_URL_HOST );
	}

	/**
	 * Obtiene todas las URLs públicas que deben ser convertidas a estático.
	 *
	 * @return array Lista de URLs públicas únicas.
	 */
	public function discover_urls() {
		$urls = array();

		// 1. Página de inicio y portada
		$urls[] = home_url( '/' );

		// 2. Entradas, páginas y custom post types públicos
		$post_types = get_post_types( array( 'public' => true ), 'names' );
		unset( $post_types['attachment'] );

		$posts = get_posts(
			array(
				'post_type'      => $post_types,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		foreach ( $posts as $post_id ) {
			$permalink = get_permalink( $post_id );
			if ( $permalink && ! in_array( $permalink, $urls, true ) ) {
				$urls[] = $permalink;
			}
		}

		// 3. Taxonomías públicas (categorías, etiquetas, etc.)
		$taxonomies = get_taxonomies( array( 'public' => true ), 'names' );
		foreach ( $taxonomies as $taxonomy ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => true,
				)
			);
			if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				foreach ( $terms as $term ) {
					$term_link = get_term_link( $term );
					if ( ! is_wp_error( $term_link ) && ! in_array( $term_link, $urls, true ) ) {
						$urls[] = $term_link;
					}
				}
			}
		}

		// 4. Archivos de autores que tengan entradas publicadas
		$authors = get_users( array( 'has_published_posts' => true ) );
		foreach ( $authors as $author ) {
			$author_url = get_author_posts_url( $author->ID );
			if ( $author_url && ! in_array( $author_url, $urls, true ) ) {
				$urls[] = $author_url;
			}
		}

		// 5. Elementos de menús de navegación activos
		$nav_menus = wp_get_nav_menus();
		foreach ( $nav_menus as $menu ) {
			$items = wp_get_nav_menu_items( $menu->term_id );
			if ( $items ) {
				foreach ( $items as $item ) {
					if ( ! empty( $item->url ) && $this->is_internal_url( $item->url ) ) {
						$clean_url = strtok( $item->url, '#' );
						if ( ! in_array( $clean_url, $urls, true ) ) {
							$urls[] = $clean_url;
						}
					}
				}
			}
		}

		// 6. Inclusión de URLs adicionales configuradas en el panel
		$additional_raw = (string) get_option( 'wp_static_arquitect_additional_urls', '' );
		if ( ! empty( $additional_raw ) ) {
			$lines = explode( "\n", str_replace( "\r", '', $additional_raw ) );
			foreach ( $lines as $line ) {
				$line = trim( $line );
				if ( empty( $line ) || 0 === strpos( $line, '#' ) ) {
					continue;
				}
				if ( 0 === strpos( $line, 'http://' ) || 0 === strpos( $line, 'https://' ) ) {
					$urls[] = $line;
				} else {
					$urls[] = home_url( '/' . ltrim( $line, '/' ) );
				}
			}
		}

		// Filtrar y normalizar
		$normalized_urls = array();
		foreach ( $urls as $u ) {
			$clean = $this->normalize_url( $u );
			if ( $clean && ! in_array( $clean, $normalized_urls, true ) ) {
				$normalized_urls[] = $clean;
			}
		}

		// 7. Reglas de exclusión de URLs configuradas en el panel
		$excluded_raw = (string) get_option( 'wp_static_arquitect_excluded_urls', '' );
		if ( ! empty( $excluded_raw ) ) {
			$rules = array_filter( array_map( 'trim', explode( "\n", str_replace( "\r", '', $excluded_raw ) ) ) );
			$normalized_urls = array_filter(
				$normalized_urls,
				function( $test_url ) use ( $rules ) {
					foreach ( $rules as $rule ) {
						if ( empty( $rule ) || 0 === strpos( $rule, '#' ) ) {
							continue;
						}
						if ( 0 === strpos( $rule, 'regex:' ) ) {
							$pattern = '#' . str_replace( '#', '\#', substr( $rule, 6 ) ) . '#i';
							if ( @preg_match( $pattern, $test_url ) ) {
								return false;
							}
							continue;
						}
						if ( preg_match( '/^[\/~#%].*[\/~#%][a-z]*$/i', $rule ) && @preg_match( $rule, $test_url ) ) {
							return false;
						}
						if ( false !== strpos( $test_url, $rule ) ) {
							return false;
						}
					}
					return true;
				}
			);
			$normalized_urls = array_values( $normalized_urls );
		}

		return apply_filters( 'wp_static_arquitect_discovered_urls', $normalized_urls );
	}

	/**
	 * Ejecuta el rastreo y extracción completa hacia el directorio temporal especificado.
	 *
	 * @param string   $temp_dir          Ruta absoluta de la carpeta destino.
	 * @param callable $progress_callback Función de callback para reportar progreso.
	 * @return array Estadísticas del rastreo.
	 */
	public function run( $temp_dir, $progress_callback = null ) {
		$this->temp_dir          = trailingslashit( $temp_dir );
		$this->visited_urls      = array();
		$this->downloaded_assets = array();

		WP_Static_Arquitect::log( 'Iniciando descubrimiento de URLs públicas...', 'info' );
		$urls_to_crawl = $this->discover_urls();
		$total_pages   = count( $urls_to_crawl );

		WP_Static_Arquitect::log( sprintf( 'Se detectaron %d páginas para exportar.', $total_pages ), 'info' );

		if ( is_callable( $progress_callback ) ) {
			call_user_func( $progress_callback, 'discovery_complete', array( 'total' => $total_pages ) );
		}

		$parser = WP_Static_Arquitect::get_instance()->html_parser;

		// Copiar assets del plugin (scripts de Supabase y estilos)
		$this->copy_plugin_assets();

		$current_page_idx = 0;
		$total_assets_found = 0;
		$search_items = array();

		foreach ( $urls_to_crawl as $page_url ) {
			$current_page_idx++;
			$this->visited_urls[] = $page_url;

			WP_Static_Arquitect::log( sprintf( '[%d/%d] Rastreado: %s', $current_page_idx, $total_pages, $page_url ), 'info' );

			// Obtención ultra-resiliente del contenido (Navegador real + Loopback + Renderizado interno)
			$fetch_res = $this->fetch_page_content( $page_url );

			if ( ! $fetch_res['success'] || empty( $fetch_res['html'] ) ) {
				$err_msg = ! empty( $fetch_res['error'] ) ? $fetch_res['error'] : 'Error desconocido';
				WP_Static_Arquitect::log( sprintf( 'Error al obtener %s: %s', $page_url, $err_msg ), 'error' );
				continue;
			}

			$html = $fetch_res['html'];

			// Extraer metadatos para el buscador estático instantáneo
			if ( '0' !== get_option( 'wp_static_arquitect_enable_search', '1' ) ) {
				$search_items[] = $this->extract_search_data_from_html( $html, $page_url );
			}

			// Extraer activos (imágenes, css, js) del HTML original
			$extracted_assets = $this->extract_asset_urls_from_html( $html, $page_url );
			$total_assets_found += count( $extracted_assets );

			// Procesar HTML a través del analizador DOM (enlaces relativos, Netlify Forms, Supabase, Buscador)
			$processed_html = $parser->process_html( $html, $page_url, $this->site_url );

			// Guardar el archivo HTML procesado en disco
			$this->save_page_html( $page_url, $processed_html );

			// Descargar los activos descubiertos
			foreach ( $extracted_assets as $asset_url ) {
				$this->download_asset( $asset_url );
			}

			if ( is_callable( $progress_callback ) ) {
				call_user_func(
					$progress_callback,
					'page_processed',
					array(
						'current' => $current_page_idx,
						'total'   => $total_pages,
						'url'     => $page_url,
					)
				);
			}
		}

		// Generar página 404, archivos de hosting, buscador estático, sitemap, robots y llms.txt
		$this->generate_404_page( $temp_dir );
		$this->generate_hosting_platform_files( $temp_dir );
		$this->generate_search_index( $temp_dir, $search_items );
		$this->generate_sitemap_xml( $temp_dir, $urls_to_crawl );
		$this->generate_robots_txt( $temp_dir );
		$this->generate_llms_txt( $temp_dir, $urls_to_crawl, $search_items );
		$this->copy_additional_files( $temp_dir );

		$stats = array(
			'pages_crawled'     => count( $this->visited_urls ),
			'assets_downloaded' => count( $this->downloaded_assets ),
		);

		WP_Static_Arquitect::log(
			sprintf(
				'Rastreo finalizado con éxito. Páginas: %d | Activos: %d',
				$stats['pages_crawled'],
				$stats['assets_downloaded']
			),
			'success'
		);

		return $stats;
	}

	/**
	 * Guarda el HTML procesado en la estructura de carpetas estática correspondiente.
	 *
	 * @param string $url               URL original de la página.
	 * @param string $html              Código HTML procesado.
	 * @param string $temp_dir_override Ruta del directorio temporal (opcional para sesiones por lote).
	 */
	public function save_page_html( $url, $html, $temp_dir_override = '' ) {
		$base_dir    = ! empty( $temp_dir_override ) ? trailingslashit( $temp_dir_override ) : $this->temp_dir;
		$parsed_path = wp_parse_url( $url, PHP_URL_PATH );
		$parsed_path = trim( (string) $parsed_path, '/' );

		if ( empty( $parsed_path ) ) {
			// Es la raíz: index.html
			$target_file = $base_dir . 'index.html';
		} else {
			// Subpágina: crear carpeta slug y guardar index.html adentro
			$target_dir = $base_dir . $parsed_path . '/';
			wp_mkdir_p( $target_dir );
			$target_file = $target_dir . 'index.html';
		}

		$html = $this->apply_custom_domain_replacements( $html );

		@file_put_contents( $target_file, $html );
	}

	/**
	 * Sustituye el dominio de desarrollo/local por el dominio canónico de producción
	 * en metadatos, canónicas, Open Graph, Schema JSON-LD y enlaces embebidos.
	 *
	 * @param string $html Código HTML procesado.
	 * @return string Código HTML con el dominio canónico aplicado.
	 */
	public function apply_custom_domain_replacements( $html ) {
		$custom_domain = get_option( 'wp_static_arquitect_custom_domain', '' );
		if ( empty( $custom_domain ) ) {
			return $html;
		}

		$clean_custom = preg_replace( '#^https?://#', '', rtrim( $custom_domain, '/' ) );
		$home_domain  = wp_parse_url( home_url(), PHP_URL_HOST );

		if ( ! empty( $clean_custom ) && ! empty( $home_domain ) && strtolower( $clean_custom ) !== strtolower( $home_domain ) ) {
			$home_clean = untrailingslashit( home_url() );
			$target_url = 'https://' . $clean_custom;

			$search = array(
				$home_clean,
				'//' . $home_domain,
				rawurlencode( $home_clean ),
				urlencode( $home_clean ),
			);
			$replace = array(
				$target_url,
				'//' . $clean_custom,
				rawurlencode( $target_url ),
				urlencode( $target_url ),
			);

			$html = str_replace( $search, $replace, $html );
		}

		return $html;
	}

	/**
	 * Extrae todas las URLs de recursos locales embebidos en el HTML.
	 *
	 * @param string $html     Contenido HTML.
	 * @param string $base_url URL base de la página.
	 * @return array Lista de URLs absolutas de activos.
	 */
	public function extract_asset_urls_from_html( $html, $base_url ) {
		$assets = array();

		// Expresión regular para localizar atributos src, href y srcset
		$patterns = array(
			'/<(?:img|script|source|audio|video|embed|iframe)[^>]+src=["\']([^"\']+)["\']/i',
			'/<link[^>]+href=["\']([^"\']+)["\']/i',
			'/<(?:img|source)[^>]+srcset=["\']([^"\']+)["\']/i',
			'/url\(\s*["\']?([^"\'\)]+)["\']?\s*\)/i',
		);

		foreach ( $patterns as $pattern ) {
			if ( preg_match_all( $pattern, $html, $matches ) ) {
				foreach ( $matches[1] as $match ) {
					// Manejo de srcset con múltiples URLs y descriptores
					if ( strpos( $match, ',' ) !== false && strpos( $match, ' ' ) !== false ) {
						$parts = explode( ',', $match );
						foreach ( $parts as $part ) {
							$url_candidate = trim( preg_replace( '/\s+\d+[wx]$/i', '', trim( $part ) ) );
							$this->add_asset_if_internal( $url_candidate, $base_url, $assets );
						}
					} else {
						$this->add_asset_if_internal( $match, $base_url, $assets );
					}
				}
			}
		}

		return array_unique( $assets );
	}

	/**
	 * Añade un activo a la lista si pertenece al mismo dominio o ruta local.
	 *
	 * @param string $url      URL del activo.
	 * @param string $base_url URL base.
	 * @param array  $assets   Array de activos por referencia.
	 */
	private function add_asset_if_internal( $url, $base_url, &$assets ) {
		$url = trim( $url );
		if ( empty( $url ) || 0 === strpos( $url, 'data:' ) || 0 === strpos( $url, '#' ) || 0 === strpos( $url, 'javascript:' ) ) {
			return;
		}

		// Convertir a absoluta si es relativa
		$absolute_url = $this->resolve_relative_url( $url, $base_url );

		if ( $this->is_internal_url( $absolute_url ) ) {
			// No incluir feeds ni URLs dinámicas de WP-Admin
			if ( false === strpos( $absolute_url, 'wp-admin' ) && false === strpos( $absolute_url, 'wp-login' ) ) {
				$clean = strtok( $absolute_url, '#' );
				$assets[] = $clean;
			}
		}
	}

	/**
	 * Descarga un activo y lo coloca en la estructura relativa correspondiente.
	 *
	 * @param string $asset_url          URL absoluta del activo.
	 * @param string $temp_dir_override  Directorio destino (opcional).
	 * @return bool True si se descargó o copió con éxito.
	 */
	public function download_asset( $asset_url, $temp_dir_override = '' ) {
		$base_dir  = ! empty( $temp_dir_override ) ? trailingslashit( $temp_dir_override ) : $this->temp_dir;
		$clean_url = strtok( $asset_url, '?' );
		if ( in_array( $clean_url, $this->downloaded_assets, true ) ) {
			return true;
		}

		$parsed_path = wp_parse_url( $clean_url, PHP_URL_PATH );
		if ( empty( $parsed_path ) ) {
			return false;
		}

		$relative_path = ltrim( $parsed_path, '/' );
		$target_file   = $base_dir . $relative_path;
		$target_dir    = dirname( $target_file );

		wp_mkdir_p( $target_dir );

		// Optimización de copia directa si el archivo se encuentra físicamente en ABSPATH
		$local_file = ABSPATH . $relative_path;
		if ( file_exists( $local_file ) && is_file( $local_file ) ) {
			@copy( $local_file, $target_file );
			$this->downloaded_assets[] = $clean_url;
			return true;
		}

		// Si no está directamente en ABSPATH o requiere descarga HTTP
		$ua = ! empty( $_SERVER['HTTP_USER_AGENT'] )
			? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) )
			: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

		$cookies = array();
		if ( ! empty( $_COOKIE ) && is_array( $_COOKIE ) ) {
			foreach ( $_COOKIE as $c_name => $c_val ) {
				if ( is_string( $c_val ) ) {
					$cookies[] = new WP_Http_Cookie( array(
						'name'  => $c_name,
						'value' => $c_val,
					) );
				}
			}
		}

		$response = wp_remote_get(
			$asset_url,
			array(
				'timeout'     => 25,
				'sslverify'   => false,
				'redirection' => 5,
				'user-agent'  => $ua,
				'cookies'     => $cookies,
				'headers'     => array(
					'Accept' => '*/*',
				),
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		@file_put_contents( $target_file, $body );

		$this->downloaded_assets[] = $clean_url;
		return true;
	}


	/**
	 * Comprueba si una URL pertenece al dominio del sitio WordPress.
	 *
	 * @param string $url URL a verificar.
	 * @return bool
	 */
	public function is_internal_url( $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( empty( $host ) ) {
			// Es ruta relativa local
			return true;
		}
		return strcasecmp( $host, $this->site_host ) === 0;
	}

	/**
	 * Normaliza una URL removiendo fragmentos y barras innecesarias.
	 *
	 * @param string $url
	 * @return string
	 */
	private function normalize_url( $url ) {
		$clean = strtok( $url, '#' );
		return $clean;
	}

	/**
	 * Resuelve una URL relativa con respecto a la URL base.
	 *
	 * @param string $relative URL relativa.
	 * @param string $base     URL base.
	 * @return string URL absoluta.
	 */
	private function resolve_relative_url( $relative, $base ) {
		if ( parse_url( $relative, PHP_URL_SCHEME ) != '' ) {
			return $relative;
		}

		if ( 0 === strpos( $relative, '//' ) ) {
			$scheme = wp_parse_url( $base, PHP_URL_SCHEME );
			return ( $scheme ? $scheme : 'https' ) . ':' . $relative;
		}

		$base_parts = wp_parse_url( $base );
		$scheme     = isset( $base_parts['scheme'] ) ? $base_parts['scheme'] : 'https';
		$host       = isset( $base_parts['host'] ) ? $base_parts['host'] : '';
		$port       = isset( $base_parts['port'] ) ? ':' . $base_parts['port'] : '';
		$root       = $scheme . '://' . $host . $port;

		if ( 0 === strpos( $relative, '/' ) ) {
			return $root . $relative;
		}

		$base_path = isset( $base_parts['path'] ) ? $base_parts['path'] : '/';
		$dir       = dirname( $base_path );
		if ( '.' === $dir || '/' === $dir ) {
			$dir = '';
		}

		return $root . $dir . '/' . $relative;
	}

	/**
	 * Genera la página 404.html capturando la plantilla 404 del tema activo de WordPress.
	 *
	 * @param string $temp_dir Directorio destino.
	 */
	public function generate_404_page( $temp_dir ) {
		$probe_url = trailingslashit( home_url() ) . 'wpsa-probe-404-check-' . wp_generate_password( 6, false );
		$fetch_res = $this->fetch_page_content( $probe_url );
		$html      = ( $fetch_res['success'] && ! empty( $fetch_res['html'] ) ) ? $fetch_res['html'] : '';

		if ( empty( $html ) ) {
			// Plantilla de respaldo si no se pudo capturar el 404 dinámico del tema
			$html = '<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Página no encontrada - 404</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#0f172a;color:#f8fafc;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;}h1{font-size:5rem;margin:0;color:#6366f1;}p{font-size:1.2rem;color:#94a3b8;margin:1rem 0 2rem;}a{display:inline-block;padding:0.75rem 1.5rem;background:#4f46e5;color:#fff;text-decoration:none;border-radius:8px;font-weight:600;transition:background 0.2s;}a:hover{background:#4338ca;}</style></head><body><div><h1>404</h1><p>Lo sentimos, la página solicitada no existe o fue movida.</p><a href="/">Volver al Inicio</a></div></body></html>';
		} else {
			$parser = WP_Static_Arquitect::get_instance()->html_parser;
			$html   = $parser->process_html( $html, $probe_url, $this->site_url );
		}

		$html = $this->apply_custom_domain_replacements( $html );

		@file_put_contents( trailingslashit( $temp_dir ) . '404.html', $html );
		WP_Static_Arquitect::log( 'Página 404.html generada correctamente.', 'info' );
	}

	/**
	 * Genera los archivos de configuración nativos de Netlify: _redirects y _headers.
	 *
	 * @param string $temp_dir Directorio destino.
	 */
	public function generate_netlify_files( $temp_dir ) {
		$target_dir = trailingslashit( $temp_dir );

		// 1. Archivo _redirects
		$redirects_content  = "# ==========================================\n";
		$redirects_content .= "# Netlify _redirects generados por WP Static Architect\n";
		$redirects_content .= "# ==========================================\n\n";

		// Redirección de accesos administrativos
		$redirects_content .= "/wp-login.php    /    301\n";
		$redirects_content .= "/wp-admin/*      /    301\n";
		$redirects_content .= "/xmlrpc.php      /    404\n";

		// Redirecciones personalizadas ingresadas en el panel
		$custom_redirects = trim( (string) get_option( 'wp_static_arquitect_netlify_custom_redirects', '' ) );
		if ( ! empty( $custom_redirects ) ) {
			$redirects_content .= "\n# Reglas personalizadas configuradas en el panel:\n";
			$redirects_content .= $custom_redirects . "\n";
		}

		// Fallback para página 404
		$redirects_content .= "\n# Fallback 404 personalizado\n";
		$redirects_content .= "/*    /404.html    404\n";

		@file_put_contents( $target_dir . '_redirects', $redirects_content );

		// 2. Archivo _headers
		$headers_content  = "# ==========================================\n";
		$headers_content .= "# Netlify _headers generados por WP Static Architect\n";
		$headers_content .= "# ==========================================\n\n";

		// Cache inmutable para uploads y recursos estáticos
		$headers_content .= "/wp-content/uploads/*\n";
		$headers_content .= "  Cache-Control: public, max-age=31536000, immutable\n\n";

		$headers_content .= "/wp-static-arquitect-assets/*\n";
		$headers_content .= "  Cache-Control: public, max-age=31536000, immutable\n\n";

		// Cabeceras de seguridad globales
		$headers_content .= "/*\n";
		$headers_content .= "  X-Frame-Options: SAMEORIGIN\n";
		$headers_content .= "  X-Content-Type-Options: nosniff\n";
		$headers_content .= "  X-XSS-Protection: 1; mode=block\n";
		$headers_content .= "  Referrer-Policy: strict-origin-when-cross-origin\n";

		// Cabeceras personalizadas ingresadas en el panel
		$custom_headers = trim( (string) get_option( 'wp_static_arquitect_netlify_custom_headers', '' ) );
		if ( ! empty( $custom_headers ) ) {
			$headers_content .= "\n# Cabeceras personalizadas configuradas en el panel:\n";
			$headers_content .= $custom_headers . "\n";
		}

		@file_put_contents( $target_dir . '_headers', $headers_content );

		WP_Static_Arquitect::log( 'Archivos de configuración _redirects y _headers de Netlify generados con éxito.', 'info' );
	}

	/**
	 * Copia los recursos del plugin según los módulos activos a la carpeta de exportación.
	 *
	 * @param string $temp_dir_override Directorio temporal.
	 */
	public function copy_plugin_assets( $temp_dir_override = '' ) {
		$base_dir = ! empty( $temp_dir_override ) ? trailingslashit( $temp_dir_override ) : $this->temp_dir;
		if ( empty( $base_dir ) ) {
			return;
		}

		$assets_dir = $base_dir . 'wp-static-arquitect-assets/';
		wp_mkdir_p( $assets_dir );

		$files_to_copy = array();

		// Solo copiar assets de comentarios si el módulo está activo
		if ( '0' !== get_option( 'wp_static_arquitect_enable_comments', '1' ) ) {
			$files_to_copy[] = 'supabase-comments.js';
			$files_to_copy[] = 'supabase-comments.css';
		}

		// Solo copiar assets de búsqueda si el módulo está activo
		if ( '0' !== get_option( 'wp_static_arquitect_enable_search', '1' ) ) {
			$files_to_copy[] = 'search-client.js';
			$files_to_copy[] = 'search-modal.css';
		}

		foreach ( $files_to_copy as $file ) {
			$source = WP_STATIC_ARQUITECT_PATH . 'templates/' . $file;
			if ( file_exists( $source ) ) {
				@copy( $source, $assets_dir . $file );
			}
		}

		$this->copy_additional_files( $base_dir );
	}

	/**
	 * Copia archivos locales adicionales especificados por el usuario en wp_options.
	 *
	 * @param string $target_dir
	 */
	public function copy_additional_files( $target_dir ) {
		$additional_raw = (string) get_option( 'wp_static_arquitect_additional_urls', '' );
		if ( empty( $additional_raw ) ) {
			return;
		}

		$lines = explode( "\n", str_replace( "\r", '', $additional_raw ) );
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( empty( $line ) || 0 === strpos( $line, '#' ) || 0 === strpos( $line, 'http' ) ) {
				continue;
			}

			$local_path = ABSPATH . ltrim( $line, '/' );
			if ( file_exists( $local_path ) && is_file( $local_path ) ) {
				$dest_file = trailingslashit( $target_dir ) . ltrim( $line, '/' );
				wp_mkdir_p( dirname( $dest_file ) );
				@copy( $local_path, $dest_file );
				WP_Static_Arquitect::log( sprintf( 'Archivo adicional copiado: %s', $line ), 'info' );
			}
		}
	}

	/**
	 * Extrae metadatos de una página para el índice de búsqueda estática (search-index.json).
	 *
	 * @param string $html Código HTML.
	 * @param string $url  URL de la página.
	 * @return array
	 */
	public function extract_search_data_from_html( $html, $url ) {
		$title = '';
		if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $matches ) ) {
			$title = wp_strip_all_tags( $matches[1] );
			$title = preg_replace( '/\s*[-–—|]\s*' . preg_quote( get_bloginfo( 'name' ), '/' ) . '.*$/i', '', $title );
		}

		$excerpt = '';
		if ( preg_match( '/<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']+)["\']/i', $html, $matches ) ) {
			$excerpt = wp_strip_all_tags( $matches[1] );
		} elseif ( preg_match( '/<p[^>]*>(.*?)<\/p>/is', $html, $matches ) ) {
			$excerpt = wp_strip_all_tags( $matches[1] );
		}
		if ( mb_strlen( $excerpt ) > 180 ) {
			$excerpt = mb_substr( $excerpt, 0, 177 ) . '...';
		}

		// Texto plano representativo (limpiando scripts y estilos)
		$clean_body = preg_replace( '/<(script|style|svg|nav|header|footer)[^>]*>.*?<\/\1>/is', ' ', $html );
		$content_text = wp_strip_all_tags( $clean_body );
		$content_text = preg_replace( '/\s+/', ' ', $content_text );
		if ( mb_strlen( $content_text ) > 400 ) {
			$content_text = mb_substr( $content_text, 0, 400 );
		}

		$parsed_path  = wp_parse_url( $url, PHP_URL_PATH );
		$relative_url = ! empty( $parsed_path ) ? '/' . ltrim( $parsed_path, '/' ) : '/';
		$type         = ( false !== strpos( $url, '/blog/' ) || false !== strpos( $url, '/post/' ) ) ? 'post' : 'page';

		return array(
			'title'   => html_entity_decode( trim( $title ), ENT_QUOTES, 'UTF-8' ),
			'url'     => $relative_url,
			'excerpt' => html_entity_decode( trim( $excerpt ), ENT_QUOTES, 'UTF-8' ),
			'content' => html_entity_decode( trim( $content_text ), ENT_QUOTES, 'UTF-8' ),
			'type'    => $type,
		);
	}

	/**
	 * Genera el archivo search-index.json a partir de los elementos procesados.
	 *
	 * @param string $temp_dir     Directorio destino.
	 * @param array  $search_items Lista de páginas indexadas.
	 */
	public function generate_search_index( $temp_dir, $search_items ) {
		if ( '0' === get_option( 'wp_static_arquitect_enable_search', '1' ) ) {
			return;
		}

		$target_file = trailingslashit( $temp_dir ) . 'search-index.json';
		$json_data   = wp_json_encode( $search_items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		@file_put_contents( $target_file, $json_data );

		WP_Static_Arquitect::log( sprintf( 'Índice de búsqueda search-index.json generado (%d elementos).', count( $search_items ) ), 'info' );
	}

	/**
	 * Obtiene el dominio canónico de producción (custom_domain > production_url > home_url).
	 *
	 * @return string URL base canónica con https:// y sin barra final.
	 */
	public function get_canonical_domain() {
		$custom_domain = get_option( 'wp_static_arquitect_custom_domain', '' );
		if ( ! empty( $custom_domain ) ) {
			$clean = preg_replace( '#^https?://#', '', rtrim( $custom_domain, '/' ) );
			return 'https://' . $clean;
		}

		$prod_url = get_option( 'wp_static_arquitect_production_url', '' );
		if ( ! empty( $prod_url ) ) {
			return untrailingslashit( $prod_url );
		}

		return untrailingslashit( home_url() );
	}

	/**
	 * Genera los archivos de configuración requeridos según la plataforma de hosting seleccionada.
	 *
	 * @param string $temp_dir Directorio destino.
	 */
	public function generate_hosting_platform_files( $temp_dir ) {
		$provider   = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );
		$target_dir = trailingslashit( $temp_dir );

		// 1. Archivo CNAME (siempre que exista un dominio personalizado configurado)
		$custom_domain = get_option( 'wp_static_arquitect_custom_domain', '' );
		if ( ! empty( $custom_domain ) ) {
			$clean_domain = preg_replace( '#^https?://#', '', rtrim( $custom_domain, '/' ) );
			@file_put_contents( $target_dir . 'CNAME', $clean_domain );
			WP_Static_Arquitect::log( sprintf( 'Archivo CNAME generado para dominio: %s', $clean_domain ), 'info' );
		}

		// 2. Archivos según plataforma
		if ( 'netlify' === $provider || 'cloudflare' === $provider ) {
			$this->generate_netlify_files( $temp_dir );

			if ( 'cloudflare' === $provider ) {
				// Cloudflare Pages _routes.json
				$routes = array(
					'version' => 1,
					'include' => array( '/*' ),
					'exclude' => array(
						'/wp-static-arquitect-assets/*',
						'/wp-content/uploads/*',
						'/search-index.json',
						'/sitemap.xml',
						'/robots.txt',
						'/llms.txt',
					),
				);
				@file_put_contents( $target_dir . '_routes.json', wp_json_encode( $routes, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
				WP_Static_Arquitect::log( 'Archivo _routes.json generado para Cloudflare Pages.', 'info' );
			}
		} elseif ( 'vercel' === $provider ) {
			// Vercel vercel.json
			$vercel_config = array(
				'cleanUrls'     => true,
				'trailingSlash' => true,
				'headers'       => array(
					array(
						'source'  => '/wp-static-arquitect-assets/(.*)',
						'headers' => array(
							array( 'key' => 'Cache-Control', 'value' => 'public, max-age=31536000, immutable' ),
						),
					),
					array(
						'source'  => '/wp-content/uploads/(.*)',
						'headers' => array(
							array( 'key' => 'Cache-Control', 'value' => 'public, max-age=31536000, immutable' ),
						),
					),
					array(
						'source'  => '/(.*)',
						'headers' => array(
							array( 'key' => 'X-Frame-Options', 'value' => 'SAMEORIGIN' ),
							array( 'key' => 'X-Content-Type-Options', 'value' => 'nosniff' ),
						),
					),
				),
			);
			@file_put_contents( $target_dir . 'vercel.json', wp_json_encode( $vercel_config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) );
			$this->generate_netlify_files( $temp_dir );
			WP_Static_Arquitect::log( 'Archivo vercel.json generado para despliegue en Vercel.', 'info' );
		} elseif ( 'github' === $provider ) {
			// GitHub Pages: .nojekyll evita que Jekyll omita carpetas con guion bajo o de WordPress
			@file_put_contents( $target_dir . '.nojekyll', '' );
			WP_Static_Arquitect::log( 'Archivo .nojekyll generado para GitHub Pages.', 'info' );
		} elseif ( 'custom' === $provider ) {
			// Servidor Propio (Apache / Litespeed)
			$htaccess  = "# Apache .htaccess generado por WP Static Architect\n";
			$htaccess .= "<IfModule mod_rewrite.c>\n";
			$htaccess .= "  RewriteEngine On\n";
			$htaccess .= "  RewriteBase /\n";
			$htaccess .= "  DirectoryIndex index.html\n";
			$htaccess .= "  ErrorDocument 404 /404.html\n";
			$htaccess .= "</IfModule>\n";
			@file_put_contents( $target_dir . '.htaccess', $htaccess );
			WP_Static_Arquitect::log( 'Archivo .htaccess generado para servidores Apache / Litespeed.', 'info' );
		}
	}

	/**
	 * Genera sitemap.xml estático conforme al estándar sitemaps.org con dominio canónico.
	 *
	 * @param string $temp_dir Directorio destino.
	 * @param array  $urls     URLs rastreadas.
	 */
	public function generate_sitemap_xml( $temp_dir, $urls ) {
		if ( '0' === get_option( 'wp_static_arquitect_enable_sitemap', '1' ) ) {
			return;
		}

		$target_dir  = trailingslashit( $temp_dir );
		$site_domain = trailingslashit( $this->get_canonical_domain() );

		$xml  = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		$xml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";

		$today = current_time( 'Y-m-d' );

		foreach ( $urls as $u ) {
			$parsed_path = wp_parse_url( $u, PHP_URL_PATH );
			$path        = ! empty( $parsed_path ) ? ltrim( $parsed_path, '/' ) : '';
			$loc         = $site_domain . $path;
			$priority    = ( empty( $path ) || '/' === $path ) ? '1.0' : '0.8';

			$xml .= "  <url>\n";
			$xml .= "    <loc>" . esc_url( $loc ) . "</loc>\n";
			$xml .= "    <lastmod>" . esc_html( $today ) . "</lastmod>\n";
			$xml .= "    <changefreq>weekly</changefreq>\n";
			$xml .= "    <priority>" . $priority . "</priority>\n";
			$xml .= "  </url>\n";
		}

		$xml .= "</urlset>\n";

		@file_put_contents( $target_dir . 'sitemap.xml', $xml );
		WP_Static_Arquitect::log( sprintf( 'sitemap.xml estático generado con éxito (%d URLs).', count( $urls ) ), 'info' );
	}

	/**
	 * Genera robots.txt estático con directivas para motores de búsqueda tradicionales y de IA (GEO).
	 *
	 * @param string $temp_dir Directorio destino.
	 */
	public function generate_robots_txt( $temp_dir ) {
		$target_dir  = trailingslashit( $temp_dir );
		$target_file = $target_dir . 'robots.txt';

		$domain = $this->get_canonical_domain();

		if ( ! file_exists( $target_file ) ) {
			$content  = "# Robots.txt generado por WP Static Architect\n";
			$content .= "User-agent: *\n";
			$content .= "Allow: /\n\n";
			$content .= "Sitemap: " . trailingslashit( $domain ) . "sitemap.xml\n\n";

			// Directivas GEO para Motores de Búsqueda de IA
			if ( '0' !== get_option( 'wp_static_arquitect_enable_geo', '1' ) ) {
				$content .= "# Directivas de Rastreo para Motores de Inteligencia Artificial (GEO)\n";
				$content .= "User-agent: GPTBot\nAllow: /\n\n";
				$content .= "User-agent: ClaudeBot\nAllow: /\n\n";
				$content .= "User-agent: PerplexityBot\nAllow: /\n\n";
				$content .= "User-agent: Google-Extended\nAllow: /\n\n";
				$content .= "User-agent: Applebot-Extended\nAllow: /\n";
			}

			@file_put_contents( $target_file, $content );
			WP_Static_Arquitect::log( 'robots.txt estático generado con éxito (incluyendo directivas GEO para IA).', 'info' );
		}
	}

	/**
	 * Genera llms.txt y llms-full.txt conforme al estándar abierto GEO para motores de búsqueda de IA.
	 *
	 * @param string $temp_dir     Directorio destino.
	 * @param array  $urls         Lista de URLs procesadas.
	 * @param array  $search_items Metadatos extraídos de cada página.
	 */
	public function generate_llms_txt( $temp_dir, $urls, $search_items ) {
		if ( '0' === get_option( 'wp_static_arquitect_enable_geo', '1' ) ) {
			return;
		}

		$target_dir = trailingslashit( $temp_dir );
		$site_name  = get_bloginfo( 'name' );
		$site_desc  = get_bloginfo( 'description' );
		$domain     = $this->get_canonical_domain();

		// 1. Generar llms.txt estándar (directorio de contenido curado para LLMs)
		$llms  = "# " . $site_name . "\n\n";
		if ( ! empty( $site_desc ) ) {
			$llms .= "> " . $site_desc . "\n\n";
		}
		$llms .= "Este archivo sigue el estándar abierto /llms.txt para facilitar a agentes de Inteligencia Artificial (ChatGPT, Claude, Perplexity, Gemini) la lectura, citación y comprensión estructurada de este sitio web.\n\n";
		$llms .= "## Secciones y Páginas Principales\n\n";

		// Agrupar items si están indexados
		if ( ! empty( $search_items ) ) {
			foreach ( $search_items as $item ) {
				$title    = ! empty( $item['title'] ) ? $item['title'] : 'Página sin título';
				$path     = ! empty( $item['url'] ) ? ltrim( $item['url'], '/' ) : '';
				$full_url = trailingslashit( $domain ) . $path;
				$excerpt  = ! empty( $item['excerpt'] ) ? $item['excerpt'] : '';

				$llms .= "- [" . $title . "](" . $full_url . ")";
				if ( ! empty( $excerpt ) ) {
					$llms .= ": " . $excerpt;
				}
				$llms .= "\n";
			}
		} else {
			foreach ( $urls as $u ) {
				$parsed = wp_parse_url( $u, PHP_URL_PATH );
				$path   = ! empty( $parsed ) ? ltrim( $parsed, '/' ) : '';
				$llms  .= "- [" . ( empty( $path ) ? 'Inicio' : $path ) . "](" . trailingslashit( $domain ) . $path . ")\n";
			}
		}

		$llms .= "\n## Enlaces de Referencia Técnica\n";
		$llms .= "- [Sitemap XML](" . trailingslashit( $domain ) . "sitemap.xml): Mapa estructurado de URLs para indexación.\n";
		$llms .= "- [Robots.txt](" . trailingslashit( $domain ) . "robots.txt): Políticas de rastreo y autorización de bots de IA.\n";

		@file_put_contents( $target_dir . 'llms.txt', $llms );
		WP_Static_Arquitect::log( 'Archivo GEO /llms.txt generado con éxito para motores de búsqueda de IA.', 'info' );

		// 2. Generar llms-full.txt si está habilitado
		if ( '1' === get_option( 'wp_static_arquitect_llms_full', '0' ) && ! empty( $search_items ) ) {
			$llms_full  = "# " . $site_name . " (Base de Conocimiento Completa)\n\n";
			$llms_full .= "Resumen textual exhaustivo de todas las entradas y páginas para modelos RAG y asistentes de IA.\n\n---\n\n";

			foreach ( $search_items as $item ) {
				$title    = ! empty( $item['title'] ) ? $item['title'] : 'Documento';
				$path     = ! empty( $item['url'] ) ? ltrim( $item['url'], '/' ) : '';
				$full_url = trailingslashit( $domain ) . $path;
				$content  = ! empty( $item['content'] ) ? $item['content'] : $item['excerpt'];

				$llms_full .= "## " . $title . "\n";
				$llms_full .= "- **URL:** " . $full_url . "\n";
				$llms_full .= "- **Tipo:** " . ( isset( $item['type'] ) ? $item['type'] : 'page' ) . "\n\n";
				$llms_full .= $content . "\n\n---\n\n";
			}

			@file_put_contents( $target_dir . 'llms-full.txt', $llms_full );
			WP_Static_Arquitect::log( 'Archivo GEO extendido /llms-full.txt generado con éxito.', 'info' );
		}
	}

	/**
	 * Ruta al archivo de estado JSON en disco.
	 *
	 * @param string $session_id ID de sesión.
	 * @return string
	 */
	public function get_session_file( $session_id ) {
		$temp_dir = WP_Static_Arquitect::get_upload_dir( 'temp/' . $session_id );
		return trailingslashit( $temp_dir ) . 'session_state.json';
	}

	/**
	 * Lee el estado de la sesión priorizando el archivo en disco sobre la base de datos.
	 *
	 * @param string $session_id ID de sesión.
	 * @return array|false
	 */
	public function get_session_data( $session_id ) {
		$file = $this->get_session_file( $session_id );
		if ( file_exists( $file ) ) {
			$raw = @file_get_contents( $file );
			if ( ! empty( $raw ) ) {
				$data = json_decode( $raw, true );
				if ( is_array( $data ) ) {
					return $data;
				}
			}
		}

		$transient_data = get_transient( 'wpsa_batch_' . $session_id );
		return is_array( $transient_data ) ? $transient_data : false;
	}

	/**
	 * Guarda el estado de la sesión en disco para evitar saturar MySQL y mantiene un transient ligero.
	 *
	 * @param string $session_id ID de sesión.
	 * @param array  $data       Datos de la sesión.
	 */
	public function save_session_data( $session_id, $data ) {
		$file = $this->get_session_file( $session_id );
		$json = wp_json_encode( $data );
		if ( ! empty( $json ) ) {
			@file_put_contents( $file, $json, LOCK_EX );
		}

		$lightweight = array(
			'session_id'      => $session_id,
			'temp_dir'        => isset( $data['temp_dir'] ) ? $data['temp_dir'] : '',
			'status'          => isset( $data['status'] ) ? $data['status'] : 'processing',
			'processed_pages' => isset( $data['processed_pages'] ) ? $data['processed_pages'] : 0,
			'total_pages'     => isset( $data['total_pages'] ) ? $data['total_pages'] : 0,
			'archive'         => isset( $data['archive'] ) ? $data['archive'] : null,
			'deploy'          => isset( $data['deploy'] ) ? $data['deploy'] : null,
		);
		set_transient( 'wpsa_batch_' . $session_id, $lightweight, 7200 );
	}

	/**
	 * Inicializa una sesión de exportación por lotes (Batch Processing).
	 *
	 * @return array
	 */
	public function init_batch_session() {
		$session_id = 'sess_' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 10 );
		$temp_dir   = WP_Static_Arquitect::get_upload_dir( 'temp/' . $session_id );

		WP_Static_Arquitect::log( 'Iniciando descubrimiento de URLs para sesión por lotes: ' . $session_id, 'info' );
		$urls        = $this->discover_urls();
		$total_pages = count( $urls );

		// Copiar recursos del plugin a la carpeta temporal
		$this->copy_plugin_assets( $temp_dir );

		$session_data = array(
			'session_id'        => $session_id,
			'temp_dir'          => $temp_dir,
			'urls'              => $urls,
			'total_pages'       => $total_pages,
			'processed_pages'   => 0,
			'successful_pages'  => 0,
			'failed_urls'       => array(),
			'current_index'     => 0,
			'search_items'      => array(),
			'downloaded_assets' => array(),
			'started_at'        => current_time( 'Y-m-d H:i:s' ),
		);

		$this->save_session_data( $session_id, $session_data );

		WP_Static_Arquitect::log( sprintf( 'Sesión por lotes creada [%s]. %d URLs listas para procesar.', $session_id, $total_pages ), 'info' );

		return array(
			'success'     => true,
			'session_id'  => $session_id,
			'total_pages' => $total_pages,
			'batch_size'  => 2,
		);
	}

	/**
	 * Obtiene el contenido HTML de una página de forma ultra-resiliente:
	 * 1. Petición HTTP simulando navegador real (Chrome moderno) con cookies de sesión de administrador y Cloudflare forwardeadas.
	 * 2. Petición Loopback a 127.0.0.1 / localhost con cabecera Host (omite cortafuegos externos / CDN Cloudflare).
	 * 3. Renderizado interno nativo en memoria de WordPress (sin dependencia de red ni puertos, infalible ante bloqueos WAF).
	 *
	 * @param string $page_url URL a obtener.
	 * @return array { 'success' => bool, 'html' => string, 'strategy' => string, 'error' => string }
	 */
	public function fetch_page_content( $page_url ) {
		// Preparar User-Agent de navegador real sin huellas de bot
		$user_agent = ! empty( $_SERVER['HTTP_USER_AGENT'] )
			? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) )
			: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

		// Cabeceras HTTP estándar de navegador legítimo
		$headers = array(
			'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
			'Accept-Language' => ! empty( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) : 'es-ES,es;q=0.9,en;q=0.8',
			'Cache-Control'   => 'no-cache',
			'Pragma'          => 'no-cache',
		);

		// Forwardear cookies activas de la sesión (incluye tokens de Cloudflare __cf_bm, cf_clearance y sesión de WP)
		$cookies = array();
		if ( ! empty( $_COOKIE ) && is_array( $_COOKIE ) ) {
			foreach ( $_COOKIE as $c_name => $c_val ) {
				if ( is_string( $c_val ) ) {
					$cookies[] = new WP_Http_Cookie( array(
						'name'  => $c_name,
						'value' => $c_val,
					) );
				}
			}
		}

		$request_args = array(
			'timeout'     => 20,
			'sslverify'   => false,
			'redirection' => 5,
			'user-agent'  => $user_agent,
			'headers'     => $headers,
			'cookies'     => $cookies,
		);

		$last_error = '';

		// Estrategia 1: Petición HTTP directa simulando navegador real
		for ( $retry = 0; $retry <= 1; $retry++ ) {
			$response = wp_remote_get( $page_url, $request_args );

			if ( ! is_wp_error( $response ) ) {
				$code = wp_remote_retrieve_response_code( $response );
				if ( 200 === $code ) {
					$html = wp_remote_retrieve_body( $response );
					if ( ! empty( $html ) && false === strpos( $html, 'cf-mitigated' ) && false === strpos( $html, 'challenge-platform' ) ) {
						return array( 'success' => true, 'html' => $html, 'strategy' => 'http_direct', 'error' => '' );
					}
				}
				$last_error = 'HTTP ' . $code;
			} else {
				$last_error = $response->get_error_message();
			}

			if ( $retry < 1 ) {
				usleep( 200000 );
			}
		}

		// Estrategia 2: Petición Loopback a 127.0.0.1 (evita salir a Cloudflare/CDN externo)
		$parsed = wp_parse_url( $page_url );
		$host   = isset( $parsed['host'] ) ? $parsed['host'] : '';
		$path   = isset( $parsed['path'] ) ? $parsed['path'] : '/';
		if ( isset( $parsed['query'] ) ) {
			$path .= '?' . $parsed['query'];
		}

		if ( ! empty( $host ) ) {
			$loopback_args = $request_args;
			$loopback_args['headers']['Host']             = $host;
			$loopback_args['headers']['X-Forwarded-Host']  = $host;
			$loopback_args['headers']['X-Forwarded-Proto'] = 'https';
			$loopback_args['timeout']                     = 10;

			$loopback_urls = array(
				'http://127.0.0.1' . $path,
				'http://localhost' . $path,
			);

			foreach ( $loopback_urls as $lb_url ) {
				$lb_response = wp_remote_get( $lb_url, $loopback_args );
				if ( ! is_wp_error( $lb_response ) && 200 === wp_remote_retrieve_response_code( $lb_response ) ) {
					$html = wp_remote_retrieve_body( $lb_response );
					if ( ! empty( $html ) && false === strpos( $html, 'cf-mitigated' ) ) {
						return array( 'success' => true, 'html' => $html, 'strategy' => 'loopback_local', 'error' => '' );
					}
				}
			}
		}

		// Estrategia 3: Renderizado interno nativo de WordPress en memoria (Sin red)
		$rendered_html = $this->render_page_internally( $page_url );
		if ( ! empty( $rendered_html ) && strlen( $rendered_html ) > 100 ) {
			return array( 'success' => true, 'html' => $rendered_html, 'strategy' => 'in_memory_render', 'error' => '' );
		}

		return array( 'success' => false, 'html' => '', 'strategy' => 'failed', 'error' => $last_error );
	}

	/**
	 * Renderizado nativo interno en memoria de WordPress cuando las peticiones HTTP fallan o están bloqueadas por WAF/Cloudflare.
	 * Ejecuta la consulta interna de WP y captura la salida de la plantilla activa mediante Output Buffering.
	 *
	 * @param string $page_url URL a renderizar.
	 * @return string Código HTML renderizado o cadena vacía si no se pudo.
	 */
	public function render_page_internally( $page_url ) {
		$relative   = wp_make_link_relative( $page_url );
		$path_clean = trim( strtok( $relative, '?' ), '/' );

		// Guardar estado global de WordPress
		global $wp, $wp_query, $wp_the_query, $post;
		$backup_wp        = $wp;
		$backup_wp_query  = $wp_query;
		$backup_the_query = $wp_the_query;
		$backup_post      = $post;
		$backup_uri       = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';

		$_SERVER['REQUEST_URI'] = '/' . ( ! empty( $path_clean ) ? $path_clean . '/' : '' );

		$is_home = empty( $path_clean ) || untrailingslashit( $page_url ) === untrailingslashit( home_url() );

		// Asegurar que las acciones de encolado de estilos/scripts de frontend se registren
		if ( ! did_action( 'wp_enqueue_scripts' ) ) {
			do_action( 'wp_enqueue_scripts' );
		}

		ob_start();

		try {
			if ( $is_home ) {
				$new_query = new WP_Query();
				if ( 'page' === get_option( 'show_on_front' ) && ( $front_id = get_option( 'page_on_front' ) ) ) {
					$new_query->query( array( 'page_id' => $front_id ) );
				} else {
					$new_query->query( array( 'posts_per_page' => get_option( 'posts_per_page', 10 ) ) );
				}
				$GLOBALS['wp_query']     = $new_query;
				$GLOBALS['wp_the_query'] = $new_query;
				if ( $new_query->have_posts() ) {
					$new_query->the_post();
				}

				$template = get_front_page_template();
				if ( empty( $template ) || ! file_exists( $template ) ) {
					$template = get_home_template();
				}
				if ( empty( $template ) || ! file_exists( $template ) ) {
					$template = get_index_template();
				}
				if ( ! empty( $template ) && file_exists( $template ) ) {
					include $template;
				}
			} else {
				$post_id = url_to_postid( $page_url );
				if ( $post_id > 0 ) {
					$new_query = new WP_Query( array(
						'p'         => $post_id,
						'post_type' => 'any',
					) );
					$GLOBALS['wp_query']     = $new_query;
					$GLOBALS['wp_the_query'] = $new_query;
					if ( $new_query->have_posts() ) {
						$new_query->the_post();
					}

					$template = get_single_template();
					if ( empty( $template ) || ! file_exists( $template ) ) {
						$template = get_page_template();
					}
					if ( empty( $template ) || ! file_exists( $template ) ) {
						$template = get_singular_template();
					}
					if ( empty( $template ) || ! file_exists( $template ) ) {
						$template = get_index_template();
					}
					if ( ! empty( $template ) && file_exists( $template ) ) {
						include $template;
					}
				} else {
					// Taxonomías o archivos de autor
					if ( 0 === strpos( $path_clean, 'category/' ) ) {
						$cat_slug  = substr( $path_clean, 9 );
						$new_query = new WP_Query( array( 'category_name' => $cat_slug ) );
						$template  = get_category_template();
					} elseif ( 0 === strpos( $path_clean, 'tag/' ) ) {
						$tag_slug  = substr( $path_clean, 4 );
						$new_query = new WP_Query( array( 'tag' => $tag_slug ) );
						$template  = get_tag_template();
					} elseif ( 0 === strpos( $path_clean, 'author/' ) ) {
						$author_slug = substr( $path_clean, 7 );
						$new_query   = new WP_Query( array( 'author_name' => $author_slug ) );
						$template    = get_author_template();
					} else {
						$custom_wp = new WP();
						$custom_wp->parse_request();
						$new_query = new WP_Query();
						$new_query->query( $custom_wp->query_vars );
						$template  = get_archive_template();
					}

					$GLOBALS['wp_query']     = $new_query;
					$GLOBALS['wp_the_query'] = $new_query;
					if ( $new_query->have_posts() ) {
						$new_query->the_post();
					}

					if ( empty( $template ) || ! file_exists( $template ) ) {
						$template = get_index_template();
					}
					if ( ! empty( $template ) && file_exists( $template ) ) {
						include $template;
					}
				}
			}
		} catch ( \Throwable $t ) {
			WP_Static_Arquitect::log( 'Aviso en renderizado interno: ' . $t->getMessage(), 'warning' );
		}

		$html = ob_get_clean();

		// Restaurar estado global
		$GLOBALS['wp']           = $backup_wp;
		$GLOBALS['wp_query']     = $backup_wp_query;
		$GLOBALS['wp_the_query'] = $backup_the_query;
		$GLOBALS['post']         = $backup_post;
		$_SERVER['REQUEST_URI']  = $backup_uri;
		wp_reset_postdata();

		return $html;
	}

	/**
	 * Procesa un bloque (chunk) de URLs en la sesión activa.
	 *
	 * @param string $session_id ID de sesión activa.
	 * @param int    $batch_size Cantidad de páginas por ciclo.
	 * @return array
	 */
	public function process_batch_step( $session_id, $batch_size = 2 ) {
		$session_data = $this->get_session_data( $session_id );
		if ( ! $session_data || ! is_array( $session_data ) ) {
			return array(
				'success' => false,
				'message' => 'Sesión de exportación no encontrada o expirada.',
			);
		}

		$temp_dir      = $session_data['temp_dir'];
		$urls          = $session_data['urls'];
		$current_index = $session_data['current_index'];
		$total_pages   = $session_data['total_pages'];

		$urls_chunk = array_slice( $urls, $current_index, $batch_size );
		$parser     = WP_Static_Arquitect::get_instance()->html_parser;
		$last_url   = '';

		foreach ( $urls_chunk as $page_url ) {
			$last_url  = $page_url;
			$fetch_res = $this->fetch_page_content( $page_url );

			if ( $fetch_res['success'] && ! empty( $fetch_res['html'] ) ) {
				$html = $fetch_res['html'];
				if ( ! empty( $fetch_res['strategy'] ) && 'http_direct' !== $fetch_res['strategy'] ) {
					WP_Static_Arquitect::log( sprintf( 'Página [%s] capturada mediante estrategia de respaldo (%s).', $page_url, $fetch_res['strategy'] ), 'info' );
				}

				// Indexar para el buscador estático
				if ( '0' !== get_option( 'wp_static_arquitect_enable_search', '1' ) ) {
					$session_data['search_items'][] = $this->extract_search_data_from_html( $html, $page_url );
				}

				$extracted_assets = $this->extract_asset_urls_from_html( $html, $page_url );
				$processed_html   = $parser->process_html( $html, $page_url, $this->site_url );
				$this->save_page_html( $page_url, $processed_html, $temp_dir );

				foreach ( $extracted_assets as $asset_url ) {
					$this->download_asset( $asset_url, $temp_dir );
				}

				if ( ! isset( $session_data['successful_pages'] ) ) {
					$session_data['successful_pages'] = 0;
				}
				$session_data['successful_pages']++;
			} else {
				$err_msg = ! empty( $fetch_res['error'] ) ? $fetch_res['error'] : 'HTTP 403 / Error de red';
				WP_Static_Arquitect::log( sprintf( 'Aviso: No se pudo obtener [%s] tras todas las estrategias: %s', $page_url, $err_msg ), 'warning' );
				$session_data['failed_urls'][] = array( 'url' => $page_url, 'error' => $err_msg );
			}

			$current_index++;
			$session_data['processed_pages']++;
		}

		$session_data['current_index'] = $current_index;
		$this->save_session_data( $session_id, $session_data );

		$percent     = $total_pages > 0 ? min( 100, round( ( $session_data['processed_pages'] / $total_pages ) * 100 ) ) : 100;
		$is_complete = $current_index >= $total_pages;

		return array(
			'success'          => true,
			'session_id'       => $session_id,
			'processed_pages'  => $session_data['processed_pages'],
			'successful_pages' => isset( $session_data['successful_pages'] ) ? $session_data['successful_pages'] : 0,
			'total_pages'      => $total_pages,
			'percent'          => $percent,
			'is_complete'      => $is_complete,
			'current_url'      => $last_url,
		);
	}

	/**
	 * Finaliza la sesión por lotes: genera 404, _redirects, _headers, buscador, sitemap, robots, comprime ZIP y opcionalmente despliega a Netlify.
	 * Soporta ejecución modular en dos fases ('prepare' y 'compress') para garantizar tiempos de respuesta ultrarrápidos y evitar timeouts de servidor.
	 *
	 * @param string $session_id ID de sesión activa.
	 * @param string $phase      Fase de ejecución: 'prepare', 'compress' o 'all'.
	 * @return array
	 */
	public function finalize_batch_session( $session_id, $phase = 'all' ) {
		@set_time_limit( 300 );
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}

		$session_data = $this->get_session_data( $session_id );

		if ( ! $session_data || ! is_array( $session_data ) ) {
			return array(
				'success' => false,
				'message' => 'Sesión no encontrada o expirada al intentar finalizar.',
			);
		}

		// Si esta sesión ya finalizó con éxito en el servidor previamente:
		if ( ! empty( $session_data['status'] ) && 'completed' === $session_data['status'] && ! empty( $session_data['archive'] ) ) {
			return array(
				'success'       => true,
				'phase'         => 'completed',
				'message'       => '¡Exportación estática completada exitosamente!',
				'archive'       => $session_data['archive'],
				'deploy_result' => isset( $session_data['deploy'] ) ? $session_data['deploy'] : null,
			);
		}

		$temp_dir = $session_data['temp_dir'];

		// Fase 1: Generación de archivos auxiliares y configuración
		if ( 'prepare' === $phase || 'all' === $phase ) {
			$this->generate_404_page( $temp_dir );
			$this->generate_hosting_platform_files( $temp_dir );
			$search_items = isset( $session_data['search_items'] ) ? $session_data['search_items'] : array();
			$this->generate_search_index( $temp_dir, $search_items );
			$this->generate_sitemap_xml( $temp_dir, $session_data['urls'] );
			$this->generate_robots_txt( $temp_dir );
			$this->generate_llms_txt( $temp_dir, $session_data['urls'], $search_items );
			$this->copy_additional_files( $temp_dir );

			// Guardián de Integridad: Verificar que index.html sea la portada real y no esté vacía o en 403
			$index_file = trailingslashit( $temp_dir ) . 'index.html';
			$needs_home = true;
			if ( file_exists( $index_file ) ) {
				$content = @file_get_contents( $index_file );
				if ( strlen( $content ) > 250 && false === strpos( $content, 'Directory access forbidden' ) && false === strpos( $content, '403 Forbidden' ) ) {
					$needs_home = false;
				}
			}

			if ( $needs_home ) {
				WP_Static_Arquitect::log( 'Guardián de Integridad: Portada (index.html) ausente o con error 403. Extrayendo página de inicio directamente...', 'warning' );
				$home_url  = home_url( '/' );
				$fetch_res = $this->fetch_page_content( $home_url );
				if ( $fetch_res['success'] && ! empty( $fetch_res['html'] ) ) {
					$html           = $fetch_res['html'];
					$parser         = WP_Static_Arquitect::get_instance()->html_parser;
					$processed_html = $parser->process_html( $html, $home_url, $this->site_url );
					$this->save_page_html( $home_url, $processed_html, $temp_dir );
					$assets         = $this->extract_asset_urls_from_html( $html, $home_url );
					foreach ( $assets as $asset ) {
						$this->download_asset( $asset, $temp_dir );
					}
					WP_Static_Arquitect::log( 'Portada (index.html) verificada y guardada con éxito.', 'success' );
				}
			}

			if ( 'prepare' === $phase ) {
				return array(
					'success' => true,
					'phase'   => 'prepared',
					'message' => 'Archivos auxiliares y configuración generados correctamente.',
				);
			}
		}

		// Fase 2: Empaquetado ZIP de alta velocidad y finalización
		if ( 'compress' === $phase || 'all' === $phase ) {
			// Comprobar que la exportación contenga páginas reales
			$index_file = trailingslashit( $temp_dir ) . 'index.html';
			$has_index  = file_exists( $index_file ) && filesize( $index_file ) > 250;

			// Rescate de emergencia para index.html si no existe antes de empaquetar
			if ( ! $has_index ) {
				$fetch_home = $this->fetch_page_content( home_url( '/' ) );
				if ( $fetch_home['success'] && ! empty( $fetch_home['html'] ) ) {
					$parser         = WP_Static_Arquitect::get_instance()->html_parser;
					$processed_html = $parser->process_html( $fetch_home['html'], home_url( '/' ), $this->site_url );
					$this->save_page_html( home_url( '/' ), $processed_html, $temp_dir );
					$has_index      = file_exists( $index_file ) && filesize( $index_file ) > 250;
				}
			}

			$succ_pages = isset( $session_data['successful_pages'] ) ? (int) $session_data['successful_pages'] : 0;

			if ( ! $has_index && $succ_pages === 0 ) {
				WP_Static_Arquitect::log( 'Error crítico: No se generó ninguna página HTML en la exportación.', 'error' );
				return array(
					'success' => false,
					'message' => 'Error: No se pudo descargar el contenido de las páginas. Comprueba los logs de actividad en el panel.',
				);
			}

			$session_data['status'] = 'compressing';
			$this->save_session_data( $session_id, $session_data );

			$zip_name = 'static-export-' . current_time( 'Y-m-d-His' ) . '.zip';
			$arch_res = WP_Static_Arquitect::get_instance()->archiver->create_archive( $temp_dir, $zip_name );

			if ( ! $arch_res['success'] ) {
				return array(
					'success' => false,
					'message' => $arch_res['message'],
				);
			}

			// Comprobar auto-despliegue a Netlify
			$auto_deploy   = '1' === get_option( 'wp_static_arquitect_netlify_auto_deploy', '0' );
			$deploy_result = null;

			if ( $auto_deploy ) {
				WP_Static_Arquitect::log( 'Auto-despliegue a Netlify activado tras finalizar lote...', 'info' );
				$deploy_result = WP_Static_Arquitect::get_instance()->netlify_forms->deploy_zip( $arch_res['data']['file_path'] );
			}

			// Actualizar sesión con estado completado
			$session_data['status']  = 'completed';
			$session_data['archive'] = $arch_res['data'];
			$session_data['deploy']  = $deploy_result;
			$this->save_session_data( $session_id, $session_data );

			// Limpieza en segundo plano para NO retener la conexión HTTP
			register_shutdown_function( array( $this, 'cleanup_directory' ), $temp_dir );

			WP_Static_Arquitect::log( sprintf( 'Sesión por lotes finalizada exitosamente: %s', $zip_name ), 'success' );

			return array(
				'success'       => true,
				'phase'         => 'completed',
				'message'       => '¡Exportación estática completada exitosamente!' . ( $auto_deploy && ! empty( $deploy_result['success'] ) ? ' Desplegado en Netlify.' : '' ),
				'archive'       => $arch_res['data'],
				'deploy_result' => $deploy_result,
			);
		}

		return array(
			'success' => false,
			'message' => 'Fase de finalización no reconocida.',
		);
	}

	/**
	 * Limpieza recursiva de directorio temporal.
	 *
	 * @param string $dir
	 */
	public function cleanup_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}
		$files = array_diff( scandir( $dir ), array( '.', '..' ) );
		foreach ( $files as $file ) {
			$path = $dir . DIRECTORY_SEPARATOR . $file;
			is_dir( $path ) ? $this->cleanup_directory( $path ) : @unlink( $path );
		}
		@rmdir( $dir );
	}
}
