# WP Static Architect

![WP Static Architect Banner](admin/assets/images/banner.svg)

**WP Static Architect** es el plugin líder de ingeniería Jamstack para WordPress. Transforma sitios dinámicos en paquetes estáticos portátiles, ultrarrápidos y seguros, con inyección automática de funciones *serverless* (formularios en **Netlify**, comentarios en tiempo real con **Supabase PostgreSQL**, optimización **GEO para IAs generativas** y compatibilidad **Multi-Hosting**).

> Desarrollado por **[Xavier Cabello](https://juan.cabellosalirrosas.com)** &bull; [juan.cabellosalirrosas.com](https://juan.cabellosalirrosas.com)

---

## 🚀 Características Principales

- 🤖 **GEO (Generative Engine Optimization para IAs):** Preparado para la era de la IA generativa. Genera automáticamente `llms.txt` y opcionalmente `llms-full.txt` en markdown limpio para modelos como ChatGPT, Claude, Perplexity y Gemini. Añade reglas específicas para bots de IA (`GPTBot`, `ClaudeBot`, `PerplexityBot`, `Google-Extended`, `Applebot-Extended`) en `robots.txt` e inyecta metadatos estructurados Schema.org (JSON-LD) en el `<head>` de cada página estática.
- 🌐 **Compatibilidad Multi-Hosting Automática:** Configura tu destino preferido con 1 clic:
  - **Netlify:** Genera `_redirects` y `_headers` con compresión inmutable y seguridad.
  - **Cloudflare Pages:** Genera `_routes.json` con exclusión inteligente de estáticos.
  - **Vercel:** Genera `vercel.json` con `cleanUrls` y control de `trailingSlash`.
  - **GitHub Pages:** Genera `.nojekyll` y archivo `CNAME` automático.
  - **Servidor Tradicional / Apache:** Genera `.htaccess` con directivas estáticas.
- 🩺 **Diagnóstico de Salud en Tiempo Real (Pre-flight Check):** Audita 8 parámetros críticos del entorno antes de iniciar exportaciones:
  - Versión de PHP (>= 7.4).
  - Extensión `ZipArchive`.
  - Extensión `DOMDocument` y `libxml`.
  - Soporte `cURL`.
  - Extensión `mbstring`.
  - Permisos de escritura en `wp-content/uploads`.
  - Límite de memoria PHP (`memory_limit` >= 128M).
  - Estructura de Enlaces Permanentes (Pretty Permalinks activos).
- 💻 **Integración Nativa con WP-CLI:** Ejecuta exportaciones, despliegues y mantenimiento desde la terminal o cron jobs de servidor:
  - `wp static-architect export [--deploy] [--provider=<provider>]`
  - `wp static-architect status`
  - `wp static-architect purge-forms`
- 🎯 **Gestor de Dominio Personalizado Sin Código (Zero-Code Custom Domain):** Asistente visual con guía de registros DNS (Tipo A y CNAME) y vinculación en 1 clic con la API de Netlify (`PATCH /api/v1/sites/{site_id}`). Reescribe enlaces canónicos, sitemaps y OpenGraph de forma automática.
- 🧩 **Modularidad Total & Toggles (Para Sitios Informativos o Corporativos):**
  - **Formularios Serverless:** Activa o desactiva Netlify Forms. Si se desactiva, los formularios no se transforman ni se inyectan atributos innecesarios.
  - **Comentarios Dinámicos:** Activa o desactiva Supabase Comments. Al desactivarlo, los contenedores `#comments`, `.comments-area` y `#respond` se eliminan por completo del HTML y no se carga ningún script ni recurso externo.
- 🏢 **Perfiles de Servicio (Modo Creador Pro Ilimitado vs Perfil Estándar):**
  - **Modo Creador Pro (Ilimitado):** Máxima potencia desbloqueada de extremo a extremo, sin límites de cuotas, retención histórica completa, empaquetado acelerado y sin purga forzada.
  - **Perfil Estándar:** Purga preventiva programada por cron si se alcanzan umbrales de 80 envíos o 8MB en Netlify para cuentas con cuotas estrictas.
- ⚡ **Motor por Lotes Asíncrono (Anti-Timeout):** Arquitectura de exportación por bloques (*chunks*) comunicada vía AJAX con barra de progreso exacta en tiempo real, garantizando compatibilidad con sitios de cientos de páginas sin cortes por timeout del servidor.
- 🔍 **Buscador Estático Instantáneo (Spotlight Ctrl + K / ⌘ K):** Búsqueda reactiva cliente ultra-ligera (Vanilla JS puro, 0 librerías externas o npm) indexada automáticamente en `search-index.json`. Diseño *Glassmorphism* con soporte automático para temas claros y oscuros, resaltado `<mark>` y navegación completa por teclado.
- 🎯 **Gestor Avanzado de Inclusiones y Exclusiones:** Inclusión de URLs y archivos estáticos sueltos (PDFs, subdirectorios, landings huérfanas) y exclusión granular mediante patrones de subcadena o expresiones regulares con prefijo `regex:`.
- 🗺️ **Generador Nativo de Sitemap & Robots.txt SEO:** Creación automática de `sitemap.xml` con fechas de modificación (`<lastmod>`) y `robots.txt` optimizados para tu dominio estático canónico de producción.
- 🔁 **Despliegue Automático al Publicar (Deploy-on-Save):** Integración nativa con `save_post` para disparar reconstrucciones en Netlify vía *Build Hooks* HTTP POST cada vez que se guarda o actualiza contenido público en WordPress.
- 🛡️ **Protección Anti-Spam con Cloudflare Turnstile:** Protección invisible y sin captchas molestos para el formulario de comentarios de Supabase, validando tokens de verificación de forma transparente.
- 🌐 **Despliegue Directo a Netlify (1-Click Deploy API):** Transferencia binaria automatizada del paquete ZIP a la Deploy API v1 de Netlify sin descargas manuales intermedias, con soporte para auto-despliegue tras cada exportación.
- 📦 **Empaquetado en .ZIP:** Compresión nativa con rotación automática de archivos antiguos y cálculo de sumas de verificación SHA-256.
- 🧭 **Centro de Ayuda & Recorrido Visual Interactivo:** Pestaña integrada con guía completa paso a paso, visualizador de flujo de arquitectura Jamstack, acordeón de FAQ y tour guiado interactivo de 6 diapositivas para nuevos usuarios.

---

## 📊 Tabla Comparativa: WP Static Architect vs Simply Static

| Característica | Simply Static (Free) | WP Static Architect |
|---|---|---|
| **Optimización GEO (IAs / llms.txt)** | ❌ Inexistente | ✅ **Nativo (llms.txt, llms-full.txt, AI bots, JSON-LD)** |
| **Soporte Multi-Hosting** | ❌ Solo Netlify / GitHub en Pro ($100+/año) | ✅ **Netlify, Cloudflare Pages, Vercel, GitHub, Apache** |
| **Diagnóstico de Salud (Pre-flight)** | ❌ Limitado | ✅ **Auditoría automática de 8 parámetros en tiempo real** |
| **Integración WP-CLI** | ❌ Solo versión Pro | ✅ **Nativo (`wp static-architect export`, `status`, etc.)** |
| **Dominio Sin Código + 1-Click Link** | ❌ Manual y complejo | ✅ **Asistente DNS + Vinculación 1-Clic Netlify API** |
| **Modularidad (Toggles Limpios)** | ❌ Código estático rígido | ✅ **Desactivación 100% limpia de formularios y comentarios** |
| **Perfiles de Servicio (Creador Pro / Estándar)** | ❌ Sin control de planes | ✅ **Modo Creador Pro Ilimitado / Protección inteligente** |
| **Buscador Estático** | ❌ Requiere Algolia de pago o plugin extra | ✅ **Nativo Spotlight (Ctrl+K), 0 dependencias** |
| **Comentarios Dinámicos** | ❌ No disponible en versión gratuita | ✅ **Supabase PostgREST + RLS en tiempo real** |
| **Protección Anti-Spam** | ❌ No integrada | ✅ **Cloudflare Turnstile Invisible integrado** |
| **Formularios de Contacto** | ❌ Requiere servicios externos de pago | ✅ **Netlify Forms nativos (`data-netlify`)** |
| **Purga de Formularios** | ❌ Sin control de cuotas | ✅ **Purgador automático por cron y manual (API v1)** |
| **Despliegue a Netlify** | ❌ Manual (descargar zip y subir) | ✅ **1-Click Binary Deploy + Auto-Deploy API** |
| **Deploy-on-Save** | ❌ Solo en Simply Static Pro ($100+/año) | ✅ **Nativo con Netlify Build Hooks en `save_post`** |
| **Sitemap & Robots.txt** | ⚠️ Requiere plugins SEO pesados | ✅ **Generador nativo automático optimizado** |
| **Inclusiones / Exclusiones** | ⚠️ Solo rutas simples | ✅ **URLs, archivos sueltos y soporte Regex** |
| **Moderación de Comentarios** | ❌ Inexistente | ✅ **Bandeja de moderación integrada en WP** |

---

## 💻 Automatización con WP-CLI

WP Static Architect incluye soporte nativo completo para **WP-CLI**, permitiendo programar exportaciones automáticas desde crontab o pipelines CI/CD:

```bash
# 1. Comprobar el estado del sistema, configuración y última exportación
wp static-architect status

# 2. Ejecutar una exportación estática completa
wp static-architect export

# 3. Exportar y desplegar inmediatamente a Netlify
wp static-architect export --deploy

# 4. Exportar generando artefactos específicos para Cloudflare Pages
wp static-architect export --provider=cloudflare

# 5. Ejecutar la purga de formularios antiguos en Netlify manualmente
wp static-architect purge-forms
```

---

## 📁 Estructura de Directorios

```text
wp-static-arquitect/
├── wp-static-arquitect.php         # Archivo principal, hooks, action links y CLI boot
├── uninstall.php                   # Limpieza segura al desinstalar
├── README.md                       # Documentación técnica completa
├── admin/                          # Panel de control en WordPress
│   ├── class-admin.php             # Menú, opciones, Pre-flight check y controladores AJAX
│   ├── views/
│   │   └── settings-page.php       # Interfaz con 7 pestañas, consola terminal y modal tour
│   └── assets/
│       ├── css/admin.css           # Estilos modernos del dashboard y pre-flight check
│       ├── js/admin.js             # Lógica AJAX, tour modal interactivo y terminal
│       └── images/
│           ├── logo.svg            # Isotipo oficial vectorizado (cristal 3D y circuitos)
│           └── banner.svg          # Banner oficial vectorizado (Jamstack Architect)
├── core/                           # Motor principal del plugin
│   ├── class-cli.php               # Comandos nativos WP-CLI (export, status, purge-forms)
│   ├── class-crawler.php           # Rastreo por lotes, GEO llms.txt, robots y assets
│   ├── class-html-parser.php       # Analizador DOM, inyección Spotlight y comentarios
│   └── class-archiver.php          # Generador de compresión ZIP con SHA-256
├── modules/                        # Integraciones de terceros
│   ├── class-netlify-forms.php     # Formularios, purga API v1, DNS link y Build Hooks
│   └── class-supabase-comments.php # Bootstrap BD, RLS, moderation y Turnstile
└── templates/                      # Plantillas frontend inyectadas (0 npm)
    ├── search-modal.html           # Modal semántico Spotlight para búsqueda
    ├── search-client.js            # Cliente Vanilla JS de búsqueda tokenizada
    ├── search-modal.css            # Estilos Glassmorphism claro/oscuro
    ├── supabase-comments.html      # Estructura semántica con slot Turnstile
    ├── supabase-comments.js        # Cliente JavaScript nativo PostgREST + Turnstile
    └── supabase-comments.css       # Estilos CSS modernos con modo oscuro
```

---

## 🗄️ Esquema de Base de Datos (Supabase)

La tabla de comentarios se estructura de la siguiente manera:

| Columna | Tipo | Descripción |
|---|---|---|
| `id` | `uuid` | Primary Key generada automáticamente (`gen_random_uuid()`). |
| `post_slug` | `text` | Identificador de la página/post donde se realizó el comentario (indexado). |
| `author_name` | `text` | Nombre del autor del comentario. |
| `author_email` | `text` | Correo electrónico del autor (opcional). |
| `content` | `text` | Texto del mensaje. |
| `created_at` | `timestamptz` | Marca temporal de publicación (`now()`). |
| `is_approved` | `boolean` | Estado de moderación (`false` o `true` según configuración). |

### Script SQL DDL y Políticas RLS

```sql
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS public.comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_slug TEXT NOT NULL,
    author_name TEXT NOT NULL,
    author_email TEXT,
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_approved BOOLEAN NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS idx_comments_post_slug ON public.comments(post_slug);

ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;

-- Lectura pública de comentarios aprobados
CREATE POLICY "Permitir lectura de comentarios aprobados"
ON public.comments FOR SELECT
TO anon, authenticated
USING (is_approved = true);

-- Inserción de comentarios anónimos
CREATE POLICY "Permitir insercion anonima de comentarios"
ON public.comments FOR INSERT
TO anon, authenticated
WITH CHECK (true);
```

---

## 🛠️ Instalación y Configuración Rápida

1. Copia la carpeta `wp-static-arquitect` dentro de `wp-content/plugins/` en tu instalación de WordPress.
2. Activa el plugin desde el panel de **Plugins**.
3. Verás enlaces directos rápidos en la lista de plugins: **Ajustes**, **Exportar** y **Guía Visual**.
4. Dirígete a **Static Architect** en el menú lateral.
5. Revisa el **Pre-flight Check** en la pestaña de exportación para asegurar que tu servidor cumple con los requisitos óptimos.
6. Elige tu proveedor de alojamiento (**Netlify**, **Cloudflare Pages**, **Vercel**, **GitHub Pages** o **Servidor Tradicional**).
7. Ingresa tus credenciales en la pestaña **Hosting, Dominio & APIs**:
   - **Netlify:** Personal Access Token (PAT) y Site ID.
   - **Supabase:** Project URL, Anon Key pública y Service Role Key (opcional para 1-click bootstrap).
8. Configura el **Motor GEO para IAs** y el **Buscador Spotlight** en la pestaña correspondiente.
9. Ve a la pestaña **Exportador Estático** y pulsa **Iniciar Exportación Estática**.
10. Descarga el paquete `.zip` generado con verificación SHA-256 o pulsa **Desplegar ahora a Netlify** para publicación instantánea.

---

## ⚙️ Requisitos del Sistema

- **PHP:** 7.4 o superior (100% compatible con PHP 8.0, 8.1, 8.2 y 8.3).
- **Extensiones PHP:** `zip`, `dom`, `libxml`, `mbstring`, `curl`.
- **WordPress:** 5.8 o superior.
- **WP-CLI:** Opcional (para automatización por terminal o cron jobs).

---

## 👨‍💻 Desarrollado por

**Xavier Cabello (Juan Xavier)**
- 🌐 Sitio Web Oficial: [juan.cabellosalirrosas.com](https://juan.cabellosalirrosas.com)
- 🐙 GitHub: [juanxaviercasa](https://github.com/juanxaviercasa)
- ✉️ Correo de Contacto: [juanxaviercasa@gmail.com](mailto:juanxaviercasa@gmail.com)
- 🚀 Especialista en Rendimiento Web, Arquitecturas Jamstack & Desarrollo WordPress Serverless.

