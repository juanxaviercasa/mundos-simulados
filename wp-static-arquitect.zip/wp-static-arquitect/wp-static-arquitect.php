<?php
/**
 * Plugin Name:       WP Static Architect
 * Plugin URI:        https://github.com/juanxaviercasa/wp-static-arquitect
 * Description:       Convierte WordPress dinámico en un sitio estático ultra-rápido con arquitectura anti-timeout, persistencia JSON en disco y reintentos automáticos.
 * Version:           1.1.4
 * Author:            Xavier Cabello
 * Author URI:        https://juan.cabellosalirrosas.com
 * License:           GPL-2.0-or-later
 * Text Domain:       wp-static-arquitect
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Salida directa si se accede fuera de WordPress
}

define( 'WP_STATIC_ARQUITECT_VERSION', '1.1.4' );
define( 'WP_STATIC_ARQUITECT_FILE', __FILE__ );
define( 'WP_STATIC_ARQUITECT_PATH', plugin_dir_path( __FILE__ ) );
define( 'WP_STATIC_ARQUITECT_URL', plugin_dir_url( __FILE__ ) );

/**
 * Clase principal de coordinación del plugin.
 */
final class WP_Static_Arquitect {

	/**
	 * Instancia única (Singleton).
	 *
	 * @var WP_Static_Arquitect|null
	 */
	private static $instance = null;

	/**
	 * Instancia del Crawler.
	 *
	 * @var WP_Static_Arquitect_Crawler
	 */
	public $crawler;

	/**
	 * Instancia del Analizador HTML.
	 *
	 * @var WP_Static_Arquitect_HTML_Parser
	 */
	public $html_parser;

	/**
	 * Instancia del Archivador ZIP.
	 *
	 * @var WP_Static_Arquitect_Archiver
	 */
	public $archiver;

	/**
	 * Instancia del Motor de Recomendación Inteligente.
	 *
	 * @var WP_Static_Arquitect_Site_Analyzer
	 */
	public $site_analyzer;

	/**
	 * Instancia del Gestor Multi-Hosting de Despliegue.
	 *
	 * @var WP_Static_Arquitect_Multi_Deployer
	 */
	public $multi_deployer;

	/**
	 * Instancia del Publicador de Pinterest.
	 *
	 * @var WP_Static_Arquitect_Pinterest_Publisher
	 */
	public $pinterest_publisher;

	/**
	 * Instancia del Módulo de Netlify.
	 *
	 * @var WP_Static_Arquitect_Netlify_Forms
	 */
	public $netlify_forms;

	/**
	 * Instancia del Módulo de Supabase.
	 *
	 * @var WP_Static_Arquitect_Supabase_Comments
	/**
	 * Instancia del Módulo de Supabase.
	 *
	 * @var WP_Static_Arquitect_Supabase_Comments
	 */
	public $supabase_comments;

	/**
	 * Instancia del Generador de Artículos con IA (SEO & GEO).
	 *
	 * @var WP_Static_Arquitect_AI_Article_Generator
	 */
	public $ai_article_generator;

	/**
	 * Instancia del Controlador de Administración.
	 *
	 * @var WP_Static_Arquitect_Admin
	 */
	public $admin;

	/**
	 * Obtener la instancia única.
	 *
	 * @return WP_Static_Arquitect
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor privado.
	 */
	private function __construct() {
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Carga de dependencias.
	 */
	private function includes() {
		// Núcleo
		require_once WP_STATIC_ARQUITECT_PATH . 'core/class-crawler.php';
		require_once WP_STATIC_ARQUITECT_PATH . 'core/class-html-parser.php';
		require_once WP_STATIC_ARQUITECT_PATH . 'core/class-archiver.php';
		require_once WP_STATIC_ARQUITECT_PATH . 'core/class-site-analyzer.php';
		require_once WP_STATIC_ARQUITECT_PATH . 'core/class-multi-deployer.php';
		require_once WP_STATIC_ARQUITECT_PATH . 'core/class-pinterest-publisher.php';
		require_once WP_STATIC_ARQUITECT_PATH . 'core/class-ai-article-generator.php';

		// Módulos
		require_once WP_STATIC_ARQUITECT_PATH . 'modules/class-netlify-forms.php';
		require_once WP_STATIC_ARQUITECT_PATH . 'modules/class-supabase-comments.php';

		// Administración
		if ( is_admin() || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
			require_once WP_STATIC_ARQUITECT_PATH . 'admin/class-admin.php';
		}

		// WP-CLI
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			require_once WP_STATIC_ARQUITECT_PATH . 'core/class-cli.php';
		}
	}

	/**
	 * Inicialización de componentes y ganchos (hooks).
	 */
	private function init_hooks() {
		// Instanciación de componentes
		$this->crawler              = new WP_Static_Arquitect_Crawler();
		$this->html_parser          = new WP_Static_Arquitect_HTML_Parser();
		$this->archiver             = new WP_Static_Arquitect_Archiver();
		$this->site_analyzer        = new WP_Static_Arquitect_Site_Analyzer();
		$this->multi_deployer       = new WP_Static_Arquitect_Multi_Deployer();
		$this->pinterest_publisher  = new WP_Static_Arquitect_Pinterest_Publisher();
		$this->ai_article_generator = new WP_Static_Arquitect_AI_Article_Generator();
		$this->netlify_forms        = new WP_Static_Arquitect_Netlify_Forms();
		$this->supabase_comments    = new WP_Static_Arquitect_Supabase_Comments();

		if ( is_admin() || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
			$this->admin = new WP_Static_Arquitect_Admin( $this );
		}

		// Garantizar perfil Modo Creador Pro desbloqueado por defecto
		$current_tier = get_option( 'wp_static_arquitect_service_tier', 'creator_pro' );
		if ( empty( $current_tier ) || 'free' === $current_tier ) {
			update_option( 'wp_static_arquitect_service_tier', 'creator_pro' );
		}

		// Enlaces de acción y meta en la lista de plugins
		add_filter( 'plugin_action_links_' . plugin_basename( WP_STATIC_ARQUITECT_FILE ), array( $this, 'filter_plugin_action_links' ) );
		add_filter( 'plugin_row_meta', array( $this, 'filter_plugin_row_meta' ), 10, 2 );

		// Registro de eventos cron
		add_action( 'wp_static_arquitect_weekly_purge_cron', array( $this->netlify_forms, 'execute_cron_purge' ) );

		// Disparadores automáticos al publicar, actualizar o liberar entradas programadas (Deploy-on-Save)
		add_action( 'save_post', array( $this, 'on_save_post' ), 20, 3 );
		add_action( 'publish_future_post', array( $this, 'on_publish_future_post' ), 20, 1 );
		add_action( 'transition_post_status', array( $this, 'on_transition_post_status' ), 20, 3 );
		add_action( 'wp_static_arquitect_async_export_deploy', array( $this, 'run_background_export_deploy' ) );

		// Despliegue programado diario a hora fija (Smart Batch Deploy)
		add_action( 'wp_static_arquitect_daily_scheduled_deploy_cron', array( $this, 'execute_scheduled_daily_deploy' ) );
		add_action( 'update_option_wp_static_arquitect_scheduled_deploy_enabled', array( 'WP_Static_Arquitect', 'sync_scheduled_deploy_cron' ) );
		add_action( 'update_option_wp_static_arquitect_scheduled_deploy_time', array( 'WP_Static_Arquitect', 'sync_scheduled_deploy_cron' ) );
	}

	/**
	 * Añade enlaces directos en la pantalla de Plugins instalados.
	 *
	 * @param array $links
	 * @return array
	 */
	public function filter_plugin_action_links( $links ) {
		$custom_links = array(
			'<a href="' . esc_url( admin_url( 'admin.php?page=wp-static-arquitect' ) ) . '"><strong>' . __( 'Ajustes', 'wp-static-arquitect' ) . '</strong></a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=wp-static-arquitect&tab=tab-export' ) ) . '">' . __( 'Exportar', 'wp-static-arquitect' ) . '</a>',
			'<a href="' . esc_url( admin_url( 'admin.php?page=wp-static-arquitect&tab=tab-guide' ) ) . '">' . __( 'Guía Visual', 'wp-static-arquitect' ) . '</a>',
		);
		return array_merge( $custom_links, $links );
	}

	/**
	 * Añade enlaces de autoría y soporte en la fila de plugins instalados.
	 *
	 * @param array  $links
	 * @param string $file
	 * @return array
	 */
	public function filter_plugin_row_meta( $links, $file ) {
		if ( plugin_basename( WP_STATIC_ARQUITECT_FILE ) === $file ) {
			$custom_links = array(
				'<a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer"><strong>Desarrollado por Xavier Cabello</strong></a>',
				'<a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer">Sitio Web Oficial</a>',
			);
			return array_merge( $links, $custom_links );
		}
		return $links;
	}

	/**
	 * Gancho save_post: dispara auto-despliegue si la entrada se guarda directamente como publicada.
	 *
	 * @param int     $post_id
	 * @param WP_Post $post
	 * @param bool    $update
	 */
	public function on_save_post( $post_id, $post, $update ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( ! isset( $post->post_status ) || 'publish' !== $post->post_status ) {
			return;
		}

		$this->maybe_trigger_auto_deploy( $post_id, $post );
	}

	/**
	 * Gancho publish_future_post: se ejecuta automáticamente por WP-Cron cuando llega
	 * la fecha y hora de una entrada programada (Scheduled Post).
	 *
	 * @param int $post_id
	 */
	public function on_publish_future_post( $post_id ) {
		$post = get_post( $post_id );
		if ( $post ) {
			WP_Static_Arquitect::log( sprintf( 'Entrada programada liberada por WP-Cron [#%d: %s].', $post_id, $post->post_title ), 'info' );
			$this->maybe_trigger_auto_deploy( $post_id, $post );
		}
	}

	/**
	 * Gancho transition_post_status: detecta cuando cualquier contenido pasa a estado 'publish'.
	 *
	 * @param string  $new_status
	 * @param string  $old_status
	 * @param WP_Post $post
	 */
	public function on_transition_post_status( $new_status, $old_status, $post ) {
		if ( 'publish' === $new_status && 'publish' !== $old_status && $post instanceof WP_Post ) {
			$this->maybe_trigger_auto_deploy( $post->ID, $post );
		}
	}

	/**
	 * Evalúa y ejecuta el auto-despliegue hacia el hosting configurado si está habilitado en los ajustes.
	 *
	 * @param int          $post_id
	 * @param WP_Post|null $post
	 */
	public function maybe_trigger_auto_deploy( $post_id, $post = null ) {
		if ( ! $post ) {
			$post = get_post( $post_id );
		}
		if ( ! $post ) {
			return;
		}

		$post_types = get_post_types( array( 'public' => true ), 'names' );
		if ( ! in_array( $post->post_type, $post_types, true ) ) {
			return;
		}

		$deploy_on_save = '1' === get_option( 'wp_static_arquitect_deploy_on_save', '0' );
		if ( ! $deploy_on_save ) {
			return;
		}

		// Debouncing: evitar ejecuciones duplicadas en menos de 10 segundos
		$transient_key = 'wpsa_auto_deploy_lock';
		if ( get_transient( $transient_key ) ) {
			return;
		}
		set_transient( $transient_key, 1, 10 );

		$provider = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );
		WP_Static_Arquitect::log( sprintf( 'Publicación detectada [#%d: %s]. Disparando auto-despliegue hacia %s...', $post_id, $post->post_title, strtoupper( $provider ) ), 'info' );

		if ( 'cloudflare' === $provider ) {
			$this->multi_deployer->deploy_to_cloudflare();
		} elseif ( 'render' === $provider ) {
			$this->multi_deployer->deploy_to_render();
		} elseif ( 'github' === $provider ) {
			$this->multi_deployer->deploy_to_github();
		} else {
			// Netlify
			$build_hook = get_option( 'wp_static_arquitect_netlify_build_hook', '' );
			if ( ! empty( $build_hook ) ) {
				$this->netlify_forms->trigger_build_hook( $build_hook );
				return;
			}

			$creds = $this->netlify_forms->get_credentials();
			if ( ! empty( $creds['pat'] ) && ! empty( $creds['site_id'] ) ) {
				if ( ! wp_next_scheduled( 'wp_static_arquitect_async_export_deploy' ) ) {
					WP_Static_Arquitect::log( sprintf( 'Publicación detectada [#%d: %s]. Programando auto-exportación y despliegue a Netlify...', $post_id, $post->post_title ), 'info' );
					wp_schedule_single_event( time() + 5, 'wp_static_arquitect_async_export_deploy' );
				}
			}
		}
	}

	/**
	 * Tarea asíncrona: ejecuta exportación y despliegue directo en segundo plano.
	 */
	public function run_background_export_deploy() {
		@set_time_limit( 300 );
		WP_Static_Arquitect::log( 'Ejecutando exportación y auto-despliegue en segundo plano tras publicación...', 'info' );

		$result = $this->crawler->run();

		if ( ! empty( $result['success'] ) && ! empty( $result['archive']['file_path'] ) ) {
			$deploy_res = $this->multi_deployer->deploy( $result['archive']['file_path'] );
			if ( ! empty( $deploy_res['success'] ) ) {
				WP_Static_Arquitect::log( sprintf( '¡Sitio estático actualizado y desplegado a %s automáticamente en segundo plano!', strtoupper( isset( $deploy_res['provider'] ) ? $deploy_res['provider'] : 'hosting' ) ), 'success' );
			}
		}
	}

	/**
	 * Ejecuta el ciclo de despliegue programado diario a la hora configurada por el usuario.
	 */
	public function execute_scheduled_daily_deploy() {
		$enabled = '1' === get_option( 'wp_static_arquitect_scheduled_deploy_enabled', '0' );
		if ( ! $enabled ) {
			return;
		}

		WP_Static_Arquitect::log( 'Iniciando ciclo de despliegue diario programado...', 'info' );

		$smart_check = '1' === get_option( 'wp_static_arquitect_scheduled_deploy_smart_check', '1' );
		if ( $smart_check ) {
			$diff = $this->get_content_changes_since_last_deploy();
			if ( empty( $diff['has_changes'] ) ) {
				WP_Static_Arquitect::log( 'Despliegue programado omitido: no se detectó contenido nuevo ni actualizado desde el último despliegue.', 'info' );
				return;
			}
			WP_Static_Arquitect::log(
				sprintf(
					'Cambios detectados: %d entrada(s) nueva(s) y %d modificada(s). Procediendo con la exportación y despliegue programado...',
					$diff['new_count'],
					$diff['modified_count']
				),
				'info'
			);
		}

		@set_time_limit( 300 );

		// 1. Ciclo Drip-Feed Editorial: publicar progresivamente cuota diaria con Humanizador Editorial
		$drip_enabled = '1' === get_option( 'wp_static_arquitect_drip_feed_enabled', '0' );
		$drip_count   = (int) get_option( 'wp_static_arquitect_drip_posts_count', 5 );
		if ( $drip_enabled && $drip_count > 0 ) {
			WP_Static_Arquitect::log( sprintf( 'Ciclo Drip-Feed activo: ejecutando Humanizador Editorial para hasta %d post(s)...', $drip_count ), 'info' );
			$this->humanize_drip_feed_posts( $drip_count, null, true );
		}

		// 2. Disparo de Pinterest Auto-Pin para publicaciones del ciclo
		$pinterest_auto = '1' === get_option( 'wp_static_arquitect_pinterest_auto_pin', '0' );
		if ( $pinterest_auto ) {
			$this->pinterest_publisher->sync_recent_posts( $drip_count );
		}

		$provider = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );

		// Si el proveedor seleccionado se dispara por webhook sin requerir exportación ZIP completa:
		if ( 'cloudflare' === $provider && ! empty( get_option( 'wp_static_arquitect_cloudflare_deploy_hook', '' ) ) ) {
			$this->multi_deployer->deploy_to_cloudflare();
			return;
		}
		if ( 'render' === $provider ) {
			$this->multi_deployer->deploy_to_render();
			return;
		}
		if ( 'netlify' === $provider && ! empty( get_option( 'wp_static_arquitect_netlify_build_hook', '' ) ) ) {
			$this->netlify_forms->trigger_build_hook();
			return;
		}

		// En caso de despliegue directo por ZIP o API:
		WP_Static_Arquitect::log( sprintf( 'Generando paquete estático para despliegue diario programado hacia %s...', strtoupper( $provider ) ), 'info' );
		$result = $this->crawler->run();
		if ( ! empty( $result['success'] ) && ! empty( $result['archive']['file_path'] ) ) {
			$deploy_res = $this->multi_deployer->deploy( $result['archive']['file_path'] );
			if ( ! empty( $deploy_res['success'] ) ) {
				WP_Static_Arquitect::log( sprintf( '¡Despliegue diario programado a %s completado con éxito!', strtoupper( isset( $deploy_res['provider'] ) ? $deploy_res['provider'] : 'hosting' ) ), 'success' );
			}
		}
	}

	/**
	 * Humanizador Editorial de Fechas y Horas (Drip-Feed FIFO Scheduler).
	 *
	 * Toma las entradas más antiguas en borrador o programadas (generadas en lote con IA)
	 * y les asigna horas realistas escalonadas dentro de la franja diurna (08:30 a 21:30)
	 * con variación aleatoria (jitter de minutos y segundos) para simular un equipo humano.
	 *
	 * @param int         $count       Número de entradas a procesar (por defecto 5).
	 * @param string|null $target_date Fecha objetivo (Y-m-d). Por defecto la fecha actual local.
	 * @param bool        $publish_now Si es true cambia el estado a 'publish'. Si es false a 'future'.
	 * @return array
	 */
	public function humanize_drip_feed_posts( $count = 5, $target_date = null, $publish_now = true ) {
		$count = max( 1, min( 50, (int) $count ) );

		if ( empty( $target_date ) ) {
			$target_date = current_time( 'Y-m-d' );
		}

		$drip_posts = get_posts( array(
			'post_type'      => 'post',
			'post_status'    => array( 'draft', 'future' ),
			'posts_per_page' => $count,
			'orderby'        => 'date',
			'order'          => 'ASC',
		) );

		if ( empty( $drip_posts ) ) {
			return array(
				'success' => false,
				'message' => 'No se encontraron entradas en borrador o programadas para humanizar.',
				'count'   => 0,
				'posts'   => array(),
			);
		}

		$total     = count( $drip_posts );
		$processed = array();

		// Ventana diurna: 08:30 (510 min) a 21:30 (1290 min) = 780 minutos de franja activa
		$start_min = 510;  // 08:30
		$end_min   = 1290; // 21:30
		$window    = $end_min - $start_min;

		$step = ( $total > 1 ) ? floor( $window / ( $total - 1 ) ) : 0;

		foreach ( $drip_posts as $index => $dp ) {
			if ( 1 === $total ) {
				$assigned_min = wp_rand( 570, 1020 ); // Entre 09:30 y 17:00 si es un solo post
			} else {
				$base_min = $start_min + ( $index * $step );
				$jitter   = wp_rand( -20, 20 ); // Jitter de +- 20 minutos
				$assigned_min = max( $start_min, min( $end_min, $base_min + $jitter ) );
			}

			$hour = floor( $assigned_min / 60 );
			$min  = $assigned_min % 60;
			$sec  = wp_rand( 0, 59 );

			$local_time_str = sprintf( '%s %02d:%02d:%02d', $target_date, $hour, $min, $sec );
			$gmt_time_str   = get_gmt_from_date( $local_time_str );

			$status = $publish_now ? 'publish' : 'future';

			wp_update_post( array(
				'ID'            => $dp->ID,
				'post_date'     => $local_time_str,
				'post_date_gmt' => $gmt_time_str,
				'post_status'   => $status,
				'edit_date'     => true,
			) );

			$processed[] = array(
				'id'         => $dp->ID,
				'title'      => $dp->post_title,
				'local_time' => $local_time_str,
				'status'     => $status,
			);

			WP_Static_Arquitect::log(
				sprintf(
					'Humanizador Editorial: Entrada [#%d: %s] asignada a %s (Estado: %s).',
					$dp->ID,
					$dp->post_title,
					$local_time_str,
					strtoupper( $status )
				),
				'success'
			);
		}

		return array(
			'success' => true,
			'message' => sprintf( '¡%d entrada(s) humanizadas exitosamente con horas escalonadas!', count( $processed ) ),
			'count'   => count( $processed ),
			'posts'   => $processed,
		);
	}

	/**
	 * Analiza si hay entradas publicadas o modificadas desde el último despliegue.
	 *
	 * @return array Información con 'has_changes', 'new_count', 'modified_count', 'last_deploy'.
	 */
	public function get_content_changes_since_last_deploy() {
		$last_deploy = get_option( 'wp_static_arquitect_last_deploy_info', null );
		$deployed_at = ! empty( $last_deploy['deployed_at'] ) ? $last_deploy['deployed_at'] : null;

		if ( empty( $deployed_at ) ) {
			return array(
				'has_changes'    => true,
				'new_count'      => 0,
				'modified_count' => 0,
				'last_deploy'    => null,
				'message'        => __( 'Aún no se ha realizado ningún despliegue previo.', 'wp-static-arquitect' ),
			);
		}

		global $wpdb;
		$post_types = get_post_types( array( 'public' => true ), 'names' );
		unset( $post_types['attachment'] );
		$placeholders = implode( "','", array_map( 'esc_sql', $post_types ) );

		// Entradas publicadas después del último despliegue
		$new_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID) FROM {$wpdb->posts}
				 WHERE post_status = 'publish'
				 AND post_type IN ('$placeholders')
				 AND post_date > %s",
				$deployed_at
			)
		);

		// Entradas modificadas después del último despliegue (excluyendo las recién creadas)
		$modified_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID) FROM {$wpdb->posts}
				 WHERE post_status = 'publish'
				 AND post_type IN ('$placeholders')
				 AND post_modified > %s
				 AND post_date <= %s",
				$deployed_at,
				$deployed_at
			)
		);

		$has_changes = ( $new_count > 0 || $modified_count > 0 );

		return array(
			'has_changes'    => $has_changes,
			'new_count'      => $new_count,
			'modified_count' => $modified_count,
			'last_deploy'    => $deployed_at,
		);
	}

	/**
	 * Sincroniza y recalcula el evento cron diario según la hora configurada por el usuario.
	 */
	public static function sync_scheduled_deploy_cron() {
		$cron_hook = 'wp_static_arquitect_daily_scheduled_deploy_cron';
		$timestamp = wp_next_scheduled( $cron_hook );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, $cron_hook );
		}

		$enabled = '1' === get_option( 'wp_static_arquitect_scheduled_deploy_enabled', '0' );
		if ( ! $enabled ) {
			return;
		}

		$next_ts = self::get_next_scheduled_deploy_timestamp();
		wp_schedule_event( $next_ts, 'daily', $cron_hook );

		WP_Static_Arquitect::log(
			sprintf(
				'Cron de despliegue diario configurado para las %s. Próxima ejecución: %s',
				get_option( 'wp_static_arquitect_scheduled_deploy_time', '23:00' ),
				date_i18n( 'Y-m-d H:i:s', $next_ts )
			),
			'info'
		);
	}

	/**
	 * Calcula el timestamp UTC exacto de la próxima ejecución según la hora local configurada.
	 *
	 * @return int
	 */
	public static function get_next_scheduled_deploy_timestamp() {
		$time_str = get_option( 'wp_static_arquitect_scheduled_deploy_time', '23:00' );
		if ( empty( $time_str ) || ! preg_match( '/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/', $time_str ) ) {
			$time_str = '23:00';
		}

		$tz  = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
		$now = new DateTime( 'now', $tz );

		list( $hours, $minutes ) = explode( ':', $time_str );
		$target = clone $now;
		$target->setTime( (int) $hours, (int) $minutes, 0 );

		if ( $target <= $now ) {
			$target->modify( '+1 day' );
		}

		return $target->getTimestamp();
	}

	/**
	 * Obtiene la instancia del generador de artículos con IA.
	 *
	 * @return WP_Static_Arquitect_AI_Article_Generator
	 */
	public function get_ai_article_generator() {
		return $this->ai_article_generator;
	}

	/**
	 * Obtiene la ruta base del directorio de almacenamiento en uploads.
	 *
	 * @param string $sub Subdirectorio ('temp', 'exports', 'logs').
	 * @return string Ruta absoluta.
	 */
	public static function get_upload_dir( $sub = '' ) {
		$upload_dir = wp_upload_dir();
		$base_dir   = trailingslashit( $upload_dir['basedir'] ) . 'wp-static-arquitect';

		if ( ! empty( $sub ) ) {
			$base_dir = trailingslashit( $base_dir ) . ltrim( $sub, '/\\' );
		}

		if ( ! file_exists( $base_dir ) ) {
			wp_mkdir_p( $base_dir );
			// Protección de navegación en directorios protegidos (exports, logs), NUNCA en la raíz temporal de exportación
			if ( false === strpos( $sub, 'temp' ) ) {
				$index_file = trailingslashit( $base_dir ) . 'index.html';
				if ( ! file_exists( $index_file ) ) {
					@file_put_contents( $index_file, '<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><h1>Directory access forbidden.</h1></body></html>' );
				}
			}
		}

		return trailingslashit( $base_dir );
	}

	/**
	 * Obtiene la URL base de uploads del plugin.
	 *
	 * @param string $sub Subdirectorio o archivo.
	 * @return string URL completa.
	 */
	public static function get_upload_url( $sub = '' ) {
		$upload_dir = wp_upload_dir();
		$base_url   = trailingslashit( $upload_dir['baseurl'] ) . 'wp-static-arquitect';

		if ( ! empty( $sub ) ) {
			$base_url = trailingslashit( $base_url ) . ltrim( $sub, '/\\' );
		}

		if ( is_ssl() || 0 === strpos( home_url(), 'https://' ) ) {
			$base_url = set_url_scheme( $base_url, 'https' );
		}

		return $base_url;
	}

	/**
	 * Registra un mensaje en el log del plugin.
	 *
	 * @param string $message Mensaje a registrar.
	 * @param string $type    Tipo: 'info', 'warning', 'error', 'success'.
	 */
	public static function log( $message, $type = 'info' ) {
		$logs_dir = self::get_upload_dir( 'logs' );
		$log_file = $logs_dir . 'activity.log';

		$timestamp = current_time( 'Y-m-d H:i:s' );
		$entry     = sprintf( "[%s] [%s] %s\n", $timestamp, strtoupper( $type ), $message );

		@file_put_contents( $log_file, $entry, FILE_APPEND | LOCK_EX );

		// Guardar también en los logs recientes en opciones para consulta rápida
		$recent_logs = get_option( 'wp_static_arquitect_recent_logs', array() );
		if ( ! is_array( $recent_logs ) ) {
			$recent_logs = array();
		}

		array_unshift(
			$recent_logs,
			array(
				'time'    => $timestamp,
				'type'    => $type,
				'message' => $message,
			)
		);

		// Mantener solo los últimos 150 registros
		$recent_logs = array_slice( $recent_logs, 0, 150 );
		update_option( 'wp_static_arquitect_recent_logs', $recent_logs, false );
	}

	/**
	 * Obtener los registros de log recientes.
	 *
	 * @return array
	 */
	public static function get_recent_logs() {
		return get_option( 'wp_static_arquitect_recent_logs', array() );
	}

	/**
	 * Limpiar los logs de actividad.
	 */
	public static function clear_logs() {
		$logs_dir = self::get_upload_dir( 'logs' );
		$log_file = $logs_dir . 'activity.log';
		if ( file_exists( $log_file ) ) {
			@file_put_contents( $log_file, '' );
		}
		delete_option( 'wp_static_arquitect_recent_logs' );
	}
}

/**
 * Activación del plugin.
 */
function wp_static_arquitect_activate() {
	// Crear directorios necesarios
	WP_Static_Arquitect::get_upload_dir( 'temp' );
	WP_Static_Arquitect::get_upload_dir( 'exports' );
	WP_Static_Arquitect::get_upload_dir( 'logs' );

	// Programar el Cron Job semanal de purga de Netlify si no existe
	if ( ! wp_next_scheduled( 'wp_static_arquitect_weekly_purge_cron' ) ) {
		wp_schedule_event( time(), 'weekly', 'wp_static_arquitect_weekly_purge_cron' );
	}

	// Opciones por defecto
	if ( false === get_option( 'wp_static_arquitect_netlify_threshold_count' ) ) {
		update_option( 'wp_static_arquitect_netlify_threshold_count', 80 );
	}
	if ( false === get_option( 'wp_static_arquitect_netlify_threshold_mb' ) ) {
		update_option( 'wp_static_arquitect_netlify_threshold_mb', 8 );
	}
	if ( false === get_option( 'wp_static_arquitect_supabase_auto_approve' ) ) {
		update_option( 'wp_static_arquitect_supabase_auto_approve', '0' );
	}
	if ( false === get_option( 'wp_static_arquitect_scheduled_deploy_enabled' ) ) {
		update_option( 'wp_static_arquitect_scheduled_deploy_enabled', '0' );
	}
	if ( false === get_option( 'wp_static_arquitect_scheduled_deploy_time' ) ) {
		update_option( 'wp_static_arquitect_scheduled_deploy_time', '23:00' );
	}
	if ( false === get_option( 'wp_static_arquitect_scheduled_deploy_smart_check' ) ) {
		update_option( 'wp_static_arquitect_scheduled_deploy_smart_check', '1' );
	}
	if ( false === get_option( 'wp_static_arquitect_service_tier' ) ) {
		update_option( 'wp_static_arquitect_service_tier', 'creator_pro' );
	}

	WP_Static_Arquitect::sync_scheduled_deploy_cron();

	WP_Static_Arquitect::log( 'Plugin activado correctamente. Tareas programadas inicializadas.', 'info' );
}
register_activation_hook( __FILE__, 'wp_static_arquitect_activate' );

/**
 * Desactivación del plugin.
 */
function wp_static_arquitect_deactivate() {
	// Desprogramar cron semanal de purga
	$timestamp = wp_next_scheduled( 'wp_static_arquitect_weekly_purge_cron' );
	if ( $timestamp ) {
		wp_unschedule_event( $timestamp, 'wp_static_arquitect_weekly_purge_cron' );
	}

	// Desprogramar cron diario de despliegue
	$daily_ts = wp_next_scheduled( 'wp_static_arquitect_daily_scheduled_deploy_cron' );
	if ( $daily_ts ) {
		wp_unschedule_event( $daily_ts, 'wp_static_arquitect_daily_scheduled_deploy_cron' );
	}

	WP_Static_Arquitect::log( 'Plugin desactivado. Tareas programadas canceladas.', 'info' );
}
register_deactivation_hook( __FILE__, 'wp_static_arquitect_deactivate' );

/**
 * Inicializar el plugin en el hook 'plugins_loaded'.
 */
function wp_static_arquitect_init() {
	return WP_Static_Arquitect::get_instance();
}
add_action( 'plugins_loaded', 'wp_static_arquitect_init' );
