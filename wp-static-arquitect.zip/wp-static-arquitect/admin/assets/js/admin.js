/**
 * WP Static Architect - Lógica de Administración JavaScript
 */
(function ($) {
    'use strict';

    $(document).ready(function () {
        initTabs();
        initApiTests();
        initBootstrap();
        initExport();
        initDeploy();
        initSiteAnalyzer();
        initPurge();
        initModeration();
        initLogs();
        initClipboard();
        initTourModal();
        initFaq();
        initJumpTabs();
        initCustomDomainLink();
        initAiArticleGenerator();
    });

    /**
     * Sistema de Notificaciones Toast Moderno
     */
    function wpsaToast(message, type, duration) {
        type = type || 'info';
        duration = duration || 4000;

        let $container = $('.wpsa-toast-container');
        if (!$container.length) {
            $container = $('<div class="wpsa-toast-container"></div>').appendTo('body');
        }

        const iconMap = {
            success: 'dashicons-yes-alt',
            error: 'dashicons-warning',
            warning: 'dashicons-info',
            info: 'dashicons-info-outline'
        };
        const icon = iconMap[type] || iconMap.info;

        const $toast = $(`
            <div class="wpsa-toast toast-${type}">
                <span class="dashicons ${icon} wpsa-toast-icon"></span>
                <div class="wpsa-toast-content">${message}</div>
                <button type="button" class="wpsa-toast-close" title="Cerrar">&times;</button>
            </div>
        `);

        $container.append($toast);
        setTimeout(function () { $toast.addClass('visible'); }, 15);

        let timer = setTimeout(dismiss, duration);

        function dismiss() {
            $toast.removeClass('visible');
            setTimeout(function () { $toast.remove(); }, 260);
        }

        $toast.find('.wpsa-toast-close').on('click', function () {
            clearTimeout(timer);
            dismiss();
        });

        $toast.on('mouseenter', function () { clearTimeout(timer); });
        $toast.on('mouseleave', function () { timer = setTimeout(dismiss, 2000); });
    }

    /**
     * Sistema de Modales de Confirmación y Alertas Elegantes
     */
    function wpsaConfirm(options) {
        return new Promise(function (resolve) {
            const opts = $.extend({
                title: '¿Estás seguro?',
                message: '',
                confirmText: 'Aceptar',
                cancelText: 'Cancelar',
                type: 'warning',
                icon: ''
            }, options);

            const iconMap = {
                danger: 'dashicons-trash',
                warning: 'dashicons-warning',
                success: 'dashicons-yes-alt',
                info: 'dashicons-info-outline'
            };
            const icon = opts.icon || iconMap[opts.type] || iconMap.info;

            const modalHtml = `
                <div class="wpsa-dialog-backdrop" id="wpsa-active-dialog">
                    <div class="wpsa-dialog-modal">
                        <div class="wpsa-dialog-body">
                            <div class="wpsa-dialog-icon-wrap type-${opts.type}">
                                <span class="dashicons ${icon}"></span>
                            </div>
                            <h3 class="wpsa-dialog-title">${opts.title}</h3>
                            <div class="wpsa-dialog-message">${opts.message}</div>
                        </div>
                        <div class="wpsa-dialog-footer">
                            <button type="button" class="wpsa-dialog-btn wpsa-dialog-btn-cancel" id="wpsa-dialog-cancel">${opts.cancelText}</button>
                            <button type="button" class="wpsa-dialog-btn wpsa-dialog-btn-confirm type-${opts.type}" id="wpsa-dialog-confirm">${opts.confirmText}</button>
                        </div>
                    </div>
                </div>
            `;

            $('#wpsa-active-dialog').remove();
            const $backdrop = $(modalHtml).appendTo('body');
            setTimeout(function () { $backdrop.addClass('visible'); }, 15);
            $('body').addClass('wpsa-modal-open');

            function closeDialog(result) {
                $backdrop.removeClass('visible');
                $('body').removeClass('wpsa-modal-open');
                $(document).off('keydown.wpsaDialog');
                setTimeout(function () {
                    $backdrop.remove();
                    resolve(result);
                }, 220);
            }

            $backdrop.find('#wpsa-dialog-confirm').on('click', function () { closeDialog(true); });
            $backdrop.find('#wpsa-dialog-cancel').on('click', function () { closeDialog(false); });

            $backdrop.on('click', function (e) {
                if (e.target === this) closeDialog(false);
            });

            $(document).on('keydown.wpsaDialog', function (e) {
                if (e.key === 'Escape') closeDialog(false);
                if (e.key === 'Enter') closeDialog(true);
            });

            $backdrop.find('#wpsa-dialog-confirm').focus();
        });
    }

    function wpsaAlert(options) {
        return new Promise(function (resolve) {
            let opts = {};
            if (typeof options === 'string') {
                opts = { title: 'Notificación', message: options, buttonText: 'Entendido', type: 'info' };
            } else {
                opts = $.extend({
                    title: 'Aviso',
                    message: '',
                    buttonText: 'Aceptar',
                    type: 'info',
                    icon: ''
                }, options);
            }

            const iconMap = {
                danger: 'dashicons-dismiss',
                warning: 'dashicons-warning',
                success: 'dashicons-yes-alt',
                info: 'dashicons-info-outline'
            };
            const icon = opts.icon || iconMap[opts.type] || iconMap.info;

            const modalHtml = `
                <div class="wpsa-dialog-backdrop" id="wpsa-active-dialog">
                    <div class="wpsa-dialog-modal">
                        <div class="wpsa-dialog-body">
                            <div class="wpsa-dialog-icon-wrap type-${opts.type}">
                                <span class="dashicons ${icon}"></span>
                            </div>
                            <h3 class="wpsa-dialog-title">${opts.title}</h3>
                            <div class="wpsa-dialog-message">${opts.message}</div>
                        </div>
                        <div class="wpsa-dialog-footer">
                            <button type="button" class="wpsa-dialog-btn wpsa-dialog-btn-confirm type-${opts.type}" id="wpsa-dialog-close">${opts.buttonText}</button>
                        </div>
                    </div>
                </div>
            `;

            $('#wpsa-active-dialog').remove();
            const $backdrop = $(modalHtml).appendTo('body');
            setTimeout(function () { $backdrop.addClass('visible'); }, 15);
            $('body').addClass('wpsa-modal-open');

            function closeDialog() {
                $backdrop.removeClass('visible');
                $('body').removeClass('wpsa-modal-open');
                $(document).off('keydown.wpsaDialog');
                setTimeout(function () {
                    $backdrop.remove();
                    resolve();
                }, 220);
            }

            $backdrop.find('#wpsa-dialog-close').on('click', closeDialog);
            $backdrop.on('click', function (e) {
                if (e.target === this) closeDialog();
            });

            $(document).on('keydown.wpsaDialog', function (e) {
                if (e.key === 'Escape' || e.key === 'Enter') closeDialog();
            });

            $backdrop.find('#wpsa-dialog-close').focus();
        });
    }

    // Exponer utilidades para uso global si fuera necesario
    window.wpsaToast = wpsaToast;
    window.wpsaConfirm = wpsaConfirm;
    window.wpsaAlert = wpsaAlert;

    /**
     * Gestión de pestañas del panel
     */
    function initTabs() {
        $('.wpsa-tab-btn').on('click', function () {
            const target = $(this).data('tab');
            $('.wpsa-tab-btn').removeClass('active');
            $('.wpsa-tab-pane').removeClass('active');

            $(this).addClass('active');
            $('#' + target).addClass('active');
        });
    }

    /**
     * Pruebas de conexión de APIs
     */
    function initApiTests() {
        // Probar Netlify
        $('#btn-test-netlify').on('click', function () {
            const $btn = $(this);
            const $res = $('#netlify-test-result');
            const pat = $('#netlify_pat').val();
            const siteId = $('#netlify_site_id').val();

            if (!pat || !siteId) {
                $res.removeClass('success').addClass('error').text('Ingresa el Token y el Site ID primero.');
                return;
            }

            $btn.prop('disabled', true);
            $res.removeClass('success error').text('Verificando...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_test_netlify',
                nonce: wpsaData.nonce,
                pat: pat,
                site_id: siteId
            }).done(function (response) {
                if (response.success) {
                    $res.addClass('success').text(response.data.message);
                    refreshLogs();
                } else {
                    $res.addClass('error').text(response.data.message || 'Error en la conexión.');
                }
            }).fail(function () {
                $res.addClass('error').text('Error de red al conectar con el servidor.');
            }).always(function () {
                $btn.prop('disabled', false);
            });
        });

        // Probar Supabase
        $('#btn-test-supabase').on('click', function () {
            const $btn = $(this);
            const $res = $('#supabase-test-result');
            const url = $('#supabase_url').val();
            const anonKey = $('#supabase_anon_key').val();

            if (!url || !anonKey) {
                $res.removeClass('success').addClass('error').text('Ingresa la URL y Anon Key primero.');
                return;
            }

            $btn.prop('disabled', true);
            $res.removeClass('success error').text('Verificando conexión...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_test_supabase',
                nonce: wpsaData.nonce,
                url: url,
                anon_key: anonKey
            }).done(function (response) {
                if (response.success) {
                    $res.addClass('success').text(response.data.message);
                } else {
                    $res.addClass('error').text(response.data.message || 'Error al conectar.');
                }
            }).fail(function () {
                $res.addClass('error').text('Error de red al conectar con el servidor.');
            }).always(function () {
                $btn.prop('disabled', false);
            });
        });

        // Probar Build Hook de Netlify
        $('#btn-test-build-hook').on('click', function () {
            const $btn = $(this);
            const $res = $('#build-hook-test-result');
            const buildHook = $('#netlify_build_hook').val();

            if (!buildHook) {
                $res.removeClass('success').addClass('error').text('Ingresa la URL del Build Hook primero.');
                return;
            }

            $btn.prop('disabled', true);
            $res.removeClass('success error').text('Disparando Build Hook...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_test_build_hook',
                nonce: wpsaData.nonce,
                build_hook: buildHook
            }).done(function (response) {
                if (response.success) {
                    $res.addClass('success').text(response.data.message);
                    if (typeof refreshLogs === 'function') {
                        refreshLogs();
                    }
                } else {
                    $res.addClass('error').text(response.data.message || 'Error al disparar el Build Hook.');
                }
            }).fail(function () {
                $res.addClass('error').text('Error de red al conectar con el servidor.');
            }).always(function () {
                $btn.prop('disabled', false);
            });
        });

        // Comprobar contenido nuevo pendiente para despliegue programado
        $('#btn-check-new-content').on('click', function () {
            const $btn = $(this);
            const $res = $('#check-new-content-result');

            $btn.prop('disabled', true);
            $res.removeClass('success error info').text('Verificando contenido en base de datos...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_check_new_content',
                nonce: wpsaData.nonce
            }).done(function (response) {
                if (response.success) {
                    const isChange = response.data.has_changes;
                    $res.removeClass('success error info')
                        .addClass(isChange ? 'success' : 'info')
                        .text(response.data.message);
                } else {
                    $res.removeClass('success error info')
                        .addClass('error')
                        .text(response.data.message || 'Error al comprobar cambios.');
                }
            }).fail(function () {
                $res.removeClass('success error info')
                    .addClass('error')
                    .text('Error de red al conectar con el servidor.');
            }).always(function () {
                $btn.prop('disabled', false);
            });
        });

        // Probar Pinterest API v5
        $('#btn-test-pinterest').on('click', function () {
            const $btn = $(this);
            const $res = $('#pinterest-test-result');
            const token = $('#pinterest_token').val();
            const boardId = $('#pinterest_board_id').val();

            if (!token) {
                $res.css('color', '#ef4444').text('Ingresa el Access Token primero.');
                return;
            }

            $btn.prop('disabled', true);
            $res.css('color', '#6b7280').text('Verificando conexión con Pinterest API v5...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_test_pinterest',
                nonce: wpsaData.nonce,
                token: token,
                board_id: boardId
            }).done(function (response) {
                if (response.success) {
                    $res.css('color', '#10b981').text(response.data.message);
                    if (typeof refreshLogs === 'function') {
                        refreshLogs();
                    }
                } else {
                    $res.css('color', '#ef4444').text(response.data.message || 'Error al conectar con Pinterest.');
                }
            }).fail(function () {
                $res.css('color', '#ef4444').text('Error de red al conectar con el servidor.');
            }).always(function () {
                $btn.prop('disabled', false);
            });
        });

        // Sincronizar Pinterest manualmente
        $('#btn-sync-pinterest').on('click', function () {
            const $btn = $(this);
            const $res = $('#pinterest-sync-result');
            const limit = $('#drip_posts_count').val() || 3;

            $btn.prop('disabled', true);
            $res.css('color', '#6b7280').text('Sincronizando pines en Pinterest...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_trigger_pinterest_sync',
                nonce: wpsaData.nonce,
                limit: limit
            }).done(function (response) {
                if (response.success) {
                    $res.css('color', '#10b981').text(response.data.message);
                    if (typeof refreshLogs === 'function') {
                        refreshLogs();
                    }
                } else {
                    $res.css('color', '#ef4444').text(response.data.message || 'Error en la sincronización.');
                }
            }).fail(function () {
                $res.css('color', '#ef4444').text('Error de red al comunicar la sincronización.');
            }).always(function () {
                $btn.prop('disabled', false);
            });
        });

        // Probar GitHub Actions workflow_dispatch
        $('#btn-test-github-dispatch').on('click', function () {
            const $btn = $(this);
            const $feedback = $('#github-dispatch-feedback');
            const token = $.trim($('#github_token').val());
            const repo = $.trim($('#github_repo').val());
            const branch = $.trim($('#github_branch').val()) || 'main';
            const workflow = $.trim($('#github_workflow').val()) || 'deploy.yml';

            if (!token || !repo) {
                $feedback.html('<div class="notice notice-error inline"><p>Por favor ingresa tu GitHub Personal Access Token (PAT) y el repositorio (usuario/repo) primero.</p></div>');
                return;
            }

            $btn.addClass('loading').prop('disabled', true);
            $feedback.html('<div class="notice notice-info inline"><p><span class="wpsa-spinner" style="display:inline-block; vertical-align: -2px; margin-right: 6px;"></span> Enviando señal HTTP a la API de GitHub Actions (workflow_dispatch)...</p></div>');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_test_github_dispatch',
                nonce: wpsaData.nonce,
                token: token,
                repo: repo,
                branch: branch,
                workflow: workflow
            }).done(function (response) {
                if (response.success) {
                    $feedback.html('<div class="notice notice-success inline"><p><strong>¡Éxito!</strong> ' + escapeHtml(response.data.message || 'GitHub Actions ha recibido la orden y comenzó el flujo.') + '</p></div>');
                    if (typeof refreshLogs === 'function') {
                        refreshLogs();
                    }
                } else {
                    $feedback.html('<div class="notice notice-error inline"><p><strong>Error de GitHub:</strong> ' + escapeHtml(response.data.message || 'No se pudo disparar el workflow.') + '</p></div>');
                }
            }).fail(function () {
                $feedback.html('<div class="notice notice-error inline"><p>Error de red al conectar con el servidor.</p></div>');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });

        // Humanizador Editorial de Borradores (Drip-Feed FIFO)
        $('#btn-humanize-drip-posts').on('click', function () {
            const $btn = $(this);
            const $feedback = $('#humanize-drip-feedback');
            const count = $('#drip_posts_count').val() || 5;

            $btn.addClass('loading').prop('disabled', true);
            $feedback.html('<div class="notice notice-info inline"><p><span class="wpsa-spinner" style="display:inline-block; vertical-align: -2px; margin-right: 6px;"></span> Humanizando fechas de los borradores más antiguos con variación aleatoria...</p></div>');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_humanize_drip_posts',
                nonce: wpsaData.nonce,
                count: count
            }).done(function (response) {
                if (response.success && response.data) {
                    const posts = response.data.posts || [];
                    let listHtml = '<ul style="margin: 6px 0 0 16px; font-size: 11.5px; list-style: disc;">';
                    posts.forEach(function (p) {
                        listHtml += `<li><strong>${escapeHtml(p.title)}</strong> &rarr; <code style="color: #4338ca;">${p.local_time}</code></li>`;
                    });
                    listHtml += '</ul>';

                    $feedback.html(`
                        <div class="notice notice-success inline" style="padding: 10px;">
                            <p style="margin: 0 0 4px 0;"><strong>¡Éxito!</strong> ${response.data.message}</p>
                            ${listHtml}
                        </div>
                    `);
                    if (typeof refreshLogs === 'function') {
                        refreshLogs();
                    }
                } else {
                    $feedback.html('<div class="notice notice-warning inline"><p>' + (response.data ? response.data.message : 'No hay borradores pendientes.') + '</p></div>');
                }
            }).fail(function () {
                $feedback.html('<div class="notice notice-error inline"><p>Error de red al conectar con el servidor.</p></div>');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });
    }

    /**
     * Bootstrap de Supabase
     */
    function initBootstrap() {
        $('#btn-run-bootstrap').on('click', function () {
            const $btn = $(this);
            const $feedback = $('#bootstrap-feedback');
            const url = $('#supabase_url').val();
            const anonKey = $('#supabase_anon_key').val();
            const serviceKey = $('#supabase_service_key').val();

            $btn.addClass('loading').prop('disabled', true);
            $feedback.removeClass('notice-success notice-error notice-warning').html('Iniciando bootstrap de la base de datos...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_bootstrap_supabase',
                nonce: wpsaData.nonce,
                url: url,
                anon_key: anonKey,
                service_key: serviceKey
            }).done(function (response) {
                if (response.success) {
                    $feedback.html('<div class="notice notice-success inline"><p>' + response.data.message + '</p></div>');
                } else {
                    let html = '<div class="notice notice-warning inline"><p>' + response.data.message + '</p>';
                    if (response.data.manual_sql) {
                        html += '<p>Puedes utilizar el botón "Copiar SQL" de la tarjeta contigua para ejecutar el script directamente en tu Supabase SQL Editor.</p>';
                    }
                    html += '</div>';
                    $feedback.html(html);
                }
                refreshLogs();
            }).fail(function () {
                $feedback.html('<div class="notice notice-error inline"><p>Error de comunicación con el servidor WordPress.</p></div>');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });
    }

    /**
     * Exportación estática por lotes asíncronos (Anti-Timeout)
     */
    function initExport() {
        let skipFormsCheck = false;

        function evaluatePreflightRequirements() {
            const hosting = $('#hosting_provider').val() || wpsaData.hostingProvider || 'netlify';
            const formProvider = $('#form_provider').val() || wpsaData.formProvider || 'auto';
            const matrix = wpsaData.compatibilityMatrix || {};
            const missing = [];

            // 1. Validar compatibilidad Hosting vs Formularios
            if (hosting !== 'netlify' && formProvider === 'netlify') {
                missing.push({
                    id: 'incompatible_form',
                    label: 'Incompatibilidad de Formularios Netlify',
                    desc: `Netlify Forms requiere que el sitio esté alojado en Netlify. Actualmente tienes seleccionado <strong>${hosting.toUpperCase()}</strong>.`,
                    field: '#mixmatch_form',
                    card: '#card-forms-settings',
                    tab: 'tab-export',
                    actionLabel: 'Cambiar a Google Sheets / Web3Forms'
                });
            }

            // 2. Validar credenciales de formularios si hay formularios en el sitio
            if (wpsaData.hasForms) {
                if (formProvider === 'google_sheets') {
                    const sheetsUrl = $.trim($('#google_sheets_url').val() || wpsaData.googleSheetsUrl || '');
                    if (!sheetsUrl) {
                        missing.push({
                            id: 'google_sheets_url',
                            label: 'Webhook de Google Apps Script (Google Sheets)',
                            desc: 'Falta la URL del Web App de Google Apps Script para almacenar los contactos en tu Google Drive.',
                            field: '#google_sheets_url',
                            card: '#card-forms-settings',
                            tab: 'tab-config',
                            actionLabel: 'Completar URL de Google Sheets'
                        });
                    }
                } else if (formProvider === 'web3forms') {
                    const web3Key = $.trim($('#web3forms_key').val() || wpsaData.web3formsKey || '');
                    if (!web3Key) {
                        missing.push({
                            id: 'web3forms_key',
                            label: 'Access Key de Web3Forms',
                            desc: 'Falta la clave de acceso de Web3Forms para enviar los contactos a tu bandeja de correo.',
                            field: '#web3forms_key',
                            card: '#card-forms-settings',
                            tab: 'tab-config',
                            actionLabel: 'Completar Clave Web3Forms'
                        });
                    }
                } else if (formProvider === 'formsubmit') {
                    const formEmail = $.trim($('#formsubmit_email').val() || wpsaData.formsubmitEmail || '');
                    if (!formEmail) {
                        missing.push({
                            id: 'formsubmit_email',
                            label: 'Correo Receptor de FormSubmit',
                            desc: 'Falta definir la dirección de correo a donde se remitirán los mensajes.',
                            field: '#formsubmit_email',
                            card: '#card-forms-settings',
                            tab: 'tab-config',
                            actionLabel: 'Completar Correo FormSubmit'
                        });
                    }
                }
            }

            // 3. Validar credenciales del hosting seleccionado
            if (hosting === 'github') {
                const ghToken = $.trim($('#github_token').val() || wpsaData.githubToken || '');
                const ghRepo = $.trim($('#github_repo').val() || wpsaData.githubRepo || '');
                if (!ghToken || !ghRepo) {
                    missing.push({
                        id: 'github_creds',
                        label: 'Credenciales de GitHub (PAT & Repositorio)',
                        desc: 'Para que el auto-despliegue de GitHub Actions funcione se requiere tu Token Personal (PAT) y el repositorio (usuario/repo).',
                        field: !ghToken ? '#github_token' : '#github_repo',
                        card: '#card-github-settings',
                        tab: 'tab-config',
                        actionLabel: 'Configurar GitHub'
                    });
                }
            } else if (hosting === 'cloudflare') {
                const cfHook = $.trim($('#cloudflare_deploy_hook').val() || wpsaData.cloudflareDeployHook || '');
                if (!cfHook) {
                    missing.push({
                        id: 'cloudflare_hook',
                        label: 'Deploy Hook de Cloudflare Pages',
                        desc: 'Se recomienda configurar el Deploy Hook de Cloudflare Pages para que el sitio se actualice automáticamente en cada exportación.',
                        field: '#cloudflare_deploy_hook',
                        card: '#card-cloudflare-settings',
                        tab: 'tab-config',
                        actionLabel: 'Configurar Deploy Hook'
                    });
                }
            } else if (hosting === 'render') {
                const renHook = $.trim($('#render_deploy_hook').val() || wpsaData.renderDeployHook || '');
                if (!renHook) {
                    missing.push({
                        id: 'render_hook',
                        label: 'Deploy Hook de Render',
                        desc: 'Falta la URL del Deploy Hook de Render para activar el despliegue automático vía HTTP POST.',
                        field: '#render_deploy_hook',
                        card: '#card-render-settings',
                        tab: 'tab-config',
                        actionLabel: 'Configurar Render Hook'
                    });
                }
            }

            return {
                hosting: hosting,
                formProvider: formProvider,
                missing: missing
            };
        }

        function checkFormsConfig() {
            return evaluatePreflightRequirements();
        }

        $('#btn-start-export').on('click', function (e) {
            if (e && e.preventDefault) {
                e.preventDefault();
            }

            // Obtener el dominio del input inline en la tarjeta principal
            let targetDomain = $.trim($('#wpsa_export_target_domain').val());
            if (targetDomain && !/^https?:\/\//i.test(targetDomain)) {
                targetDomain = 'https://' + targetDomain;
                $('#wpsa_export_target_domain').val(targetDomain);
            }

            // Iniciar exportación directa en 1 solo clic sin ningún modal emergente
            startExportExecution(targetDomain, 1);
        });

        // Botón para guardar el dominio de forma independiente
        $('#btn-save-inline-domain').on('click', function () {
            let targetDomain = $.trim($('#wpsa_export_target_domain').val());
            if (targetDomain && !/^https?:\/\//i.test(targetDomain)) {
                targetDomain = 'https://' + targetDomain;
                $('#wpsa_export_target_domain').val(targetDomain);
            }
            const $btn = $(this);
            const origHtml = $btn.html();
            $btn.prop('disabled', true).text('Guardando...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_batch_init',
                nonce: wpsaData.nonce,
                custom_domain: targetDomain,
                save_perm: 1
            }).done(function () {
                if (targetDomain) {
                    wpsaData.customDomain = targetDomain;
                    $('#custom_domain').val(targetDomain);
                    $('.wpsa-summary-item:has(.wpsa-label:contains("Dominio Canónico")) .wpsa-val').text(targetDomain);
                }
                wpsaToast('Dominio de producción guardado con éxito.', 'success');
            }).fail(function () {
                wpsaToast('No se pudo guardar el dominio en el servidor.', 'error');
            }).always(function () {
                $btn.prop('disabled', false).html(origHtml);
            });
        });

        function showPreflightModal(check, onProceed) {
            const hostingNames = {
                'cloudflare': 'Cloudflare Pages',
                'github': 'GitHub Pages & Actions',
                'render': 'Render',
                'netlify': 'Netlify'
            };
            const formNames = {
                'google_sheets': 'Google Sheets (Excel CSV)',
                'web3forms': 'Web3Forms',
                'formsubmit': 'FormSubmit',
                'netlify': 'Netlify Forms',
                'auto': 'Automático'
            };

            $('#preflight-hosting-name').text(hostingNames[check.hosting] || check.hosting.toUpperCase());
            $('#preflight-provider-name').text(formNames[check.formProvider] || check.formProvider.toUpperCase());

            let checklistHtml = '';
            check.missing.forEach(function (item, idx) {
                checklistHtml += `
                    <div style="background: #ffffff; border: 1px solid #fed7aa; border-left: 4px solid #f97316; border-radius: 6px; padding: 12px; display: flex; align-items: flex-start; justify-content: space-between; gap: 12px;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 3px;">
                                <span class="dashicons dashicons-warning" style="color: #ea580c; font-size: 16px; width: 16px; height: 16px;"></span>
                                <strong style="color: #9a3412; font-size: 13px;">${item.label}</strong>
                            </div>
                            <p style="margin: 0; font-size: 12px; color: #475569; line-height: 1.4;">${item.desc}</p>
                        </div>
                        <button type="button" class="button button-small btn-preflight-jump" data-tab="${item.tab}" data-card="${item.card}" data-field="${item.field}" style="white-space: nowrap; font-size: 11.5px; display: inline-flex; align-items: center; gap: 4px; font-weight: 600;">
                            <span class="dashicons dashicons-arrow-right-alt"></span> ${item.actionLabel}
                        </button>
                    </div>
                `;
            });

            $('#preflight-checklist').html(checklistHtml);
            $('#wpsa-forms-preflight-modal-backdrop').fadeIn(200).css('display', 'flex');

            // Botón cancelar
            $('#btn-preflight-cancel').off('click').on('click', function () {
                $('#wpsa-forms-preflight-modal-backdrop').fadeOut(200);
            });

            // Botón omitir y exportar estático puro
            $('#btn-preflight-skip').off('click').on('click', function () {
                $('#wpsa-forms-preflight-modal-backdrop').fadeOut(200);
                if (typeof onProceed === 'function') {
                    onProceed();
                } else {
                    startExportExecution();
                }
            });

            // Botón principal configurar ahora
            $('#btn-preflight-configure').off('click').on('click', function () {
                $('#wpsa-forms-preflight-modal-backdrop').fadeOut(200);
                const first = check.missing[0];
                jumpToConfigField(first.tab, first.card, first.field);
            });

            // Botones individuales de cada ítem del checklist
            $('.btn-preflight-jump').off('click').on('click', function () {
                const tab = $(this).data('tab');
                const card = $(this).data('card');
                const field = $(this).data('field');
                $('#wpsa-forms-preflight-modal-backdrop').fadeOut(200);
                jumpToConfigField(tab, card, field);
            });
        }

        function jumpToConfigField(tab, card, field) {
            $('.wpsa-tab-btn[data-tab="' + tab + '"]').trigger('click');
            setTimeout(function () {
                if ($(card).length) {
                    $('html, body').animate({
                        scrollTop: $(card).offset().top - 30
                    }, 400, function () {
                        if ($(field).length) {
                            $(field).focus().css('box-shadow', '0 0 0 3px rgba(37, 99, 235, 0.5)');
                            setTimeout(function () {
                                $(field).css('box-shadow', '');
                            }, 3500);
                        }
                    });
                }
            }, 100);
        }

        function startExportExecution(chosenDomain, savePerm) {
            chosenDomain = (typeof chosenDomain === 'string') ? chosenDomain : (wpsaData.customDomain || '');
            savePerm = (typeof savePerm !== 'undefined') ? savePerm : 1;

            const $btn = $('#btn-start-export');
            const $progressContainer = $('#wpsa-progress-container');
            const $progressFill = $('#wpsa-progress-fill');
            const $progressStatus = $('#wpsa-progress-status');
            const $progressPercent = $('#wpsa-progress-percent');
            const $progressStage = $('#wpsa-progress-stage');
            const $progressCount = $('#wpsa-progress-pages-count');
            const $progressSpinner = $('#wpsa-progress-spinner');
            const $progressIcon = $('#wpsa-progress-icon');

            // Actualizar pipeline visual
            $('#pipeline-step-1').removeClass('complete').addClass('active');
            $('#pipeline-step-2').removeClass('active complete');
            $('#pipeline-step-3').removeClass('active complete');

            $btn.addClass('loading').prop('disabled', true);
            $btn.find('strong').text('Exportando sitio estático...');
            $btn.find('small').text('Por favor, espera unos instantes mientras se genera el paquete...');

            $progressContainer.removeClass('is-complete').slideDown(200);
            $progressSpinner.show();
            $progressIcon.hide();
            $progressPercent.css({'color': '#2563eb', 'background': '#eff6ff', 'border-color': '#dbeafe'});
            $progressFill.css('width', '5%');
            $progressPercent.text('5%');
            $progressStatus.text('Iniciando sesión y mapeando 260 URLs públicas...');
            $progressStage.text('Fase 1: Rastreo y Mapeo');
            $progressCount.text('Descubriendo recursos...');

            let logInterval = setInterval(refreshLogs, 3000);

            // 1. Inicializar sesión por lotes con dominio canónico de producción
            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_batch_init',
                nonce: wpsaData.nonce,
                custom_domain: chosenDomain,
                save_perm: savePerm
            }).done(function (initRes) {
                if (chosenDomain) {
                    wpsaData.customDomain = chosenDomain;
                    $('#custom_domain').val(chosenDomain);
                }
                if (!initRes.success) {
                    handleExportError(initRes.data.message || 'No se pudo inicializar la sesión de exportación.');
                    return;
                }

                const sessionId = initRes.data.session_id;
                const totalPages = initRes.data.total_pages;

                $progressFill.css('width', '8%');
                $progressPercent.text('8%');
                $progressStatus.text(`Descubiertas ${totalPages} páginas. Iniciando rastreo y conversión...`);
                $progressCount.text(`0 de ${totalPages} URLs`);

                // Avanzar al paso 2 en el pipeline visual
                $('#pipeline-step-1').removeClass('active').addClass('complete');
                $('#pipeline-step-2').addClass('active');

                // 2. Bucle iterativo de chunks
                processNextStep(sessionId, totalPages);

            }).fail(function () {
                handleExportError('Error de red al inicializar la sesión.');
            });

            let stepRetries = 0;
            const maxStepRetries = 3;

            function processNextStep(sessionId, totalPages) {
                $.post(wpsaData.ajaxUrl, {
                    action: 'wpsa_batch_step',
                    nonce: wpsaData.nonce,
                    session_id: sessionId,
                    batch_size: 2
                }).done(function (stepRes) {
                    stepRetries = 0;

                    if (!stepRes.success) {
                        handleExportError(stepRes.data.message || 'Error durante el procesamiento por lotes.');
                        return;
                    }

                    const processed = stepRes.data.processed_pages;
                    const successful = stepRes.data.successful_pages || processed;
                    const percent = Math.min(92, Math.max(8, stepRes.data.percent));

                    $progressFill.css('width', percent + '%');
                    $progressPercent.text(percent + '%');
                    $progressStage.text('Fase 2: Optimización Serverless y HTML Puro');
                    $progressCount.text(`${processed} de ${totalPages} URLs (${percent}%)`);

                    const cleanUrl = stepRes.data.current_url ? stepRes.data.current_url.replace(/^https?:\/\/[^\/]+/, '') : '';
                    $progressStatus.text(`Procesando [${processed}/${totalPages}] - Guardada: ${cleanUrl || 'recursos'}`);

                    if (stepRes.data.is_complete) {
                        $('#pipeline-step-2').removeClass('active').addClass('complete');
                        $('#pipeline-step-3').addClass('active');

                        $progressFill.css('width', '94%');
                        $progressPercent.text('94%');
                        $progressStage.text('Fase 3: Empaquetado y Finalización');
                        $progressStatus.text('Generando archivos auxiliares (sitemap, buscador, directivas SEO y llms.txt)...');
                        finalizeSessionStep1(sessionId);
                    } else {
                        // Siguiente lote
                        processNextStep(sessionId, totalPages);
                    }
                }).fail(function (xhr) {
                    if (stepRetries < maxStepRetries) {
                        stepRetries++;
                        $progressStatus.html(`<span style="color:#d97706;"><span class="wpsa-spinner" style="display:inline-block; vertical-align: -3px; margin-right: 6px;"></span> Reintentando lote [intento ${stepRetries}/${maxStepRetries}] por corte de conexión...</span>`);
                        setTimeout(function () {
                            processNextStep(sessionId, totalPages);
                        }, 2500);
                    } else {
                        handleExportError(parseAjaxError(xhr, 'Error de conexión durante el procesamiento de páginas.'));
                    }
                });
            }

            function finalizeSessionStep1(sessionId) {
                $.post(wpsaData.ajaxUrl, {
                    action: 'wpsa_batch_finalize',
                    nonce: wpsaData.nonce,
                    session_id: sessionId,
                    phase: 'prepare'
                }).done(function (prepRes) {
                    if (!prepRes.success) {
                        handleExportError(prepRes.data && prepRes.data.message ? prepRes.data.message : 'Error al preparar archivos estáticos auxiliares.');
                        return;
                    }

                    $progressFill.css('width', '98%');
                    $progressPercent.text('98%');
                    $progressStatus.text('Empaquetando archivo ZIP de alta velocidad y finalizando...');
                    finalizeSessionStep2(sessionId);
                }).fail(function (xhr) {
                    let errDetail = parseAjaxError(xhr, 'Error de conexión al preparar archivos estáticos auxiliares.');
                    handleExportError(errDetail, sessionId, 'prepare');
                });
            }

            function finalizeSessionStep2(sessionId) {
                let statusPollTimer = null;
                let pollAttempts = 0;
                const maxPollAttempts = 40; // 40 intentos * 3.5s = ~140 segundos

                function checkStatusPoll() {
                    pollAttempts++;
                    $.post(wpsaData.ajaxUrl, {
                        action: 'wpsa_batch_status',
                        nonce: wpsaData.nonce,
                        session_id: sessionId
                    }).done(function (statusRes) {
                        if (statusRes.success && statusRes.data && statusRes.data.is_complete) {
                            clearInterval(statusPollTimer);
                            statusPollTimer = null;
                            $('#pipeline-step-1, #pipeline-step-2, #pipeline-step-3').removeClass('active').addClass('complete');
                            $progressFill.css('width', '100%');
                            $progressPercent.text('100%').css({'color': '#059669', 'background': '#ecfdf5', 'border-color': '#a7f3d0'});
                            $progressStage.text('¡Exportación Completada!');
                            $progressCount.text('Paquete listo para descarga');
                            $progressStatus.text('¡Exportación finalizada exitosamente! Paquete listo para descargar.');
                            $progressSpinner.hide();
                            $progressIcon.removeClass('dashicons-warning dashicons-dismiss').addClass('dashicons-yes-alt').css('color', '#10b981').show();
                            $progressContainer.addClass('is-complete');

                            try {
                                renderLastExportBox(statusRes.data.archive, statusRes.data.deploy_result ? statusRes.data.deploy_result.deploy_info : null);
                            } catch (renderErr) {
                                console.error('Error al renderizar paquete exportado:', renderErr);
                            }
                            refreshLogs();
                            cleanupExport();

                            if ($('#wpsa-last-export-box').length) {
                                $('html, body').animate({
                                    scrollTop: $('#wpsa-last-export-box').offset().top - 40
                                }, 500);
                            }
                        } else if (pollAttempts >= maxPollAttempts) {
                            clearInterval(statusPollTimer);
                            statusPollTimer = null;
                            handleExportError('El servidor continúa procesando el archivo. Haz clic en Reintentar para verificar el paquete generado.', sessionId, 'compress');
                        }
                    });
                }

                $.post(wpsaData.ajaxUrl, {
                    action: 'wpsa_batch_finalize',
                    nonce: wpsaData.nonce,
                    session_id: sessionId,
                    phase: 'compress'
                }).done(function (finRes) {
                    if (statusPollTimer) {
                        clearInterval(statusPollTimer);
                        statusPollTimer = null;
                    }

                    if (finRes.success) {
                        $('#pipeline-step-1, #pipeline-step-2, #pipeline-step-3').removeClass('active').addClass('complete');
                        $progressFill.css('width', '100%');
                        $progressPercent.text('100%').css({'color': '#059669', 'background': '#ecfdf5', 'border-color': '#a7f3d0'});
                        $progressStage.text('¡Exportación Completada!');
                        $progressCount.text('Paquete listo para descarga');
                        $progressStatus.text(finRes.data.message || '¡Exportación finalizada exitosamente! Paquete listo para descargar.');
                        $progressSpinner.hide();
                        $progressIcon.removeClass('dashicons-warning dashicons-dismiss').addClass('dashicons-yes-alt').css('color', '#10b981').show();
                        $progressContainer.addClass('is-complete');

                        try {
                            renderLastExportBox(finRes.data.archive, finRes.data.deploy_result ? finRes.data.deploy_result.deploy_info : null);
                        } catch (renderErr) {
                            console.error('Error al renderizar paquete exportado:', renderErr);
                        }
                        refreshLogs();
                        cleanupExport();

                        if ($('#wpsa-last-export-box').length) {
                            $('html, body').animate({
                                scrollTop: $('#wpsa-last-export-box').offset().top - 40
                            }, 500);
                        }
                    } else {
                        handleExportError(finRes.data && finRes.data.message ? finRes.data.message : 'Error al empaquetar el archivo ZIP.', sessionId, 'compress');
                    }
                }).fail(function (xhr) {
                    // Ante un 504 Gateway Timeout o corte de red temporal, el servidor continúa comprimiendo en segundo plano
                    if (xhr.status === 504 || xhr.status === 0 || xhr.status === 502) {
                        $progressStatus.html('<span style="color:#d97706; font-weight: 600;"><span class="wpsa-spinner" style="display:inline-block; vertical-align: -3px; margin-right: 6px;"></span> Empaquetando archivo ZIP en segundo plano en el servidor... Esperando finalización...</span>');
                        if (!statusPollTimer) {
                            statusPollTimer = setInterval(checkStatusPoll, 3500);
                        }
                    } else {
                        let errDetail = parseAjaxError(xhr, 'Error de conexión al finalizar y comprimir el paquete.');
                        handleExportError(errDetail, sessionId, 'compress');
                    }
                });
            }

            function parseAjaxError(xhr, defaultMsg) {
                if (xhr.status === 504) {
                    return 'Tiempo de espera del servidor agotado (504 Gateway Timeout). El servidor tardó más de 60 segundos.';
                } else if (xhr.status === 500) {
                    if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                        return xhr.responseJSON.data.message;
                    }
                    return 'Error interno del servidor (500 Internal Server Error).';
                } else if (xhr.status === 502) {
                    return 'Puerta de enlace incorrecta (502 Bad Gateway). El proceso PHP se reinició o agotó memoria.';
                }
                return defaultMsg;
            }

            function handleExportError(msg, retrySessionId, retryPhase) {
                $progressSpinner.hide();
                $progressIcon.removeClass('dashicons-yes-alt').addClass('dashicons-warning').css('color', '#ef4444').show();
                $progressContainer.removeClass('is-complete');
                let errorHtml = '<span style="color:#ef4444; font-weight: 600;">Error: ' + escapeHtml(msg) + '</span>';
                if (retrySessionId && retryPhase) {
                    errorHtml += ` <button type="button" class="button button-small button-secondary wpsa-retry-btn" data-session="${escapeHtml(retrySessionId)}" data-phase="${escapeHtml(retryPhase)}" style="margin-left: 10px; font-size: 11px;">Reintentar</button>`;
                }
                $progressStatus.html(errorHtml);
                cleanupExport();

                $('.wpsa-retry-btn').off('click').on('click', function () {
                    const sid = $(this).data('session');
                    const ph = $(this).data('phase');
                    $btn.addClass('loading').prop('disabled', true);
                    $progressSpinner.show();
                    $progressIcon.hide();
                    $progressContainer.removeClass('is-complete');
                    logInterval = setInterval(refreshLogs, 2500);
                    $progressStatus.text('Comprobando estado del paquete en el servidor...');

                    // Primero comprobar si el paquete ya finalizó en segundo plano
                    $.post(wpsaData.ajaxUrl, {
                        action: 'wpsa_batch_status',
                        nonce: wpsaData.nonce,
                        session_id: sid
                    }).done(function (statusRes) {
                        if (statusRes.success && statusRes.data && statusRes.data.is_complete) {
                            $('#pipeline-step-1, #pipeline-step-2, #pipeline-step-3').removeClass('active').addClass('complete');
                            $progressFill.css('width', '100%');
                            $progressPercent.text('100%').css({'color': '#059669', 'background': '#ecfdf5', 'border-color': '#a7f3d0'});
                            $progressStatus.text('¡Exportación finalizada exitosamente! Paquete listo para descargar.');
                            $progressSpinner.hide();
                            $progressIcon.removeClass('dashicons-warning dashicons-dismiss').addClass('dashicons-yes-alt').css('color', '#10b981').show();
                            $progressContainer.addClass('is-complete');

                            renderLastExportBox(statusRes.data.archive, statusRes.data.deploy_result ? statusRes.data.deploy_result.deploy_info : null);
                            refreshLogs();
                            cleanupExport();
                        } else {
                            if (ph === 'prepare') {
                                $progressStatus.text('Reintentando generación de archivos auxiliares...');
                                finalizeSessionStep1(sid);
                            } else {
                                $progressStatus.text('Reintentando compresión ZIP...');
                                finalizeSessionStep2(sid);
                            }
                        }
                    }).fail(function () {
                        finalizeSessionStep2(sid);
                    });
                });
            }

            function cleanupExport() {
                clearInterval(logInterval);
                setTimeout(refreshLogs, 1000);
                const $startBtn = $('#btn-start-export');
                $startBtn.removeClass('loading').prop('disabled', false);
                $startBtn.find('strong').text('Iniciar Nueva Exportación Estática (.ZIP)');
                $startBtn.find('small').text('Generar una nueva versión actualizada de tu sitio portátil');
            }
        }

        // Eliminar y descartar paquete exportado anterior
        $(document).on('click', '.btn-delete-export-action', function (e) {
            e.preventDefault();
            const $btn = $(this);

            wpsaConfirm({
                title: '¿Eliminar paquete exportado?',
                message: 'Esta acción eliminará permanentemente el archivo .ZIP del servidor y liberará espacio para generar un paquete nuevo desde cero.',
                confirmText: 'Sí, eliminar paquete',
                cancelText: 'Cancelar',
                type: 'danger',
                icon: 'dashicons-trash'
            }).then(function (confirmed) {
                if (!confirmed) return;

                const $allBtns = $('.btn-delete-export-action');
                $allBtns.prop('disabled', true);
                $btn.find('.wpsa-spinner').show();
                if ($btn.hasClass('wpsa-btn-trash-header')) {
                    $btn.text('Eliminando...');
                }

                $.post(wpsaData.ajaxUrl, {
                    action: 'wpsa_delete_export',
                    nonce: wpsaData.nonce
                }).done(function (response) {
                    if (response.success) {
                        // Remover botón de cabecera si existe
                        $('.wpsa-btn-trash-header').fadeOut(200, function () {
                            $(this).remove();
                        });

                        // Renderizar estado vacío en la caja
                        $('#wpsa-last-export-box').fadeOut(200, function () {
                            $(this).html(`
                                <div class="wpsa-empty-box" style="text-align: center; padding: 30px 20px; background: #f8fafc; border: 2px dashed #cbd5e1; border-radius: 12px;">
                                    <span class="dashicons dashicons-cloud-upload" style="font-size: 40px; width: 40px; height: 40px; color: #94a3b8; margin-bottom: 10px;"></span>
                                    <h4 style="margin: 0 0 6px 0; font-size: 15px; color: #334155;">Aún no has generado tu primer paquete estático</h4>
                                    <p style="margin: 0; font-size: 13px; color: #64748b; max-width: 380px; margin: 0 auto;">
                                        Haz clic en <strong>"Iniciar Exportación Estática Completa (.ZIP)"</strong> para compilar tu sitio completo en archivos HTML, CSS y JS optimizados.
                                    </p>
                                </div>
                            `).fadeIn(200);
                        });

                        // Resetear pasos del pipeline
                        $('.wpsa-pipeline-steps .wpsa-step').removeClass('active completed');
                        $('.wpsa-pipeline-steps .wpsa-step[data-step="1"]').addClass('active');

                        wpsaToast('Paquete exportado eliminado correctamente del servidor.', 'success');

                        if (typeof refreshLogs === 'function') {
                            refreshLogs();
                        }
                    } else {
                        wpsaToast(response.data && response.data.message ? response.data.message : 'Error al eliminar paquete.', 'error');
                        $allBtns.prop('disabled', false);
                        $btn.find('.wpsa-spinner').hide();
                    }
                }).fail(function () {
                    wpsaToast('Error de red o conexión al intentar eliminar el paquete.', 'error');
                    $allBtns.prop('disabled', false);
                    $btn.find('.wpsa-spinner').hide();
                });
            });
        });
    }

    /**
     * Renderiza dinámicamente la tarjeta del último paquete exportado
     */
    function renderLastExportBox(archive, deployInfo) {
        if (!archive || typeof archive !== 'object' || !archive.file_url) {
            console.warn('renderLastExportBox: archive data is missing or invalid', archive);
            return;
        }

        try {
            let deployBadgeHtml = '';
            const provider = (wpsaData.hostingProvider || 'cloudflare');
            const providerName = provider.charAt(0).toUpperCase() + provider.slice(1);

            if (deployInfo && (deployInfo.ssl_url || deployInfo.deploy_ssl_url)) {
                const liveUrl = deployInfo.ssl_url || deployInfo.deploy_ssl_url;
                deployBadgeHtml = `
                    <div class="wpsa-last-deploy-badge" style="margin-top: 14px; padding: 12px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
                            <span style="color: #065f46; font-weight: 600; font-size: 13px;">
                                <span class="dashicons dashicons-yes-alt" style="color: #10b981;"></span> Despliegue en Vivo:
                            </span>
                            <a href="${liveUrl}" target="_blank" rel="noopener noreferrer" class="button button-small button-link" style="color: #047857; text-decoration: underline; font-weight: bold;">
                                Visitar Sitio en ${providerName} &rarr;
                            </a>
                        </div>
                        <small style="color: #047857; display: block; margin-top: 4px;">
                            Estado: <strong>${(deployInfo.state || 'READY').toUpperCase()}</strong> &bull; Fecha: ${deployInfo.deployed_at || ''}
                        </small>
                    </div>
                `;
            }

            // Asegurar que el botón de descarte en la cabecera exista
            if (!$('.wpsa-btn-trash-header').length) {
                $('#wpsa-last-export-box').closest('.wpsa-card').find('.wpsa-card-header').append(
                    '<button type="button" class="wpsa-btn-trash-header btn-delete-export-action" title="Eliminar y descartar este archivo .ZIP del servidor">' +
                    '<span class="dashicons dashicons-trash"></span> Descartar Paquete' +
                    '</button>'
                );
            }

            const html = `
                <div class="wpsa-export-details" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 16px; margin-bottom: 16px;">
                    <div class="wpsa-file-icon" style="background: #eff6ff; color: #2563eb; width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 24px;">
                        <span class="dashicons dashicons-media-archive"></span>
                    </div>
                    <div class="wpsa-file-meta">
                        <h4 class="wpsa-file-name" style="margin: 0 0 6px 0; font-size: 15px; font-weight: 700; color: #1e293b;">${escapeHtml(archive.file_name)}</h4>
                        <p class="wpsa-file-sub" style="margin: 0 0 6px 0; font-size: 13px; color: #64748b;">
                            <span><strong>Tamaño:</strong> ${escapeHtml(archive.file_size)}</span> &bull;
                            <span><strong>Archivos:</strong> ${escapeHtml(archive.files_count)}</span> &bull;
                            <span><strong>Fecha:</strong> ${escapeHtml(archive.created_at)}</span>
                        </p>
                        <p class="wpsa-hash-box" style="margin: 0;">
                            <small style="color: #94a3b8;">SHA-256: <code>${escapeHtml(archive.sha256 ? archive.sha256.substring(0, 32) : '')}...</code></small>
                        </p>
                    </div>
                </div>
                <div class="wpsa-export-btn-group" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                    <a href="${escapeHtml(archive.file_url)}" class="wpsa-download-hero-btn" download>
                        <span class="dashicons dashicons-download"></span> Descargar Paquete .ZIP
                    </a>
                    <button type="button" id="btn-deploy-netlify" class="button button-secondary button-large wpsa-deploy-btn" data-provider="${provider}" style="padding: 10px 16px; font-weight: 600;">
                        <span class="dashicons dashicons-cloud-upload"></span>
                        <span class="btn-text">Desplegar a ${providerName} Ahora</span>
                        <span class="wpsa-spinner"></span>
                    </button>
                    <button type="button" class="button button-link-delete btn-delete-export-action" style="color: #dc2626; display: inline-flex; align-items: center; gap: 6px; font-weight: 600; text-decoration: none; padding: 10px 16px; border-radius: 8px; border: 1px solid #fecaca; background: #fff5f5; font-size: 13px; cursor: pointer; transition: all 0.2s ease;">
                        <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px;"></span>
                        <span>Eliminar Paquete</span>
                        <span class="wpsa-spinner" style="display:none;"></span>
                    </button>
                </div>
                <div id="wpsa-deploy-feedback" class="wpsa-feedback-msg" style="margin-top: 12px;"></div>

                <div class="wpsa-cf-quickstart" style="margin-top: 16px; padding: 14px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; font-size: 12.5px; color: #166534;">
                    <strong style="display: flex; align-items: center; gap: 6px; font-size: 13px; color: #14532d; margin-bottom: 6px;">
                        <span class="dashicons dashicons-yes-alt" style="color: #16a34a;"></span>
                        ¿Cómo publicar tu ZIP en Cloudflare Pages en 30 segundos (Gratis)?
                    </strong>
                    <ol style="margin: 4px 0 0 18px; padding: 0; line-height: 1.6;">
                        <li>Descarga tu archivo <strong>.ZIP</strong> con el botón verde superior.</li>
                        <li>Entra en <a href="https://dash.cloudflare.com/" target="_blank" rel="noopener noreferrer" style="color: #15803d; text-decoration: underline; font-weight: bold;">Cloudflare Dashboard</a> &rarr; <strong>Workers & Pages</strong> &rarr; <strong>Create application</strong> &rarr; <strong>Pages</strong>.</li>
                        <li>Selecciona <strong>"Upload assets"</strong>, arrastra tu archivo .ZIP (o su carpeta extraída) y haz clic en <strong>Deploy</strong>. ¡Tu sitio estará activo con SSL y CDN mundial instantáneamente!</li>
                    </ol>
                </div>
                ${deployBadgeHtml}
            `;
            $('#wpsa-last-export-box').html(html);
        } catch (err) {
            console.error('Error al renderizar la tarjeta del último paquete:', err);
        }
    }

    /**
     * Despliegue directo a Netlify y Multi-Hosting
     */
    function initDeploy() {
        $(document).on('click', '#btn-deploy-netlify, #btn-deploy-provider', function () {
            const $btn = $(this);
            const $feedback = $('#wpsa-deploy-feedback');
            const provider = $btn.data('provider') || 'hosting';
            const providerName = provider.charAt(0).toUpperCase() + provider.slice(1);

            $btn.addClass('loading').prop('disabled', true);
            $feedback.html(`<div class="notice notice-info inline"><p>Iniciando despliegue hacia <strong>${providerName}</strong>...</p></div>`);

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_deploy_to_provider',
                provider: provider,
                nonce: wpsaData.nonce
            }).done(function (response) {
                if (response.success) {
                    const info = response.data.deploy_info || {};
                    const siteUrl = info.ssl_url || info.deploy_ssl_url;
                    let urlButton = '';
                    if (siteUrl) {
                        urlButton = `<p><a href="${siteUrl}" target="_blank" rel="noopener noreferrer" class="button button-primary">Visitar Sitio Desplegado en ${providerName} &rarr;</a></p>`;
                    }
                    $feedback.html(`
                        <div class="notice notice-success inline">
                            <p><strong>¡Despliegue completado con éxito!</strong> ${response.data.message || 'El sitio ha sido transmitido correctamente.'}</p>
                            ${urlButton}
                        </div>
                    `);
                    refreshLogs();
                } else {
                    $feedback.html('<div class="notice notice-error inline"><p>' + (response.data.message || 'Error al desplegar.') + '</p></div>');
                }
            }).fail(function () {
                $feedback.html('<div class="notice notice-error inline"><p>Error de red o tiempo de espera excedido durante la transferencia.</p></div>');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });
    }

    /**
     * Motor de Recomendación Inteligente de Hosting Serverless
     */
    function initSiteAnalyzer() {
        // Re-analizar sitio bajo demanda
        $('#btn-reanalyze-site').on('click', function () {
            const $btn = $(this);
            $btn.addClass('loading').prop('disabled', true);

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_run_site_analyzer',
                nonce: wpsaData.nonce
            }).done(function (response) {
                if (response.success && response.data) {
                    wpsaToast('¡Análisis completado con éxito! Recargando...', 'success');
                    setTimeout(function () { window.location.reload(); }, 700);
                }
            }).fail(function () {
                wpsaToast('Error al conectar con el analizador del sitio.', 'error');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });

        // Aplicar proveedor en 1 clic
        $(document).on('click', '.btn-apply-provider', function () {
            const $btn = $(this);
            const provider = $btn.data('provider');
            if (!provider) return;

            $btn.prop('disabled', true).text('Aplicando...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_set_hosting_provider',
                provider: provider,
                nonce: wpsaData.nonce
            }).done(function (response) {
                if (response.success) {
                    $('#hosting_provider').val(provider);
                    const provName = provider.charAt(0).toUpperCase() + provider.slice(1);
                    $('#btn-deploy-netlify')
                        .attr('data-provider', provider)
                        .find('.btn-text').text(`Desplegar a ${provName} Ahora`);

                    wpsaToast(`¡Destino de hosting actualizado a ${provName}!`, 'success');
                    setTimeout(function () { window.location.reload(); }, 800);
                } else {
                    wpsaToast(response.data.message || 'Error al cambiar proveedor.', 'error');
                    $btn.prop('disabled', false).text('Cambiar a este Hosting');
                }
            }).fail(function () {
                wpsaToast('Error de red al intentar actualizar el proveedor.', 'error');
                $btn.prop('disabled', false).text('Cambiar a este Hosting');
            });
        });

        // Aplicar Combo Recomendado (Hosting + Email/Forms) en 1 clic
        $(document).on('click', '.btn-apply-combo', function () {
            const $btn = $(this);
            const hosting = $btn.data('hosting');
            const formProvider = $btn.data('form');

            if (!hosting || !formProvider) return;

            $btn.prop('disabled', true).text('Aplicando Combo...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_apply_combo',
                hosting: hosting,
                form_provider: formProvider,
                nonce: wpsaData.nonce
            }).done(function (response) {
                if (response.success) {
                    $('#hosting_provider').val(hosting);
                    $('#form_provider').val(formProvider);
                    wpsaAlert({
                        title: '¡Combo Aplicado con Éxito!',
                        message: `<strong>Hosting:</strong> ${hosting.toUpperCase()}<br><strong>Servicio de Formularios/Email:</strong> ${formProvider.toUpperCase()}<br><br>Las opciones han sido guardadas y optimizadas.`,
                        buttonText: 'Aceptar',
                        type: 'success',
                        icon: 'dashicons-yes-alt'
                    }).then(function () {
                        window.location.reload();
                    });
                } else {
                    wpsaToast(response.data.message || 'Error al aplicar el combo.', 'error');
                    $btn.prop('disabled', false).text('Aplicar Combo');
                }
            }).fail(function () {
                wpsaToast('Error de red al intentar aplicar el combo.', 'error');
                $btn.prop('disabled', false).text('Aplicar Combo');
            });
        });

        // Analizar con Gemini IA (Google AI Studio)
        $('#btn-analyze-gemini').on('click', function () {
            const $btn = $(this);
            const $feedback = $('#gemini-analysis-feedback');
            const $results = $('#gemini-analysis-results');
            const apiKey = $.trim($('#gemini_api_key_input').val());

            if (!apiKey) {
                $feedback.show().html('<span style="color: #ef4444;">Por favor ingresa tu API Key de Google AI Studio (Gemini) primero.</span>');
                return;
            }

            $btn.addClass('loading').prop('disabled', true);
            $feedback.show().html('<span style="color: #6366f1;"><span class="wpsa-spinner" style="display:inline-block; vertical-align: -2px; margin-right: 6px;"></span> Conectando con Gemini Flash para análisis editorial de tu sitio...</span>');
            $results.hide();

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_analyze_with_gemini',
                api_key: apiKey,
                nonce: wpsaData.nonce
            }).done(function (response) {
                if (response.success && response.data && response.data.data) {
                    const d = response.data.data;
                    $feedback.hide();
                    $results.show().html(`
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; border-bottom: 1px solid #86efac; padding-bottom: 8px;">
                            <strong style="color: #166534; font-size: 14px;">🎯 Diagnóstico Editorial Generado por Gemini IA</strong>
                            <span style="background: #dcfce7; color: #15803d; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 6px;">Gemini Flash</span>
                        </div>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; font-size: 12.5px; color: #1e293b;">
                            <div style="background: #ffffff; padding: 10px; border-radius: 6px; border: 1px solid #bbf7d0;">
                                <strong style="color: #15803d; display: block; margin-bottom: 3px;">📌 Nicho &amp; Temática:</strong>
                                ${escapeHtml(d.niche || 'General')}
                            </div>
                            <div style="background: #ffffff; padding: 10px; border-radius: 6px; border: 1px solid #bbf7d0;">
                                <strong style="color: #15803d; display: block; margin-bottom: 3px;">👥 Público Objetivo:</strong>
                                ${escapeHtml(d.target_audience || 'General')}
                            </div>
                            <div style="background: #ffffff; padding: 10px; border-radius: 6px; border: 1px solid #bbf7d0;">
                                <strong style="color: #15803d; display: block; margin-bottom: 3px;">📅 Cadencia Recomendada:</strong>
                                ${escapeHtml(d.recommended_cadence || '3 a 5 posts/día')}
                            </div>
                            <div style="background: #ffffff; padding: 10px; border-radius: 6px; border: 1px solid #bbf7d0;">
                                <strong style="color: #15803d; display: block; margin-bottom: 3px;">☁️ Hosting Recomendado:</strong>
                                ${escapeHtml(d.hosting_verdict || 'Cloudflare Pages')}
                            </div>
                            <div style="background: #ffffff; padding: 10px; border-radius: 6px; border: 1px solid #bbf7d0; grid-column: 1 / -1;">
                                <strong style="color: #15803d; display: block; margin-bottom: 3px;">🎁 Lead Magnet en Google Sheets:</strong>
                                ${escapeHtml(d.lead_magnet_idea || 'Plantilla o recurso descargable')}
                            </div>
                            <div style="background: #ffffff; padding: 10px; border-radius: 6px; border: 1px solid #bbf7d0; grid-column: 1 / -1;">
                                <strong style="color: #15803d; display: block; margin-bottom: 3px;">🛡️ Estrategia Anti-Penalización IA:</strong>
                                ${escapeHtml(d.seo_advice || 'Mantener cadencia regular con títulos variados')}
                            </div>
                        </div>
                    `);
                } else {
                    $feedback.show().html('<span style="color: #ef4444;">' + escapeHtml(response.data ? response.data.message : 'No se pudo completar el análisis.') + '</span>');
                }
            }).fail(function () {
                $feedback.show().html('<span style="color: #ef4444;">Error de red al conectar con Google AI Studio.</span>');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });

        // Combinador Libre Mix & Match: Validación en tiempo real
        function updateMixMatchCompatibility() {
            const hosting = $('#mixmatch_hosting').val();
            const form = $('#mixmatch_form').val();
            const matrix = wpsaData.compatibilityMatrix || {};
            const $badge = $('#mixmatch-compat-badge');
            const $notice = $('#mixmatch-compat-notice');
            const $applyBtn = $('#btn-apply-mixmatch');

            let isCompatible = true;
            let message = '';

            if (matrix.hosting_to_forms && matrix.hosting_to_forms[hosting]) {
                const hRules = matrix.hosting_to_forms[hosting];
                if (hRules.disallowed && hRules.disallowed.indexOf(form) !== -1) {
                    isCompatible = false;
                    message = hRules.disallow_msg || 'Esta combinación de hosting y formularios no es compatible.';
                }
            }

            if (isCompatible) {
                $badge.css({ 'background': '#ecfdf5', 'color': '#047857' }).html('✓ Combinación 100% Compatible');
                $notice.hide();
                $applyBtn.prop('disabled', false).css('opacity', '1');
            } else {
                $badge.css({ 'background': '#fef2f2', 'color': '#b91c1c' }).html('⚠️ Combinación Incompatible');
                $notice.show().css({ 'background': '#fef2f2', 'border': '1px solid #fecaca', 'color': '#991b1b' }).html(`
                    <strong style="display: block; margin-bottom: 2px;">⚠️ Incompatibilidad detectada:</strong>
                    ${message}
                `);
                $applyBtn.prop('disabled', true).css('opacity', '0.6');
            }
        }

        $('#mixmatch_hosting, #mixmatch_form').on('change', function () {
            updateMixMatchCompatibility();
        });

        // Aplicar Combinación Mix & Match
        $('#btn-apply-mixmatch').on('click', function () {
            const $btn = $(this);
            const hosting = $('#mixmatch_hosting').val();
            const form = $('#mixmatch_form').val();

            $btn.addClass('loading').prop('disabled', true);

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_apply_combo',
                hosting: hosting,
                form_provider: form,
                nonce: wpsaData.nonce
            }).done(function (response) {
                if (response.success) {
                    $('#hosting_provider').val(hosting);
                    $('#form_provider').val(form);
                    wpsaAlert({
                        title: '¡Combinación Personalizada Guardada!',
                        message: `<strong>Hosting:</strong> ${hosting.toUpperCase()}<br><strong>Servicio de Formularios/Email:</strong> ${form.toUpperCase()}`,
                        buttonText: 'Aceptar',
                        type: 'success',
                        icon: 'dashicons-yes-alt'
                    }).then(function () {
                        window.location.reload();
                    });
                } else {
                    wpsaToast(response.data.message || 'Error al aplicar combinación.', 'error');
                }
            }).fail(function () {
                wpsaToast('Error de red al aplicar combinación.', 'error');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });

        // Sincronización en Tab 2: cuando se cambia hosting_provider, deshabilitar netlify forms si no es netlify
        function syncTab2HostingFormOptions() {
            const hosting = $('#hosting_provider').val();
            const $formSelect = $('#form_provider');
            const $netlifyOption = $formSelect.find('option[value="netlify"]');

            if (hosting !== 'netlify') {
                $netlifyOption.prop('disabled', true).text('Netlify Forms (Incompatible con ' + hosting.toUpperCase() + ' - Requiere Netlify)');
                if ($formSelect.val() === 'netlify') {
                    $formSelect.val('google_sheets');
                }
            } else {
                $netlifyOption.prop('disabled', false).text('Netlify Forms (Solo si hospedas en Netlify)');
            }
        }

        $('#hosting_provider').on('change', function () {
            syncTab2HostingFormOptions();
        });
        syncTab2HostingFormOptions();
        updateMixMatchCompatibility();
    }

    /**
     * Purga manual de Netlify
     */
    function initPurge() {
        $('#btn-force-purge').on('click', function () {
            wpsaConfirm({
                title: '¿Purgar Caché CDN?',
                message: wpsaData.strings.confirmPurge || '¿Deseas invalidar la caché del CDN en este momento para forzar la actualización de los contenidos?',
                confirmText: 'Sí, purgar ahora',
                cancelText: 'Cancelar',
                type: 'warning',
                icon: 'dashicons-update'
            }).then(function (confirmed) {
                if (!confirmed) return;

                const $btn = $('#btn-force-purge');
                const $feedback = $('#purge-feedback');

                $btn.addClass('loading').prop('disabled', true);
                $feedback.text('Purgando envíos antiguos en Netlify...');

                $.post(wpsaData.ajaxUrl, {
                    action: 'wpsa_purge_netlify',
                    nonce: wpsaData.nonce
                }).done(function (response) {
                    if (response.success) {
                        $feedback.html('<div class="notice notice-success inline"><p>' + response.data.message + '</p></div>');
                        wpsaToast('Caché purgada exitosamente.', 'success');
                    } else {
                        $feedback.html('<div class="notice notice-error inline"><p>' + response.data.message + '</p></div>');
                        wpsaToast(response.data.message || 'Error al purgar caché.', 'error');
                    }
                    refreshLogs();
                }).fail(function () {
                    $feedback.html('<div class="notice notice-error inline"><p>Error al comunicar la purga.</p></div>');
                    wpsaToast('Error al comunicar la purga.', 'error');
                }).always(function () {
                    $btn.removeClass('loading').prop('disabled', false);
                });
            });
        });
    }

    /**
     * Terminal y logs de actividad
     */
    function initLogs() {
        $('#btn-refresh-logs').on('click', function () {
            refreshLogs();
        });

        $('#btn-clear-logs').on('click', function () {
            wpsaConfirm({
                title: '¿Limpiar Registros?',
                message: 'Se borrarán todos los eventos y registros de actividad acumulados en la consola.',
                confirmText: 'Sí, limpiar registros',
                cancelText: 'Cancelar',
                type: 'warning',
                icon: 'dashicons-trash'
            }).then(function (confirmed) {
                if (!confirmed) return;

                $.post(wpsaData.ajaxUrl, {
                    action: 'wpsa_clear_logs',
                    nonce: wpsaData.nonce
                }).done(function () {
                    $('#wpsa-terminal-log').html('<div class="wpsa-log-empty">No hay registros de actividad aún.</div>');
                    wpsaToast('Registros de actividad eliminados.', 'info');
                });
            });
        });
    }

    function refreshLogs() {
        $.post(wpsaData.ajaxUrl, {
            action: 'wpsa_get_logs',
            nonce: wpsaData.nonce
        }).done(function (response) {
            if (response.success && response.data.logs) {
                const logs = response.data.logs;
                const $terminal = $('#wpsa-terminal-log');
                if (logs.length === 0) {
                    $terminal.html('<div class="wpsa-log-empty">No hay registros de actividad aún.</div>');
                    return;
                }

                let html = '';
                logs.slice().reverse().forEach(function (log) {
                    const typeClass = 'log-' + (log.type || 'info');
                    html += `
                        <div class="wpsa-log-row ${typeClass}">
                            <span class="log-time">[${log.time}]</span>
                            <span class="log-badge">[${(log.type || 'info').toUpperCase()}]</span>
                            <span class="log-msg">${escapeHtml(log.message)}</span>
                        </div>
                    `;
                });
                $terminal.html(html);
                $terminal.scrollTop($terminal[0].scrollHeight);
            }
        });
    }

    /**
     * Copiar al portapapeles con retroalimentación visual inmediata
     */
    function initClipboard() {
        function copyText(text, callback) {
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function () {
                    if (typeof callback === 'function') callback(true);
                }).catch(function () {
                    fallbackCopyText(text, callback);
                });
            } else {
                fallbackCopyText(text, callback);
            }
        }

        function fallbackCopyText(text, callback) {
            try {
                const tempTextArea = document.createElement('textarea');
                tempTextArea.value = text;
                tempTextArea.setAttribute('readonly', '');
                tempTextArea.style.position = 'fixed';
                tempTextArea.style.left = '-9999px';
                tempTextArea.style.top = '0';
                document.body.appendChild(tempTextArea);
                tempTextArea.focus();
                tempTextArea.select();
                const successful = document.execCommand('copy');
                document.body.removeChild(tempTextArea);
                if (typeof callback === 'function') callback(successful);
            } catch (err) {
                if (typeof callback === 'function') callback(false);
            }
        }

        // 1. Botón Maestro: Copiar Script Completo (Todo en 1)
        $('#btn-copy-full-sql').on('click', function () {
            const $btn = $(this);
            const fullSql = $('#wpsa-full-sql-raw').val() || $('#wpsa-sql-content').text();
            const originalHtml = $btn.html();

            copyText(fullSql, function (success) {
                if (success) {
                    $btn.addClass('copied').html('<span class="dashicons dashicons-yes"></span> <span class="wpsa-btn-copy-label">¡Script Completo Copiado!</span>');
                    setTimeout(function () {
                        $btn.removeClass('copied').html(originalHtml);
                    }, 2500);
                }
            });
        });

        // 2. Botones individuales por Paso en Tarjetas SQL
        $(document).on('click', '.wpsa-copy-code-btn', function () {
            const $btn = $(this);
            const targetSelector = $btn.data('clipboard-target');
            const codeText = $(targetSelector).text();
            const originalHtml = $btn.html();

            copyText(codeText, function (success) {
                if (success) {
                    $btn.addClass('copied').html('<span class="dashicons dashicons-yes"></span> <span class="wpsa-copy-text">¡Copiado!</span>');
                    setTimeout(function () {
                        $btn.removeClass('copied').html(originalHtml);
                    }, 2000);
                }
            });
        });

        // 3. Botones de copia rápida inline (IPs de DNS, comandos WP-CLI, etc.)
        $(document).on('click', '.wpsa-inline-copy-btn', function () {
            const $btn = $(this);
            const textToCopy = $btn.data('copy-text');
            const originalHtml = $btn.html();

            if (!textToCopy) return;

            copyText(textToCopy, function (success) {
                if (success) {
                    $btn.addClass('copied').html('<span class="dashicons dashicons-yes"></span> <span>¡Copiado!</span>');
                    setTimeout(function () {
                        $btn.removeClass('copied').html(originalHtml);
                    }, 2000);
                }
            });
        });

        // 4. Compatibilidad con botón SQL previo
        $('#btn-copy-sql').on('click', function () {
            const $btn = $(this);
            const sqlText = $('#wpsa-sql-content').text() || $('#wpsa-full-sql-raw').val();
            const originalHtml = $btn.html();

            copyText(sqlText, function (success) {
                if (success) {
                    $btn.addClass('copied').html('<span class="dashicons dashicons-yes"></span> ¡Copiado!');
                    setTimeout(function () {
                        $btn.removeClass('copied').html(originalHtml);
                    }, 2000);
                }
            });
        });
    }

    /**
     * Bandeja de Moderación de Comentarios de Supabase
     */
    function initModeration() {
        let currentStatus = 'all';
        let hasLoadedOnce = false;

        // Cargar al hacer clic en la pestaña si no se ha cargado
        $('#tab-btn-moderation').on('click', function () {
            if (!hasLoadedOnce) {
                loadComments(currentStatus);
                hasLoadedOnce = true;
            }
        });

        // Botón de recarga
        $('#btn-reload-comments').on('click', function () {
            loadComments(currentStatus);
        });

        // Filtros
        $('.wpsa-filter-btn').on('click', function () {
            $('.wpsa-filter-btn').removeClass('active button-primary').addClass('button-secondary');
            $(this).removeClass('button-secondary').addClass('active button-primary');
            currentStatus = $(this).data('status');
            loadComments(currentStatus);
        });

        function loadComments(status) {
            const $wrapper = $('#wpsa-comments-moderation-wrapper');
            $wrapper.html('<div style="text-align:center; padding: 40px; color: #64748b;"><span class="dashicons dashicons-update" style="animation: wpsa-spin 1s linear infinite;"></span> Cargando comentarios de Supabase...</div>');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_load_admin_comments',
                nonce: wpsaData.nonce,
                status: status
            }).done(function (response) {
                if (response.success) {
                    renderCommentsTable(response.data.comments);
                } else {
                    $wrapper.html(`
                        <div class="notice notice-error inline" style="margin: 20px 0;">
                            <p><strong>No se pudieron cargar los comentarios:</strong> ${response.data.message || 'Error de conexión'}</p>
                            <p><small>Verifica que hayas guardado tu Service Role Key en la pestaña Configuración de APIs.</small></p>
                        </div>
                    `);
                }
            }).fail(function () {
                $wrapper.html('<div class="notice notice-error inline"><p>Error de comunicación al consultar la API de Supabase.</p></div>');
            });
        }

        function renderCommentsTable(comments) {
            const $wrapper = $('#wpsa-comments-moderation-wrapper');

            if (!comments || comments.length === 0) {
                $wrapper.html('<div style="text-align:center; padding: 40px; color:#64748b;"><p>No hay comentarios registrados para este filtro.</p></div>');
                return;
            }

            let html = `
                <table class="wp-list-table widefat fixed striped" style="border-radius: 6px; overflow: hidden;">
                    <thead>
                        <tr>
                            <th style="width: 180px;">Autor</th>
                            <th>Comentario</th>
                            <th style="width: 140px;">Página (Slug)</th>
                            <th style="width: 140px;">Fecha</th>
                            <th style="width: 110px;">Estado</th>
                            <th style="width: 160px; text-align: right;">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
            `;

            comments.forEach(function (c) {
                const isApproved = c.is_approved === true;
                const statusBadge = isApproved
                    ? '<span class="status-badge status-active">Aprobado</span>'
                    : '<span class="status-badge status-inactive">Pendiente</span>';

                const toggleBtn = isApproved
                    ? `<button type="button" class="button button-small btn-toggle-status" data-id="${c.id}" data-action="0" title="Marcar como pendiente">Desaprobar</button>`
                    : `<button type="button" class="button button-small button-primary btn-toggle-status" data-id="${c.id}" data-action="1" title="Aprobar para publicación">Aprobar</button>`;

                const dateStr = new Date(c.created_at).toLocaleDateString(undefined, {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });

                html += `
                    <tr id="comment-row-${c.id}">
                        <td>
                            <strong>${escapeHtml(c.author_name)}</strong>
                            ${c.author_email ? `<br><small style="color:#64748b;">${escapeHtml(c.author_email)}</small>` : ''}
                        </td>
                        <td>
                            <div style="max-height: 80px; overflow-y: auto; font-size: 13px; line-height: 1.5;">
                                ${escapeHtml(c.content)}
                            </div>
                        </td>
                        <td><code>/${escapeHtml(c.post_slug)}/</code></td>
                        <td><small>${dateStr}</small></td>
                        <td>${statusBadge}</td>
                        <td style="text-align: right;">
                            <div style="display: flex; gap: 4px; justify-content: flex-end;">
                                ${toggleBtn}
                                <button type="button" class="button button-small btn-delete-comment wpsa-danger-btn" data-id="${c.id}" title="Eliminar definitivamente">
                                    <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; line-height: 24px;"></span>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            });

            html += '</tbody></table>';
            $wrapper.html(html);
        }

        // Cambiar estado de aprobación
        $(document).on('click', '.btn-toggle-status', function () {
            const $btn = $(this);
            const commentId = $btn.data('id');
            const targetAction = $btn.data('action');

            $btn.prop('disabled', true);

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_moderate_comment',
                nonce: wpsaData.nonce,
                comment_id: commentId,
                is_approved: targetAction
            }).done(function (res) {
                if (res.success) {
                    loadComments(currentStatus);
                    wpsaToast('Estado del comentario actualizado con éxito.', 'success');
                } else {
                    wpsaToast(res.data.message || 'Error al cambiar estado.', 'error');
                    $btn.prop('disabled', false);
                }
            }).fail(function () {
                wpsaToast('Error de conexión al moderar comentario.', 'error');
                $btn.prop('disabled', false);
            });
        });

        // Eliminar comentario
        $(document).on('click', '.btn-delete-comment', function () {
            const $btn = $(this);
            const commentId = $btn.data('id');

            wpsaConfirm({
                title: '¿Eliminar Comentario?',
                message: '¿Estás seguro de que deseas eliminar este comentario definitivamente de Supabase? Esta acción no se puede deshacer.',
                confirmText: 'Sí, eliminar',
                cancelText: 'Cancelar',
                type: 'danger',
                icon: 'dashicons-trash'
            }).then(function (confirmed) {
                if (!confirmed) return;

                $btn.prop('disabled', true);

                $.post(wpsaData.ajaxUrl, {
                    action: 'wpsa_delete_comment',
                    nonce: wpsaData.nonce,
                    comment_id: commentId
                }).done(function (res) {
                    if (res.success) {
                        $(`#comment-row-${commentId}`).fadeOut(300, function () {
                            $(this).remove();
                        });
                        wpsaToast('Comentario eliminado exitosamente.', 'success');
                    } else {
                        wpsaToast(res.data.message || 'Error al eliminar comentario.', 'error');
                        $btn.prop('disabled', false);
                    }
                }).fail(function () {
                    wpsaToast('Error de red al intentar eliminar comentario.', 'error');
                    $btn.prop('disabled', false);
                });
            });
        });
    }

    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        const str = String(text);
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return str.replace(/[&<>"']/g, function (m) { return map[m]; });
    }

    /**
     * Modal de Recorrido Visual Interactivo
     */
    function initTourModal() {
        let currentSlide = 1;
        const totalSlides = $('.wpsa-tour-slide').length || 6;

        function showSlide(index) {
            if (index < 1) index = 1;
            if (index > totalSlides) index = totalSlides;
            currentSlide = index;

            $('.wpsa-tour-slide').removeClass('active');
            $('.wpsa-tour-slide[data-slide="' + currentSlide + '"]').addClass('active');

            $('.wpsa-tour-dot').removeClass('active');
            $('.wpsa-tour-dot[data-slide="' + currentSlide + '"]').addClass('active');

            // Actualizar estado de botones
            $('#btn-tour-prev').prop('disabled', currentSlide === 1);

            if (currentSlide === totalSlides) {
                $('#btn-tour-next').hide();
                $('#btn-tour-finish').show();
            } else {
                $('#btn-tour-next').show();
                $('#btn-tour-finish').hide();
            }
        }

        function openTour() {
            showSlide(1);
            $('#wpsa-tour-modal-backdrop').fadeIn(200);
            $('body').addClass('wpsa-modal-open');
        }

        function closeTour() {
            $('#wpsa-tour-modal-backdrop').fadeOut(200);
            $('body').removeClass('wpsa-modal-open');
        }

        // Abrir tour desde cabecera o botón en guía
        $('#btn-open-tour, .wpsa-btn-start-tour').on('click', function (e) {
            e.preventDefault();
            openTour();
        });

        // Cerrar modal
        $('#btn-close-tour, #btn-tour-finish').on('click', function (e) {
            e.preventDefault();
            closeTour();
        });

        // Click fuera del modal para cerrar
        $('#wpsa-tour-modal-backdrop').on('click', function (e) {
            if ($(e.target).is('#wpsa-tour-modal-backdrop') || $(e.target).hasClass('wpsa-tour-modal-container')) {
                closeTour();
            }
        });

        // Navegación con botones
        $('#btn-tour-next').on('click', function (e) {
            e.preventDefault();
            showSlide(currentSlide + 1);
        });

        $('#btn-tour-prev').on('click', function (e) {
            e.preventDefault();
            showSlide(currentSlide - 1);
        });

        // Navegación con dots
        $('.wpsa-tour-dot').on('click', function () {
            const slide = parseInt($(this).data('slide'), 10);
            if (slide) {
                showSlide(slide);
            }
        });

        // Navegación con teclado (Esc, Flechas)
        $(document).on('keydown', function (e) {
            if ($('#wpsa-tour-modal-backdrop').is(':visible')) {
                if (e.key === 'Escape') {
                    closeTour();
                } else if (e.key === 'ArrowRight') {
                    showSlide(currentSlide + 1);
                } else if (e.key === 'ArrowLeft') {
                    showSlide(currentSlide - 1);
                }
            }
        });
    }

    /**
     * Salto directo entre pestañas desde la guía
     */
    function initJumpTabs() {
        $(document).on('click', '.wpsa-jump-tab', function (e) {
            e.preventDefault();
            const targetTab = $(this).data('jump');
            if (targetTab) {
                // Cerrar modal si estaba abierto
                $('#wpsa-tour-modal-backdrop').fadeOut(200);
                $('body').removeClass('wpsa-modal-open');

                // Cambiar a la pestaña correspondiente
                const $tabBtn = $('.wpsa-tab-btn[data-tab="' + targetTab + '"]');
                if ($tabBtn.length) {
                    $tabBtn.trigger('click');
                    $('html, body').animate({
                        scrollTop: $('.wpsa-tabs-nav').offset().top - 40
                    }, 300);
                }
            }
        });
    }

    /**
     * Acordeón de preguntas frecuentes (FAQ)
     */
    function initFaq() {
        $('.wpsa-faq-question').on('click', function () {
            const $item = $(this).closest('.wpsa-faq-item');
            const $ans = $item.find('.wpsa-faq-answer');

            $item.toggleClass('active');
            $ans.slideToggle(200);
        });
    }

    /**
     * Vinculación de dominio personalizado en 1 clic con la API de Netlify
     */
    function initCustomDomainLink() {
        $('#btn-link-custom-domain').on('click', function () {
            const $btn = $(this);
            const $feedback = $('#custom-domain-link-feedback');
            const domain = $.trim($('#custom_domain').val());

            if (!domain) {
                $feedback.removeClass('notice-success notice-warning')
                         .addClass('notice-error')
                         .html('Por favor introduce un nombre de dominio (ej. <code>miempresa.com</code>) antes de vincular.')
                         .fadeIn();
                return;
            }

            $btn.addClass('loading').prop('disabled', true);
            $feedback.removeClass('notice-success notice-error notice-warning')
                     .html('Conectando con la API de Netlify para registrar el dominio...')
                     .fadeIn();

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_link_custom_domain_netlify',
                nonce: wpsaData.nonce,
                custom_domain: domain
            }).done(function (response) {
                if (response.success) {
                    $feedback.removeClass('notice-error notice-warning')
                             .addClass('notice-success')
                             .html('<strong>¡Éxito!</strong> ' + response.data.message);
                    if (response.data.custom_domain) {
                        $('#custom_domain').val(response.data.custom_domain);
                    }
                    if (typeof refreshLogs === 'function') {
                        refreshLogs();
                    }
                } else {
                    $feedback.removeClass('notice-success notice-warning')
                             .addClass('notice-error')
                             .html('<strong>Error:</strong> ' + (response.data.message || 'No se pudo vincular el dominio.'));
                }
            }).fail(function () {
                $feedback.removeClass('notice-success notice-warning')
                         .addClass('notice-error')
                         .html('Error de red al intentar comunicarse con el servidor WordPress.');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
            });
        });
    }

    /**
     * Asistente Editorial de Artículos con IA (SEO & GEO en Vivo)
     */
    function initAiArticleGenerator() {
        // Conmutador de Modos
        $('#btn-mode-custom-idea').on('click', function () {
            $(this).removeClass('button-secondary').addClass('button-primary');
            $('#btn-mode-auto-discover').removeClass('button-primary').addClass('button-secondary');
            $('#wpsa-ai-panel-custom-idea').fadeIn(200);
            $('#wpsa-ai-panel-auto-discover').hide();
        });

        $('#btn-mode-auto-discover').on('click', function () {
            $(this).removeClass('button-secondary').addClass('button-primary');
            $('#btn-mode-custom-idea').removeClass('button-primary').addClass('button-secondary');
            $('#wpsa-ai-panel-auto-discover').fadeIn(200);
            $('#wpsa-ai-panel-custom-idea').hide();
        });

        // Modo 2: Descubrir Temas en Motores de Búsqueda
        $('#btn-wpsa-discover-topics').on('click', function () {
            const $btn = $(this);
            const category = $('#wpsa-ai-discover-category').val();
            const $wrapper = $('#wpsa-discovered-topics-wrapper');
            const $grid = $('#wpsa-discovered-topics-grid');

            $btn.addClass('loading').prop('disabled', true);
            $btn.find('.btn-text').text('Escaneando Google y Wikipedia...');

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_ai_discover_topics',
                nonce: wpsaData.nonce,
                category: category,
                count: 6
            }).done(function (response) {
                if (response.success && response.data && response.data.topics) {
                    $grid.empty();
                    response.data.topics.forEach(function (topic, index) {
                        const cardHtml = `
                            <div class="wpsa-topic-card" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                <div>
                                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                                        <span style="font-size: 11px; font-weight: 700; background: #e0e7ff; color: #4338ca; padding: 2px 8px; border-radius: 10px;">
                                            PROPUESTA #${index + 1}
                                        </span>
                                        <span style="font-size: 11px; color: #64748b; font-weight: 600;">
                                            ${topic.palabra_clave || ''}
                                        </span>
                                    </div>
                                    <h4 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 700; color: #1e293b; line-height: 1.4;">
                                        ${topic.titulo}
                                    </h4>
                                    <p style="margin: 0 0 6px 0; font-size: 12px; color: #475569;">
                                        <strong>Dato base:</strong> ${topic.dato_medible_base || 'No especificado'}
                                    </p>
                                    <p style="margin: 0 0 12px 0; font-size: 12px; color: #64748b;">
                                        <strong>Variable:</strong> ${topic.variable_alterada || 'No especificada'}
                                    </p>
                                </div>
                                <button type="button" class="button button-primary btn-generate-from-topic" 
                                    data-topic="${$('<div>').text(topic.titulo).html()}" 
                                    data-category="${category}" 
                                    data-keyword="${topic.palabra_clave || ''}" 
                                    style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 6px; background: #7c3aed; border-color: #6d28d9;">
                                    <span class="dashicons dashicons-welcome-write-blog"></span> Redactar este Artículo en 1 Clic
                                </button>
                            </div>
                        `;
                        $grid.append(cardHtml);
                    });
                    $wrapper.fadeIn(250);
                } else {
                    wpsaToast('Error al descubrir temas: ' + (response.data ? response.data.message : 'Respuesta desconocida'), 'error');
                }
            }).fail(function () {
                wpsaToast('Error de red al intentar descubrir temas en los motores de búsqueda.', 'error');
            }).always(function () {
                $btn.removeClass('loading').prop('disabled', false);
                $btn.find('.btn-text').text('Escanear Tendencias de Búsqueda y Proponer Temas');
            });
        });

        // Función de Generación de Artículo
        function ejecutarGeneracionArticulo(topic, category, keyword) {
            const $progress = $('#wpsa-ai-generation-progress');
            const $progressText = $('#wpsa-ai-progress-text');
            const $result = $('#wpsa-ai-generation-result');
            const $btnCustom = $('#btn-wpsa-generate-custom');
            const $topicButtons = $('.btn-generate-from-topic');

            $btnCustom.addClass('loading').prop('disabled', true);
            $topicButtons.prop('disabled', true);
            $result.hide();
            $progress.fadeIn(200);

            // Simulación visual de pasos durante la generación
            const pasos = [
                'Paso 1/4: Consultando Google Suggest y Wikipedia para recopilar datos científicos medibles...',
                'Paso 2/4: Verificando 240 artículos existentes para resolver interlinking contextual...',
                'Paso 3/4: Estructurando arquitectura GEO y redactando 1400-1900 palabras con rigor estricto...',
                'Paso 4/4: Creando borrador en WordPress con RankMath SEO y metadatos de imágenes...'
            ];
            let pasoActual = 0;
            $progressText.text(pasos[0]);
            const intervalo = setInterval(function () {
                pasoActual = (pasoActual + 1) % pasos.length;
                $progressText.text(pasos[pasoActual]);
            }, 12000);

            $.post(wpsaData.ajaxUrl, {
                action: 'wpsa_ai_generate_article',
                nonce: wpsaData.nonce,
                topic: topic,
                category: category,
                keyword: keyword
            }).done(function (response) {
                clearInterval(intervalo);
                if (response.success && response.data) {
                    const data = response.data;
                    $('#wpsa-ai-result-title').text('¡Borrador Creado: "' + data.title + '"!');
                    $('#wpsa-ai-result-meta').html(
                        '<strong>Extensión:</strong> ' + data.word_count + ' palabras &bull; ' +
                        '<strong>Slug:</strong> <code>/' + data.slug + '/</code> &bull; ' +
                        '<strong>Borrador ID:</strong> #' + data.post_id + ' &bull; ' +
                        '<strong>RankMath:</strong> Configurado'
                    );
                    $('#wpsa-ai-btn-edit-post').attr('href', data.edit_url);

                    $progress.hide();
                    $result.fadeIn(250);
                    $('html, body').animate({
                        scrollTop: $result.offset().top - 80
                    }, 500);
                } else {
                    $progress.hide();
                    wpsaToast('Error al generar el artículo: ' + (response.data ? response.data.message : 'Error desconocido.'), 'error');
                }
            }).fail(function () {
                clearInterval(intervalo);
                $progress.hide();
                wpsaToast('Error de conexión o timeout durante la generación del artículo. Revisa la consola o logs.', 'error');
            }).always(function () {
                $btnCustom.removeClass('loading').prop('disabled', false);
                $topicButtons.prop('disabled', false);
            });
        }

        // Trigger desde Modo 1: Idea Propia
        $('#btn-wpsa-generate-custom').on('click', function () {
            const topic = $('#wpsa-ai-custom-topic').val().trim();
            const category = $('#wpsa-ai-custom-category').val();
            const keyword = $('#wpsa-ai-custom-keyword').val().trim();

            if (!topic) {
                wpsaToast('Por favor ingresa una premisa o hipótesis científica (ej. ¿Qué pasaría si la gravedad disminuyera un 10%?).', 'warning');
                $('#wpsa-ai-custom-topic').focus();
                return;
            }

            ejecutarGeneracionArticulo(topic, category, keyword);
        });

        // Trigger desde Modo 2: Clic en propuesta descubierta
        $(document).on('click', '.btn-generate-from-topic', function () {
            const topic = $(this).data('topic');
            const category = $(this).data('category');
            const keyword = $(this).data('keyword');

            ejecutarGeneracionArticulo(topic, category, keyword);
        });
    }

})(jQuery);

