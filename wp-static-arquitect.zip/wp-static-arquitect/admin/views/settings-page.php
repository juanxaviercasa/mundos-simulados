<?php
/**
 * Plantilla de la interfaz de administración de WP Static Architect.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$netlify_pat         = get_option( 'wp_static_arquitect_netlify_pat', '' );
$netlify_site_id     = get_option( 'wp_static_arquitect_netlify_site_id', '' );
$threshold_count     = get_option( 'wp_static_arquitect_netlify_threshold_count', 80 );
$threshold_mb        = get_option( 'wp_static_arquitect_netlify_threshold_mb', 8 );

$supabase_url        = get_option( 'wp_static_arquitect_supabase_url', '' );
$supabase_anon_key   = get_option( 'wp_static_arquitect_supabase_anon_key', '' );
$supabase_service_k  = get_option( 'wp_static_arquitect_supabase_service_key', '' );
$supabase_auto_app   = get_option( 'wp_static_arquitect_supabase_auto_approve', '0' );
$url_mode            = get_option( 'wp_static_arquitect_url_mode', 'root-relative' );

$enable_search       = get_option( 'wp_static_arquitect_enable_search', '1' );
$additional_urls     = get_option( 'wp_static_arquitect_additional_urls', '' );
$excluded_urls       = get_option( 'wp_static_arquitect_excluded_urls', '' );
$enable_sitemap      = get_option( 'wp_static_arquitect_enable_sitemap', '1' );
$production_url      = get_option( 'wp_static_arquitect_production_url', '' );
$deploy_on_save      = get_option( 'wp_static_arquitect_deploy_on_save', '0' );
$netlify_build_hook  = get_option( 'wp_static_arquitect_netlify_build_hook', '' );
$scheduled_deploy_enabled = get_option( 'wp_static_arquitect_scheduled_deploy_enabled', '0' );
$scheduled_deploy_time    = get_option( 'wp_static_arquitect_scheduled_deploy_time', '23:00' );
$scheduled_smart_check    = get_option( 'wp_static_arquitect_scheduled_deploy_smart_check', '1' );
$next_scheduled_deploy    = wp_next_scheduled( 'wp_static_arquitect_daily_scheduled_deploy_cron' );
$turnstile_site_key  = get_option( 'wp_static_arquitect_turnstile_site_key', '' );

$enable_geo          = get_option( 'wp_static_arquitect_enable_geo', '1' );
$llms_full           = get_option( 'wp_static_arquitect_llms_full', '0' );
$enable_forms        = get_option( 'wp_static_arquitect_enable_forms', '1' );
$enable_comments     = get_option( 'wp_static_arquitect_enable_comments', '1' );
$service_tier        = get_option( 'wp_static_arquitect_service_tier', 'creator_pro' );
if ( empty( $service_tier ) || 'free' === $service_tier ) {
	$service_tier = 'creator_pro';
}
$hosting_provider    = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );
$custom_domain       = get_option( 'wp_static_arquitect_custom_domain', '' );

$last_export         = get_option( 'wp_static_arquitect_last_export_info', null );
$last_purge          = get_option( 'wp_static_arquitect_last_purge_info', null );
$last_deploy         = get_option( 'wp_static_arquitect_last_deploy_info', null );
$netlify_auto_deploy = get_option( 'wp_static_arquitect_netlify_auto_deploy', '0' );
$netlify_custom_redirects = get_option( 'wp_static_arquitect_netlify_custom_redirects', '' );
$netlify_custom_headers   = get_option( 'wp_static_arquitect_netlify_custom_headers', '' );

// Opciones Multi-Hosting (Cloudflare Pages, GitHub, Render, Formularios Serverless)
// Opciones Multi-Hosting (Cloudflare Pages, GitHub, Render, Formularios Serverless)
$cloudflare_deploy_hook = get_option( 'wp_static_arquitect_cloudflare_deploy_hook', '' );
$cloudflare_account_id  = get_option( 'wp_static_arquitect_cloudflare_account_id', '' );
$cloudflare_project_name = get_option( 'wp_static_arquitect_cloudflare_project_name', '' );
$cloudflare_api_token   = get_option( 'wp_static_arquitect_cloudflare_api_token', '' );

$github_token           = get_option( 'wp_static_arquitect_github_token', '' );
$github_repo            = get_option( 'wp_static_arquitect_github_repo', '' );
$github_branch          = get_option( 'wp_static_arquitect_github_branch', 'main' );
$github_workflow        = get_option( 'wp_static_arquitect_github_workflow', 'deploy.yml' );

$render_deploy_hook     = get_option( 'wp_static_arquitect_render_deploy_hook', '' );

$form_provider          = get_option( 'wp_static_arquitect_form_provider', 'auto' );
$google_sheets_url      = get_option( 'wp_static_arquitect_google_sheets_url', '' );
$web3forms_key          = get_option( 'wp_static_arquitect_web3forms_key', '' );
$formsubmit_email       = get_option( 'wp_static_arquitect_formsubmit_email', get_option( 'admin_email' ) );

// Pinterest Auto-Pin & Drip-Feed Editorial
$pinterest_token        = get_option( 'wp_static_arquitect_pinterest_token', '' );
$pinterest_board_id     = get_option( 'wp_static_arquitect_pinterest_board_id', '' );
$pinterest_auto_pin     = get_option( 'wp_static_arquitect_pinterest_auto_pin', '0' );
$drip_feed_enabled      = get_option( 'wp_static_arquitect_drip_feed_enabled', '0' );
$drip_posts_count       = (int) get_option( 'wp_static_arquitect_drip_posts_count', 3 );

// Ejecutar análisis rápido del sitio para el recomendador inteligente
$site_analyzer          = WP_Static_Arquitect::get_instance()->site_analyzer;
$analysis_data          = $site_analyzer->analyze_site();
$site_stats             = $analysis_data['stats'];
$recommendations        = $analysis_data['recommendations'];
$top_combos             = isset( $analysis_data['combos'] ) ? $analysis_data['combos'] : array();
$best_match             = $analysis_data['best_match'];
$best_combo             = isset( $analysis_data['best_combo'] ) ? $analysis_data['best_combo'] : null;

$schema_sql          = WP_Static_Arquitect::get_instance()->supabase_comments->get_schema_sql();
$schema_steps        = WP_Static_Arquitect::get_instance()->supabase_comments->get_schema_steps();
$system_health       = WP_Static_Arquitect_Admin::get_system_health();
?>

<div class="wrap wpsa-wrap">
    <!-- Barrera para avisos de terceros en WordPress (evita que plugins como WP Mail SMTP alteren la cabecera) -->
    <h1 class="screen-reader-text">WP Static Architect</h1>
    <hr class="wp-header-end" style="display: none; margin: 0; padding: 0; border: none;">

    <!-- Cabecera Principal con Identidad de Marca Jamstack -->
    <header class="wpsa-admin-header">
        <div class="wpsa-header-left">
            <div class="wpsa-brand-icon">
                <img src="<?php echo esc_url( WP_STATIC_ARQUITECT_URL . 'admin/assets/images/logo.svg' ); ?>" alt="Logo WP Static Architect" class="wpsa-header-logo-img">
            </div>
            <div class="wpsa-header-title-box">
                <div class="wpsa-title-row">
                    <h2 class="wpsa-header-title">WP Static <span class="wpsa-title-accent">Architect</span></h2>
                    <span class="wpsa-head-pill-tag">ARQUITECTURA JAMSTACK</span>
                </div>
                <p class="wpsa-header-subtitle">Generación estática de alto rendimiento con Netlify, Supabase, GEO e Inteligencia Artificial.</p>
                <div class="wpsa-header-pills">
                    <span class="wpsa-pill-item">⚡ Sin Timeouts</span>
                    <span class="wpsa-pill-item">🤖 Motor GEO &amp; IAs</span>
                    <span class="wpsa-pill-item">💬 Supabase RLS</span>
                    <span class="wpsa-pill-item">🌐 Multi-Hosting</span>
                </div>
            </div>
        </div>
        <div class="wpsa-header-right">
            <a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer" class="wpsa-author-badge" title="Visitar sitio web oficial del desarrollador">
                <span class="dashicons dashicons-admin-users"></span>
                <span>Desarrollado por <strong>Xavier Cabello</strong></span>
                <span class="dashicons dashicons-external"></span>
            </a>
            <span class="wpsa-health-pill <?php echo $system_health['all_ok'] ? 'wpsa-health-pass' : 'wpsa-health-warn'; ?>" title="Diagnóstico de requisitos del servidor">
                <span class="dashicons <?php echo $system_health['all_ok'] ? 'dashicons-shield' : 'dashicons-warning'; ?>"></span>
                <span>Servidor <?php echo esc_html( $system_health['passed'] . '/' . $system_health['total'] ); ?></span>
            </span>
            <button type="button" id="btn-open-tour" class="button wpsa-btn-tour" title="Iniciar recorrido visual guiado">
                <span class="dashicons dashicons-welcome-learn-more"></span>
                <span>Recorrido Visual</span>
            </button>
            <span class="wpsa-version-badge">v<?php echo esc_html( WP_STATIC_ARQUITECT_VERSION ); ?></span>
        </div>
    </header>

    <!-- Navegación por Pestañas -->
    <nav class="wpsa-tabs-nav" role="tablist">
        <button type="button" class="wpsa-tab-btn active" data-tab="tab-export">
            <span class="dashicons dashicons-media-archive"></span>
            Exportador Estático
        </button>
        <button type="button" class="wpsa-tab-btn" data-tab="tab-config">
            <span class="dashicons dashicons-admin-settings"></span>
            Hosting, Dominio & APIs
        </button>
        <button type="button" class="wpsa-tab-btn" data-tab="tab-advanced" id="tab-btn-advanced">
            <span class="dashicons dashicons-search"></span>
            Buscador, SEO & GEO (IAs)
        </button>
        <button type="button" class="wpsa-tab-btn" data-tab="tab-ai-generator" id="tab-btn-ai-generator" style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.12), rgba(168, 85, 247, 0.12)); border-color: #a855f7; font-weight: 700; color: #4338ca;">
            <span class="dashicons dashicons-superhero-alt" style="color: #7c3aed;"></span>
            Creador IA (SEO &amp; GEO)
        </button>
        <button type="button" class="wpsa-tab-btn" data-tab="tab-netlify">
            <span class="dashicons dashicons-feedback"></span>
            Netlify Forms & Purgador
        </button>
        <button type="button" class="wpsa-tab-btn" data-tab="tab-supabase">
            <span class="dashicons dashicons-admin-comments"></span>
            Supabase & Comentarios
        </button>
        <button type="button" class="wpsa-tab-btn" data-tab="tab-moderation" id="tab-btn-moderation">
            <span class="dashicons dashicons-format-chat"></span>
            Bandeja de Comentarios
        </button>
        <button type="button" class="wpsa-tab-btn" data-tab="tab-guide" id="tab-btn-guide">
            <span class="dashicons dashicons-book"></span>
            Guía & Recorrido Visual
        </button>
    </nav>

    <!-- Contenido de Pestañas -->
    <div class="wpsa-tabs-content">

        <!-- ==================== TAB 1: EXPORTADOR ESTÁTICO ==================== -->
        <div id="tab-export" class="wpsa-tab-pane active">
            <!-- Pipeline Visual de 3 Pasos -->
            <div class="wpsa-export-pipeline">
                <div class="wpsa-pipeline-step active" id="pipeline-step-1">
                    <div class="wpsa-step-num">1</div>
                    <div class="wpsa-step-content">
                        <h4 class="wpsa-step-title">Rastreo y Mapeo</h4>
                        <p class="wpsa-step-desc">Descubre las 260 páginas, 120 artículos optimizados y assets multimedia.</p>
                    </div>
                </div>
                <div class="wpsa-pipeline-step" id="pipeline-step-2">
                    <div class="wpsa-step-num">2</div>
                    <div class="wpsa-step-content">
                        <h4 class="wpsa-step-title">Optimización Serverless</h4>
                        <p class="wpsa-step-desc">HTML estático puro, SEO Rank Math 100/100, llms.txt y formularios con Cloudflare.</p>
                    </div>
                </div>
                <div class="wpsa-pipeline-step" id="pipeline-step-3">
                    <div class="wpsa-step-num">3</div>
                    <div class="wpsa-step-content">
                        <h4 class="wpsa-step-title">Empaquetado y Descarga</h4>
                        <p class="wpsa-step-desc">Genera archivo ZIP portátil listo para descargar o desplegar en 1 clic.</p>
                    </div>
                </div>
            </div>

            <div class="wpsa-grid-2col">
                <!-- Tarjeta de Acción Principal -->
                <div class="wpsa-card wpsa-action-card">
                    <div class="wpsa-card-header">
                        <h2>Generar Sitio Estático Portátil</h2>
                        <p>Rastrea todas las URLs públicas, optimiza recursos locales, inyecta funciones serverless y comprime el sitio completo en un archivo .zip.</p>
                    </div>

                    <div class="wpsa-card-body">
                        <div class="wpsa-options-summary">
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Destino de Hosting:</span>
                                <strong class="wpsa-val" style="text-transform: capitalize; color: #4f46e5;"><?php echo esc_html( $hosting_provider ); ?></strong>
                            </div>
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Dominio Canónico:</span>
                                <strong class="wpsa-val"><?php echo ! empty( $custom_domain ) ? esc_html( $custom_domain ) : ( ! empty( $production_url ) ? esc_html( $production_url ) : 'Localhost' ); ?></strong>
                            </div>
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Optimización GEO (IAs):</span>
                                <strong class="wpsa-val <?php echo '1' === $enable_geo ? 'status-badge status-active' : 'status-badge status-inactive'; ?>">
                                    <?php echo '1' === $enable_geo ? 'Activo (llms.txt)' : 'Desactivado'; ?>
                                </strong>
                            </div>
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Buscador Spotlight:</span>
                                <strong class="wpsa-val <?php echo '1' === $enable_search ? 'status-badge status-active' : 'status-badge status-inactive'; ?>">
                                    <?php echo '1' === $enable_search ? 'Activo (Ctrl+K)' : 'Desactivado'; ?>
                                </strong>
                            </div>
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Formularios Serverless:</span>
                                <strong class="wpsa-val <?php echo '1' === $enable_forms ? 'status-badge status-active' : 'status-badge status-inactive'; ?>">
                                    <?php echo '1' === $enable_forms ? 'Habilitados (Cloudflare)' : 'Desactivados'; ?>
                                </strong>
                            </div>
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Comentarios Dinámicos:</span>
                                <strong class="wpsa-val <?php echo '1' === $enable_comments ? ( ! empty( $supabase_url ) ? 'status-badge status-active' : 'status-badge status-inactive' ) : 'status-badge status-inactive'; ?>">
                                    <?php echo '1' === $enable_comments ? ( ! empty( $supabase_url ) ? 'Supabase Activo' : 'Pendiente Config' ) : 'Desactivados'; ?>
                                </strong>
                            </div>
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Perfil de Servicio:</span>
                                <strong class="wpsa-val status-badge status-active" style="background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-weight: 700;">
                                    <span class="dashicons dashicons-awards" style="font-size: 14px; width: 14px; height: 14px; vertical-align: -2px; margin-right: 2px;"></span> Modo Creador Pro (Ilimitado)
                                </strong>
                            </div>
                            <div class="wpsa-summary-item">
                                <span class="wpsa-label">Auto-Despliegue:</span>
                                <?php
                                $deploy_label = 'Manual';
                                $deploy_class = 'status-badge status-inactive';
                                if ( '1' === $deploy_on_save && '1' === $scheduled_deploy_enabled ) {
                                    $deploy_label = 'Instantáneo + Diario (' . esc_html( $scheduled_deploy_time ) . ')';
                                    $deploy_class = 'status-badge status-active';
                                } elseif ( '1' === $deploy_on_save ) {
                                    $deploy_label = 'Instantáneo Activo';
                                    $deploy_class = 'status-badge status-active';
                                } elseif ( '1' === $scheduled_deploy_enabled ) {
                                    $deploy_label = 'Diario (' . esc_html( $scheduled_deploy_time ) . ')';
                                    $deploy_class = 'status-badge status-active';
                                }
                                ?>
                                <strong class="wpsa-val <?php echo esc_attr( $deploy_class ); ?>">
                                    <?php echo esc_html( $deploy_label ); ?>
                                </strong>
                            </div>
                        </div>

                        <!-- Selector y Configuración Directa de Dominio Canónico de Producción -->
                        <div class="wpsa-inline-domain-box" style="margin: 18px 0 16px 0; padding: 16px; background: #f8fafc; border: 1.5px solid #cbd5e1; border-radius: 12px;">
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                                <label for="wpsa_export_target_domain" style="font-weight: 700; color: #1e293b; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
                                    <span class="dashicons dashicons-admin-site-alt3" style="color: #2563eb; font-size: 18px; width: 18px; height: 18px;"></span>
                                    Dominio Canónico de Producción
                                </label>
                                <span style="font-size: 11px; font-weight: 600; color: #64748b; background: #e2e8f0; padding: 2px 8px; border-radius: 6px;">
                                    Salida Estática
                                </span>
                            </div>
                            <p style="margin: 0 0 10px 0; font-size: 12px; color: #64748b; line-height: 1.4;">
                                Define la dirección web oficial de tu sitio estático (para sitemap.xml, robots.txt, IA /llms.txt y SEO). Si lo dejas vacío, se usará automáticamente la URL actual de este WordPress.
                            </p>
                            <div style="display: flex; gap: 8px; align-items: center;">
                                <input type="url" id="wpsa_export_target_domain" class="regular-text" style="flex: 1; height: 38px; border-radius: 8px; border: 1.5px solid #cbd5e1; padding: 0 12px; font-size: 13.5px;" placeholder="<?php echo esc_attr( untrailingslashit( home_url() ) ); ?>" value="<?php echo esc_attr( ! empty( $custom_domain ) ? $custom_domain : ( ! empty( $production_url ) ? $production_url : '' ) ); ?>">
                                <button type="button" class="button" id="btn-save-inline-domain" style="height: 38px; border-radius: 8px; padding: 0 14px; font-size: 12.5px; font-weight: 600; color: #334155; white-space: nowrap;">
                                    <span class="dashicons dashicons-saved" style="vertical-align: -3px;"></span> Guardar
                                </button>
                            </div>
                        </div>

                        <div class="wpsa-export-action-box">
                            <button type="button" id="btn-start-export" class="wpsa-hero-export-btn">
                                <span class="wpsa-btn-icon dashicons dashicons-cloud-upload"></span>
                                <span class="wpsa-btn-label">
                                    <strong>Iniciar Exportación Estática Completa (.ZIP)</strong>
                                    <small>Generar archivo portátil listo para descargar o publicar en Cloudflare / Netlify</small>
                                </span>
                                <span class="wpsa-spinner"></span>
                            </button>
                            <div class="wpsa-export-reassurance">
                                <span class="dashicons dashicons-shield-alt" style="color: #10b981; font-size: 16px; width: 16px; height: 16px;"></span>
                                <span>100% Seguro: No modifica tu base de datos ni tus artículos originales. Crea una copia estática pura ultra-rápida.</span>
                            </div>
                        </div>

                        <!-- Barra de Progreso Mejorada -->
                        <div id="wpsa-progress-container" class="wpsa-progress-wrapper" style="display:none;">
                            <div class="wpsa-progress-header">
                                <div class="wpsa-progress-status-box">
                                    <span id="wpsa-progress-spinner" class="wpsa-spinner" style="display:inline-block; vertical-align:middle; width:16px; height:16px; border:2px solid #93c5fd; border-top-color:#2563eb; flex-shrink: 0;"></span>
                                    <span id="wpsa-progress-icon" class="dashicons dashicons-yes-alt" style="display:none; color:#10b981; font-size: 19px; width: 19px; height: 19px; vertical-align: middle; flex-shrink: 0;"></span>
                                    <span id="wpsa-progress-status">Preparando sesión de rastreo...</span>
                                </div>
                                <span id="wpsa-progress-percent">0%</span>
                            </div>
                            <div class="wpsa-progress-bar">
                                <div id="wpsa-progress-fill" class="wpsa-progress-fill"></div>
                            </div>
                            <div id="wpsa-progress-detail" style="margin-top: 8px; font-size: 12px; color: #64748b; display: flex; align-items: center; justify-content: space-between;">
                                <span id="wpsa-progress-stage">Fase: Inicializando</span>
                                <span id="wpsa-progress-pages-count"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tarjeta de Última Exportación -->
                <div class="wpsa-card">
                    <div class="wpsa-card-header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
                        <h2 style="margin: 0;">Último Paquete Generado</h2>
                        <?php if ( $last_export && ! empty( $last_export['file_url'] ) ) : ?>
                            <button type="button" class="wpsa-btn-trash-header btn-delete-export-action" title="Eliminar y descartar este archivo .ZIP del servidor">
                                <span class="dashicons dashicons-trash"></span> Descartar Paquete
                            </button>
                        <?php endif; ?>
                    </div>
                    <div class="wpsa-card-body" id="wpsa-last-export-box">
                        <?php if ( $last_export && ! empty( $last_export['file_url'] ) ) : ?>
                            <div class="wpsa-export-details" style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 16px; margin-bottom: 16px;">
                                <div class="wpsa-file-icon" style="background: #eff6ff; color: #2563eb; width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 24px;">
                                    <span class="dashicons dashicons-media-archive"></span>
                                </div>
                                <div class="wpsa-file-meta">
                                    <h4 class="wpsa-file-name" style="margin: 0 0 6px 0; font-size: 15px; font-weight: 700; color: #1e293b;"><?php echo esc_html( $last_export['file_name'] ); ?></h4>
                                    <p class="wpsa-file-sub" style="margin: 0 0 6px 0; font-size: 13px; color: #64748b;">
                                        <span><strong>Tamaño:</strong> <?php echo esc_html( $last_export['file_size'] ); ?></span> &bull;
                                        <span><strong>Archivos:</strong> <?php echo esc_html( $last_export['files_count'] ); ?></span> &bull;
                                        <span><strong>Fecha:</strong> <?php echo esc_html( $last_export['created_at'] ); ?></span>
                                    </p>
                                    <p class="wpsa-hash-box" style="margin: 0;">
                                        <small style="color: #94a3b8;">SHA-256: <code><?php echo esc_html( substr( $last_export['sha256'], 0, 32 ) . '...' ); ?></code></small>
                                    </p>
                                </div>
                            </div>
                            <div class="wpsa-export-btn-group" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                                <a href="<?php echo esc_url( $last_export['file_url'] ); ?>" class="wpsa-download-hero-btn" download>
                                    <span class="dashicons dashicons-download"></span> Descargar Paquete .ZIP
                                </a>
                                <button type="button" id="btn-deploy-netlify" class="button button-secondary button-large wpsa-deploy-btn" data-provider="<?php echo esc_attr( $hosting_provider ); ?>" style="padding: 10px 16px; font-weight: 600;">
                                    <span class="dashicons dashicons-cloud-upload"></span>
                                    <span class="btn-text">Desplegar a <?php echo esc_html( ucfirst( $hosting_provider ) ); ?> Ahora</span>
                                    <span class="wpsa-spinner"></span>
                                </button>
                                <button type="button" class="button button-link-delete btn-delete-export-action" style="color: #dc2626; display: inline-flex; align-items: center; gap: 6px; font-weight: 600; text-decoration: none; padding: 10px 16px; border-radius: 8px; border: 1px solid #fecaca; background: #fff5f5; font-size: 13px; cursor: pointer; transition: all 0.2s ease;">
                                    <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px;"></span>
                                    <span>Eliminar Paquete</span>
                                    <span class="wpsa-spinner" style="display:none;"></span>
                                </button>
                            </div>
                            <div id="wpsa-deploy-feedback" class="wpsa-feedback-msg" style="margin-top: 12px;"></div>

                            <!-- Caja de Ayuda Rápida para Cloudflare Pages -->
                            <div class="wpsa-cf-quickstart" style="margin-top: 16px; padding: 14px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; font-size: 12.5px; color: #166534;">
                                <strong style="display: flex; align-items: center; gap: 6px; font-size: 13px; color: #14532d; margin-bottom: 6px;">
                                    <span class="dashicons dashicons-yes-alt" style="color: #16a34a;"></span>
                                    ¿Cómo publicar tu ZIP en Cloudflare Pages en 30 segundos (Gratis)?
                                </strong>
                                <ol style="margin: 4px 0 0 18px; padding: 0; line-height: 1.6;">
                                    <li>Descarga tu archivo <strong>.ZIP</strong> con el botón verde superior.</li>
                                    <li>Entra en <a href="https://dash.cloudflare.com/" target="_blank" rel="noopener noreferrer" style="color: #15803d; text-decoration: underline; font-weight: bold;">Cloudflare Dashboard</a> &rarr; <strong>Workers & Pages</strong> &rarr; <strong>Create application</strong> &rarr; <strong>Pages</strong>.</li>
                                    <li>Selecciona <strong>"Upload assets"</strong>, arrastra tu archivo .ZIP (o su carpeta extraída) y haz clic en <strong>Deploy</strong>. ¡Tu sitio estará activo con SSL y CDN mundial instantáneamente!</li>
                                </ol>
                            </div>

                            <?php if ( $last_deploy && ! empty( $last_deploy['ssl_url'] ) ) : ?>
                                <div class="wpsa-last-deploy-badge" style="margin-top: 14px; padding: 12px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px;">
                                    <div style="display: flex; align-items: center; justify-content: space-between;">
                                        <span style="color: #065f46; font-weight: 600; font-size: 13px;">
                                            <span class="dashicons dashicons-yes-alt" style="color: #10b981;"></span> Último Despliegue en Vivo:
                                        </span>
                                        <a href="<?php echo esc_url( $last_deploy['ssl_url'] ); ?>" target="_blank" rel="noopener noreferrer" class="button button-small button-link" style="color: #047857; text-decoration: underline; font-weight: bold;">
                                            Visitar Sitio en <?php echo esc_html( ucfirst( ! empty( $last_deploy['provider'] ) ? $last_deploy['provider'] : $hosting_provider ) ); ?> &rarr;
                                        </a>
                                    </div>
                                    <small style="color: #047857; display: block; margin-top: 4px;">
                                        Estado: <strong><?php echo esc_html( strtoupper( $last_deploy['state'] ) ); ?></strong> &bull; Fecha: <?php echo esc_html( $last_deploy['deployed_at'] ); ?>
                                    </small>
                                </div>
                            <?php endif; ?>
                        <?php else : ?>
                            <div class="wpsa-empty-box" style="text-align: center; padding: 30px 20px; background: #f8fafc; border: 2px dashed #cbd5e1; border-radius: 12px;">
                                <span class="dashicons dashicons-cloud-upload" style="font-size: 40px; width: 40px; height: 40px; color: #94a3b8; margin-bottom: 10px;"></span>
                                <h4 style="margin: 0 0 6px 0; font-size: 15px; color: #334155;">Aún no has generado tu primer paquete estático</h4>
                                <p style="margin: 0; font-size: 13px; color: #64748b; max-width: 380px; margin: 0 auto;">
                                    Haz clic en el botón azul <strong>"Iniciar Exportación Estática Completa"</strong> para compilar tus 120 artículos y páginas en un archivo .ZIP descargable.
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ======================================================== -->
                <!-- Tarjeta: Recomendador Inteligente de Hosting Serverless -->
                <!-- ======================================================== -->
                <div class="wpsa-card wpsa-analyzer-card" style="grid-column: 1 / -1; margin-top: 14px; background: linear-gradient(135deg, #f8fafc 0%, #eff6ff 100%); border: 1px solid #bfdbfe; border-radius: 10px;">
                    <div class="wpsa-card-header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; border-bottom: 1px solid #dbeafe; padding-bottom: 12px;">
                        <div>
                            <h2 style="color: #1e3a8a; display: flex; align-items: center; gap: 8px; font-size: 17px; margin: 0 0 4px 0;">
                                <span class="dashicons dashicons-superhero" style="color: #2563eb; font-size: 22px;"></span>
                                Recomendador Inteligente de Hosting Serverless
                            </h2>
                            <p style="color: #475569; margin: 0; font-size: 13px;">
                                Analiza automáticamente el código, volumen de entradas, peso de medios y formularios para recomendar la plataforma gratuita serverless más óptima.
                            </p>
                        </div>
                        <button type="button" id="btn-reanalyze-site" class="button button-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                            <span class="dashicons dashicons-update"></span>
                            <span class="btn-text">Volver a Analizar Sitio</span>
                            <span class="wpsa-spinner"></span>
                        </button>
                    </div>

                    <div class="wpsa-card-body" style="padding-top: 16px;">
                        <!-- Chips de Diagnóstico del Sitio -->
                        <div class="wpsa-analyzer-stats" style="display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 18px;">
                            <span class="wpsa-stat-chip" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 20px; padding: 5px 12px; font-size: 12.5px; font-weight: 600; color: #1e293b; display: inline-flex; align-items: center; gap: 6px;">
                                📄 <strong><?php echo esc_html( $site_stats['total_content'] ); ?></strong> Páginas &amp; Entradas
                            </span>
                            <span class="wpsa-stat-chip" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 20px; padding: 5px 12px; font-size: 12.5px; font-weight: 600; color: #1e293b; display: inline-flex; align-items: center; gap: 6px;">
                                🖼️ <strong><?php echo esc_html( $site_stats['uploads_formatted'] ); ?></strong> en Medios (Uploads)
                            </span>
                            <span class="wpsa-stat-chip" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 20px; padding: 5px 12px; font-size: 12.5px; font-weight: 600; color: #1e293b; display: inline-flex; align-items: center; gap: 6px;">
                                ✉️ <?php echo $site_stats['has_forms'] ? '<strong>Formularios Detectados:</strong> ' . esc_html( implode( ', ', $site_stats['form_plugins'] ? $site_stats['form_plugins'] : array( 'HTML nativo' ) ) ) : 'Sin formularios detectados'; ?>
                            </span>
                            <span class="wpsa-stat-chip" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 20px; padding: 5px 12px; font-size: 12.5px; font-weight: 600; color: #1e293b; display: inline-flex; align-items: center; gap: 6px;">
                                💬 <?php echo $site_stats['comments_open'] ? 'Comentarios Activos (Supabase RLS)' : 'Comentarios Desactivados'; ?>
                            </span>
                        </div>

                        <!-- ======================================================== -->
                        <!-- TOP 3 COMBOS: HOSTING GRATUITO + EMAIL / LEADS          -->
                        <!-- ======================================================== -->
                        <div class="wpsa-combos-header" style="margin-bottom: 12px;">
                            <h3 style="margin: 0; font-size: 16px; color: #1e3a8a; display: flex; align-items: center; gap: 8px;">
                                <span class="dashicons dashicons-star-filled" style="color: #f59e0b;"></span>
                                Top 3 Combinaciones Recomendadas (Hosting Gratuito + Servicio de Email/Leads)
                            </h3>
                            <p style="margin: 2px 0 0 0; font-size: 12.5px; color: #64748b;">
                                Selecciona cualquiera de las 3 mejores opciones para aplicar automáticamente el destino de hosting y el manejador de formularios en 1 solo clic.
                            </p>
                        </div>

                        <div class="wpsa-combos-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(310px, 1fr)); gap: 14px; margin-bottom: 20px;">
                            <?php foreach ( $top_combos as $combo ) : 
                                $is_active_combo = ( $hosting_provider === $combo['hosting'] && $form_provider === $combo['form_provider'] );
                            ?>
                                <div class="wpsa-combo-card" style="background: #ffffff; border: 2px solid <?php echo $combo['is_top'] ? '#3b82f6' : '#e2e8f0'; ?>; border-radius: 10px; padding: 16px; position: relative; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 2px 5px rgba(0,0,0,0.04);">
                                    <?php if ( $combo['is_top'] ) : ?>
                                        <span style="position: absolute; top: -11px; left: 16px; background: #2563eb; color: #ffffff; font-size: 11px; font-weight: 800; padding: 2px 10px; border-radius: 12px; text-transform: uppercase; letter-spacing: 0.5px;">
                                            RECOMENDACIÓN #1
                                        </span>
                                    <?php endif; ?>
                                    <div>
                                        <div style="display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; margin-top: <?php echo $combo['is_top'] ? '4px' : '0'; ?>; margin-bottom: 8px;">
                                            <h4 style="margin: 0; font-size: 16px; color: #0f172a; font-weight: 700; line-height: 1.3;">
                                                <?php echo esc_html( $combo['title'] ); ?>
                                            </h4>
                                            <span style="background: #ecfdf5; color: #047857; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 6px; white-space: nowrap;">
                                                OPCIÓN <?php echo esc_html( $combo['rank'] ); ?>
                                            </span>
                                        </div>

                                        <p style="margin: 0 0 10px 0; font-size: 12.5px; color: #475569; line-height: 1.45;">
                                            <?php echo wp_kses_post( $combo['description'] ); ?>
                                        </p>

                                        <?php if ( ! empty( $combo['criteria'] ) ) : ?>
                                            <div class="wpsa-combo-criteria" style="margin: 10px 0 14px 0; padding: 10px 12px; background: #f8fafc; border-left: 3px solid <?php echo $combo['is_top'] ? '#2563eb' : '#94a3b8'; ?>; border-radius: 4px;">
                                                <span style="display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; color: #475569; margin-bottom: 5px; letter-spacing: 0.4px;">
                                                    <span class="dashicons dashicons-info-outline" style="font-size: 14px; width: 14px; height: 14px; vertical-align: -2px;"></span> ¿Por qué se seleccionó para tu sitio?
                                                </span>
                                                <div style="font-size: 11.5px; color: #334155; margin-bottom: 4px; line-height: 1.4;">
                                                    <strong style="color: #1e293b;">Hosting:</strong> <?php echo esc_html( $combo['criteria']['hosting'] ); ?>
                                                </div>
                                                <div style="font-size: 11.5px; color: #334155; line-height: 1.4;">
                                                    <strong style="color: #1e293b;">Leads / Email:</strong> <?php echo esc_html( $combo['criteria']['leads'] ); ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <ul style="margin: 0 0 14px 16px; font-size: 12px; color: #334155; line-height: 1.4; list-style-type: disc;">
                                            <?php foreach ( $combo['highlights'] as $hl ) : ?>
                                                <li><?php echo esc_html( $hl ); ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>

                                    <button type="button" class="button <?php echo $combo['is_top'] ? 'button-primary' : 'button-secondary'; ?> btn-apply-combo" data-hosting="<?php echo esc_attr( $combo['hosting'] ); ?>" data-form="<?php echo esc_attr( $combo['form_provider'] ); ?>" style="width: 100%; justify-content: center; display: inline-flex; align-items: center; gap: 6px; font-weight: 600; <?php echo $is_active_combo ? 'opacity: 0.7; pointer-events: none;' : ''; ?>">
                                        <span class="dashicons dashicons-saved"></span>
                                        <span><?php echo $is_active_combo ? 'Combo Activo en tu Sitio' : 'Aplicar Opción #' . esc_html( $combo['rank'] ) . ' en 1 Clic'; ?></span>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- ======================================================== -->
                        <!-- MIX & MATCH: COMBINADOR LIBRE CON MATRIZ DE COMPATIBILIDAD -->
                        <!-- ======================================================== -->
                        <div class="wpsa-mix-match-card" style="margin-bottom: 22px; padding: 18px; background: #ffffff; border: 2px dashed #93c5fd; border-radius: 10px; box-shadow: 0 1px 4px rgba(0,0,0,0.03);">
                            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-bottom: 14px;">
                                <div>
                                    <h4 style="margin: 0; font-size: 15.5px; color: #1e3a8a; display: flex; align-items: center; gap: 8px;">
                                        <span class="dashicons dashicons-forms" style="color: #2563eb;"></span>
                                        Combinador Libre "Mix &amp; Match" (Hosting vs. Formularios)
                                    </h4>
                                    <p style="margin: 3px 0 0 0; font-size: 12.5px; color: #64748b;">
                                        ¿Prefieres armar tu propia combinación? Elige libremente cualquier hosting y servicio de email/leads. La matriz validará en tiempo real la compatibilidad técnica bidireccional.
                                    </p>
                                </div>
                                <span id="mixmatch-compat-badge" class="wpsa-badge" style="background: #ecfdf5; color: #047857; font-weight: 700; font-size: 12px; padding: 4px 10px; border-radius: 12px;">
                                    ✓ Combinación Compatible
                                </span>
                            </div>

                            <div style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 14px; align-items: flex-end;">
                                <div class="wpsa-input-group" style="margin: 0;">
                                    <label for="mixmatch_hosting" style="font-weight: 600; font-size: 13px; color: #1e293b;">1. Selecciona Hosting Gratuito:</label>
                                    <select id="mixmatch_hosting" style="width: 100%; margin-top: 4px; font-size: 13px;">
                                        <option value="cloudflare" <?php selected( $hosting_provider, 'cloudflare' ); ?>>Cloudflare Pages (Tráfico Ilimitado)</option>
                                        <option value="github" <?php selected( $hosting_provider, 'github' ); ?>>GitHub Pages &amp; Actions (Git + Cron)</option>
                                        <option value="render" <?php selected( $hosting_provider, 'render' ); ?>>Render (Deploy Hook)</option>
                                        <option value="netlify" <?php selected( $hosting_provider, 'netlify' ); ?>>Netlify (1-Click ZIP Deploy)</option>
                                    </select>
                                </div>

                                <div class="wpsa-input-group" style="margin: 0;">
                                    <label for="mixmatch_form" style="font-weight: 600; font-size: 13px; color: #1e293b;">2. Selecciona Servicio de Leads / Email:</label>
                                    <select id="mixmatch_form" style="width: 100%; margin-top: 4px; font-size: 13px;">
                                        <option value="google_sheets" <?php selected( $form_provider, 'google_sheets' ); ?>>Google Sheets / Excel CSV (Base de Datos en Drive)</option>
                                        <option value="web3forms" <?php selected( $form_provider, 'web3forms' ); ?>>Web3Forms (Inbox API sin servidor)</option>
                                        <option value="formsubmit" <?php selected( $form_provider, 'formsubmit' ); ?>>FormSubmit (Directo a tu correo)</option>
                                        <option value="netlify" <?php selected( $form_provider, 'netlify' ); ?>>Netlify Forms (Solo válido en Netlify)</option>
                                    </select>
                                </div>

                                <div>
                                    <button type="button" id="btn-apply-mixmatch" class="button button-primary" style="height: 38px; display: inline-flex; align-items: center; gap: 6px; font-weight: 600;">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <span class="btn-text">Aplicar Combinación</span>
                                        <span class="wpsa-spinner"></span>
                                    </button>
                                </div>
                            </div>

                            <div id="mixmatch-compat-notice" style="display: none; margin-top: 12px; padding: 10px 14px; border-radius: 6px; font-size: 12.5px; line-height: 1.4;"></div>
                        </div>

                        <!-- ======================================================== -->
                        <!-- GUÍA DESPLEGABLE: ALTERNATIVAS DE EMAIL Y FORMULARIOS    -->
                        <!-- ======================================================== -->
                        <div class="wpsa-email-alternatives-guide" style="margin-bottom: 22px; padding: 18px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.03);">
                            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-bottom: 12px;">
                                <div>
                                    <h4 style="margin: 0; font-size: 15.5px; color: #0f172a; display: flex; align-items: center; gap: 8px;">
                                        <span class="dashicons dashicons-email-alt" style="color: #0284c7;"></span>
                                        Guía de Alternativas para Email y Formularios según el Hosting
                                    </h4>
                                    <p style="margin: 3px 0 0 0; font-size: 12.5px; color: #64748b;">
                                        No estás atado a una sola opción. Despliega cada hosting para conocer las mejores alternativas nativas y externas para recibir correos y gestionar formularios sin pagar servidores.
                                    </p>
                                </div>
                                <span class="wpsa-badge" style="background: #e0f2fe; color: #0369a1; font-weight: 700; font-size: 11.5px; padding: 4px 10px; border-radius: 12px;">
                                    Alternativas Flexibles
                                </span>
                            </div>

                            <div class="wpsa-accordion-container" style="display: flex; flex-direction: column; gap: 10px;">
                                <!-- 1. CLOUDFLARE PAGES -->
                                <details class="wpsa-details-card" style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px 16px;" open>
                                    <summary style="font-weight: 700; font-size: 13.5px; color: #1e293b; cursor: pointer; display: flex; align-items: center; justify-content: space-between;">
                                        <span style="display: inline-flex; align-items: center; gap: 8px;">
                                            <span class="dashicons dashicons-cloud" style="color: #f97316;"></span>
                                            1. Cloudflare Pages (Tráfico Ilimitado) — Alternativas de Correo y Formularios
                                        </span>
                                        <span style="font-size: 11.5px; color: #2563eb; font-weight: 600;">(Recomendado) Desplegar ▼</span>
                                    </summary>
                                    <div style="margin-top: 12px; font-size: 12.5px; color: #334155; line-height: 1.5;">
                                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; margin-bottom: 10px;">
                                            <div style="background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #f97316; border-radius: 6px; padding: 12px;">
                                                <strong style="color: #c2410c; display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                                                    <span class="dashicons dashicons-email"></span> Opción A: Cloudflare Email Routing (Reenvío Nativo Gratis)
                                                </strong>
                                                <p style="margin: 0 0 6px 0;">
                                                    Cloudflare incluye <strong>Email Routing 100% gratuito</strong>. Te permite crear correos como <code>contacto@tudominio.com</code> o <code>info@tudominio.com</code> que se reenvían al instante a tu Gmail o correo personal, <em>sin pagar Google Workspace ni servidores SMTP</em>.
                                                </p>
                                                <small style="color: #64748b; display: block; background: #f1f5f9; padding: 6px; border-radius: 4px;">
                                                    <strong>¿Cómo activarlo?</strong> En tu panel de Cloudflare &gt; pestaña <strong>Email Routing</strong> &gt; Activar (configura registros DNS MX en 1 clic). Luego, en WP Static Architect pon ese correo en FormSubmit y recibirás los contactos en tu Gmail personal.
                                                </small>
                                            </div>

                                            <div style="background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #10b981; border-radius: 6px; padding: 12px;">
                                                <strong style="color: #047857; display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                                                    <span class="dashicons dashicons-spreadsheet"></span> Opción B: Google Sheets / Excel CSV (Base de Datos)
                                                </strong>
                                                <p style="margin: 0 0 6px 0;">
                                                    Si además de avisos deseas que todos los datos de los visitantes queden registrados en una tabla de Google Drive con descarga en .XLSX/.CSV para análisis o campañas de email marketing.
                                                </p>
                                                <small style="color: #64748b; display: block; background: #f1f5f9; padding: 6px; border-radius: 4px;">
                                                    <strong>Configuración:</strong> Selecciona Google Sheets en el manejador y pega la URL de tu Web App de Google Apps Script.
                                                </small>
                                            </div>

                                            <div style="background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #6366f1; border-radius: 6px; padding: 12px;">
                                                <strong style="color: #4338ca; display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                                                    <span class="dashicons dashicons-rest-api"></span> Opción C: Web3Forms (Inbox API Sin Servidor)
                                                </strong>
                                                <p style="margin: 0 0 6px 0;">
                                                    Servicio serverless que entrega los mensajes directo a tu bandeja sin exponer tu email real en el código HTML de la web estática.
                                                </p>
                                                <small style="color: #64748b; display: block; background: #f1f5f9; padding: 6px; border-radius: 4px;">
                                                    <strong>Configuración:</strong> Regístrate gratis en web3forms.com y copia tu Access Key en la configuración de formularios.
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </details>

                                <!-- 2. GITHUB PAGES -->
                                <details class="wpsa-details-card" style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px 16px;">
                                    <summary style="font-weight: 700; font-size: 13.5px; color: #1e293b; cursor: pointer; display: flex; align-items: center; justify-content: space-between;">
                                        <span style="display: inline-flex; align-items: center; gap: 8px;">
                                            <span class="dashicons dashicons-networking" style="color: #1e293b;"></span>
                                            2. GitHub Pages &amp; Actions — Alternativas de Correo y Formularios
                                        </span>
                                        <span style="font-size: 11.5px; color: #64748b; font-weight: 600;">Desplegar ▼</span>
                                    </summary>
                                    <div style="margin-top: 12px; font-size: 12.5px; color: #334155; line-height: 1.5;">
                                        <p style="margin: 0 0 8px 0;">
                                            Como GitHub Pages solo sirve archivos estáticos HTML/CSS/JS puros, las mejores opciones para correo son:
                                        </p>
                                        <ul style="margin: 0 0 0 18px; line-height: 1.6;">
                                            <li><strong>FormSubmit:</strong> Envía los formularios directamente a tu dirección de correo electrónico sin registrar cuentas ni configurar llaves.</li>
                                            <li><strong>Web3Forms:</strong> Envío rápido a tu bandeja de correo mediante clave de API sin exponer tu dirección pública en el código.</li>
                                            <li><strong>Google Sheets:</strong> Captura y almacenamiento en hoja de cálculo en tu Google Drive.</li>
                                        </ul>
                                    </div>
                                </details>

                                <!-- 3. NETLIFY -->
                                <details class="wpsa-details-card" style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px 16px;">
                                    <summary style="font-weight: 700; font-size: 13.5px; color: #1e293b; cursor: pointer; display: flex; align-items: center; justify-content: space-between;">
                                        <span style="display: inline-flex; align-items: center; gap: 8px;">
                                            <span class="dashicons dashicons-admin-generic" style="color: #06b6d4;"></span>
                                            3. Netlify — Alternativas de Correo y Formularios
                                        </span>
                                        <span style="font-size: 11.5px; color: #64748b; font-weight: 600;">Desplegar ▼</span>
                                    </summary>
                                    <div style="margin-top: 12px; font-size: 12.5px; color: #334155; line-height: 1.5;">
                                        <ul style="margin: 0 0 0 18px; line-height: 1.6;">
                                            <li><strong>Netlify Forms Nativos:</strong> Automático. WP Static Architect inyecta <code>data-netlify="true"</code> y Honeypot anti-spam. Los contactos se ven en tu panel de Netlify y puedes activar notificaciones por correo en el panel de Netlify.</li>
                                            <li><strong>FormSubmit / Web3Forms / Google Sheets:</strong> También compatibles si prefieres no depender de la bandeja de Netlify.</li>
                                        </ul>
                                    </div>
                                </details>
                            </div>
                        </div>

                        <!-- Sección: Análisis Editorial Inteligente con Google AI Studio (Gemini) -->
                        <div class="wpsa-gemini-card" style="margin-bottom: 20px; padding: 16px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; box-shadow: 0 1px 3px rgba(0,0,0,0.03);">
                            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-bottom: 8px;">
                                <div>
                                    <h4 style="margin: 0; font-size: 15px; color: #1e3a8a; display: flex; align-items: center; gap: 6px;">
                                        <span class="dashicons dashicons-admin-generic" style="color: #6366f1;"></span>
                                        Análisis Editorial &amp; Semántico con Google AI Studio (Gemini IA)
                                    </h4>
                                    <p style="margin: 2px 0 0 0; font-size: 12px; color: #64748b;">
                                        Examina tus categorías, títulos y densidad de contenido con Gemini 1.5/2.0 Flash para obtener recomendaciones de nicho, cadencia editorial y lead magnets.
                                    </p>
                                </div>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <input type="password" id="gemini_api_key_input" value="<?php echo esc_attr( get_option( 'wp_static_arquitect_gemini_api_key', '' ) ); ?>" placeholder="Pega tu API Key de Gemini..." style="width: 240px; font-size: 12px;" />
                                    <button type="button" id="btn-analyze-gemini" class="button button-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                                        <span class="dashicons dashicons-superhero"></span>
                                        <span class="btn-text">Analizar con Gemini IA</span>
                                        <span class="wpsa-spinner"></span>
                                    </button>
                                </div>
                            </div>
                            <div id="gemini-analysis-feedback" style="display: none; margin-top: 10px; font-size: 12px;"></div>
                            <div id="gemini-analysis-results" style="display: none; margin-top: 14px; padding: 14px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px;"></div>
                        </div>

                        <!-- Rejilla Comparativa de Todos los Proveedores -->
                        <div class="wpsa-providers-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px;">
                            <?php foreach ( $recommendations as $rec ) : 
                                $is_active = ( $hosting_provider === $rec['provider'] );
                            ?>
                                <div class="wpsa-provider-card" style="background: #ffffff; border: 1px solid <?php echo $is_active ? '#3b82f6' : '#e2e8f0'; ?>; border-radius: 8px; padding: 14px; position: relative;">
                                    <?php if ( $is_active ) : ?>
                                        <span style="position: absolute; top: 10px; right: 10px; font-size: 11px; background: #dbeafe; color: #1d4ed8; font-weight: 700; padding: 2px 7px; border-radius: 12px;">ACTIVO</span>
                                    <?php endif; ?>
                                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                                        <h4 style="margin: 0; font-size: 15px; color: #1e293b;"><?php echo esc_html( $rec['name'] ); ?></h4>
                                        <span style="font-weight: 700; font-size: 13px; color: <?php echo ( $rec['score'] >= 85 ) ? '#059669' : '#475569'; ?>;"><?php echo esc_html( $rec['score'] ); ?>%</span>
                                    </div>
                                    <p style="margin: 0 0 10px 0; font-size: 12px; color: #64748b; line-height: 1.4;">
                                        <?php echo esc_html( $rec['pros'][0] ); ?>
                                    </p>
                                    <button type="button" class="button button-small btn-apply-provider" data-provider="<?php echo esc_attr( $rec['provider'] ); ?>" style="width: 100%; text-align: center; justify-content: center; <?php echo $is_active ? 'opacity: 0.6; pointer-events: none;' : ''; ?>">
                                        <?php echo $is_active ? 'Seleccionado' : 'Cambiar a este Hosting'; ?>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Diagnóstico de Salud del Servidor (Pre-Flight Check) -->
                <div class="wpsa-card wpsa-health-card" style="grid-column: 1 / -1; margin-top: 10px;">
                    <div class="wpsa-card-header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                        <div>
                            <h2><span class="dashicons dashicons-shield" style="color: #10b981;"></span> Diagnóstico del Entorno &amp; Salud del Servidor (Pre-Flight Check)</h2>
                            <p>Verificación automática de compatibilidad para garantizar que tu servidor local o de producción exporte sin bloqueos ni errores de memoria.</p>
                        </div>
                        <span class="wpsa-health-pill <?php echo $system_health['all_ok'] ? 'wpsa-health-pass' : 'wpsa-health-warn'; ?>" style="font-size: 13px; padding: 6px 14px;">
                            <span class="dashicons <?php echo $system_health['all_ok'] ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span>
                            <?php echo $system_health['all_ok'] ? 'Servidor 100% Preparado (' . esc_html( $system_health['passed'] . '/' . $system_health['total'] ) . ')' : 'Atención Requerida (' . esc_html( $system_health['passed'] . '/' . $system_health['total'] ) . ')'; ?>
                        </span>
                    </div>
                    <div class="wpsa-card-body">
                        <div class="wpsa-health-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 14px;">
                            <?php foreach ( $system_health['checks'] as $check ) : ?>
                                <div class="wpsa-health-item <?php echo $check['pass'] ? 'is-pass' : 'is-fail'; ?>" style="padding: 12px 14px; background: <?php echo $check['pass'] ? '#f8fafc' : '#fef2f2'; ?>; border: 1px solid <?php echo $check['pass'] ? '#e2e8f0' : '#fecaca'; ?>; border-radius: 8px; display: flex; gap: 12px; align-items: flex-start;">
                                    <div class="wpsa-health-icon" style="color: <?php echo $check['pass'] ? '#10b981' : '#ef4444'; ?>; font-size: 20px; margin-top: 1px;">
                                        <span class="dashicons <?php echo $check['pass'] ? 'dashicons-yes-alt' : 'dashicons-warning'; ?>"></span>
                                    </div>
                                    <div class="wpsa-health-info" style="flex: 1;">
                                        <div class="wpsa-health-title-row" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                                            <strong style="color: #1e293b; font-size: 13px;"><?php echo esc_html( $check['label'] ); ?></strong>
                                            <span class="wpsa-health-val" style="font-size: 11.5px; font-weight: 600; padding: 2px 7px; border-radius: 4px; background: <?php echo $check['pass'] ? '#ecfdf5' : '#fee2e2'; ?>; color: <?php echo $check['pass'] ? '#047857' : '#b91c1c'; ?>;"><?php echo esc_html( $check['value'] ); ?></span>
                                        </div>
                                        <p class="wpsa-health-msg" style="margin: 0; font-size: 12px; color: #64748b; line-height: 1.35;"><?php echo esc_html( $check['message'] ); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==================== TAB 2: CONFIGURACIÓN DE APIS ==================== -->
        <div id="tab-config" class="wpsa-tab-pane">
            <form method="post" action="options.php" class="wpsa-form-card" id="wpsa-main-settings-form">
                <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>

                <!-- Plataforma de Hosting, Dominio y Perfil de Servicio -->
                <div class="wpsa-card" style="margin-bottom: 1.5rem;">
                    <div class="wpsa-card-header">
                        <h2><span class="dashicons dashicons-networking" style="color: #4f46e5;"></span> Plataforma de Hosting, Dominio & Perfil de Servicio</h2>
                        <p>Selecciona tu destino de despliegue estático, gestiona tu dominio personalizado sin código y define el perfil de cuota de tu cuenta.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <div class="wpsa-grid-2col">
                            <div class="wpsa-input-group">
                                <label for="hosting_provider"><strong>Destino de Alojamiento Estático</strong></label>
                                <select id="hosting_provider" name="wp_static_arquitect_hosting_provider" style="width: 100%; max-width: 100%;">
                                    <option value="netlify" <?php selected( $hosting_provider, 'netlify' ); ?>>Netlify (Genera _redirects, _headers, soporte API)</option>
                                    <option value="cloudflare" <?php selected( $hosting_provider, 'cloudflare' ); ?>>Cloudflare Pages (Genera _routes.json y edge headers)</option>
                                    <option value="vercel" <?php selected( $hosting_provider, 'vercel' ); ?>>Vercel (Genera vercel.json con cleanUrls)</option>
                                    <option value="github" <?php selected( $hosting_provider, 'github' ); ?>>GitHub Pages (Genera .nojekyll y CNAME)</option>
                                    <option value="custom" <?php selected( $hosting_provider, 'custom' ); ?>>Servidor Apache / Nginx / Estático (Genera .htaccess)</option>
                                </select>
                                <small class="wpsa-help-text">El exportador adaptará y empaquetará los archivos de configuración requeridos para la plataforma seleccionada.</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="service_tier"><strong>Perfil de Servicio / Licencia</strong></label>
                                <select id="service_tier" name="wp_static_arquitect_service_tier" style="width: 100%; max-width: 100%;">
                                    <option value="creator_pro" <?php selected( ( 'creator_pro' === $service_tier || 'enterprise' === $service_tier || 'free' === $service_tier || empty( $service_tier ) ), true ); ?>>⭐ Modo Creador Pro / Ilimitado (Totalmente Desbloqueado: cuotas ilimitadas, retención total, sin purga obligatoria)</option>
                                    <option value="standard" <?php selected( $service_tier, 'standard' ); ?>>Estándar (Con purga preventiva semanal de formularios según umbrales)</option>
                                </select>
                                <small class="wpsa-help-text">En Modo Creador Pro, todas las capacidades operan al 100% de potencia sin ninguna restricción ni límites de cuota.</small>
                            </div>
                        </div>

                        <!-- Dominio Personalizado Sin Código -->
                        <div class="wpsa-domain-box" style="margin-top: 18px; padding: 16px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;">
                            <div class="wpsa-input-group">
                                <label for="custom_domain"><strong>Dominio Personalizado Sin Código (Zero-Code Custom Domain)</strong></label>
                                <div class="wpsa-custom-domain-row">
                                    <input type="text" id="custom_domain" name="wp_static_arquitect_custom_domain" value="<?php echo esc_attr( $custom_domain ); ?>" class="regular-text" placeholder="ej. miempresa.com o www.miempresa.com">
                                    <button type="button" id="btn-link-custom-domain" class="button button-secondary" style="display: flex; align-items: center; gap: 6px;">
                                        <span class="dashicons dashicons-admin-links"></span>
                                        <span class="btn-text">Vincular a Netlify en 1 Clic</span>
                                        <span class="wpsa-spinner"></span>
                                    </button>
                                </div>
                                <small class="wpsa-help-text">Configura tu dominio canónico. Genera automáticamente el archivo <code>CNAME</code>, reescribe <code>sitemap.xml</code>, <code>robots.txt</code>, OpenGraph y datos estructurados Schema.org sin tocar código.</small>
                                <div id="custom-domain-link-feedback" class="wpsa-feedback-msg" style="margin-top: 8px;"></div>
                            </div>

                            <!-- Tabla Visual de Asistencia DNS -->
                            <div class="wpsa-dns-helper" style="margin-top: 14px;">
                                <h4 style="margin: 0 0 8px 0; font-size: 13px; color: #334155; display: flex; align-items: center; gap: 6px;">
                                    <span class="dashicons dashicons-info-outline" style="color: #4f46e5;"></span> Guía Rápida de Configuración DNS en tu Registrador (GoDaddy, Namecheap, Cloudflare)
                                </h4>
                                <div class="wpsa-table-responsive">
                                    <table class="wpsa-dns-table" style="width: 100%; border-collapse: collapse; font-size: 12.5px; background: #ffffff; border-radius: 6px; overflow: hidden; border: 1px solid #e2e8f0;">
                                        <thead>
                                            <tr style="background: #f1f5f9; text-align: left; color: #475569;">
                                                <th style="padding: 8px 12px; border-bottom: 1px solid #e2e8f0;">Tipo</th>
                                                <th style="padding: 8px 12px; border-bottom: 1px solid #e2e8f0;">Host / Nombre</th>
                                                <th style="padding: 8px 12px; border-bottom: 1px solid #e2e8f0;">Valor de Destino</th>
                                                <th style="padding: 8px 12px; border-bottom: 1px solid #e2e8f0;">Propósito</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td style="padding: 8px 12px; border-bottom: 1px solid #f1f5f9;"><span class="wpsa-dns-badge">A</span></td>
                                                <td style="padding: 8px 12px; border-bottom: 1px solid #f1f5f9;"><code>@</code> (raíz apex)</td>
                                                <td style="padding: 8px 12px; border-bottom: 1px solid #f1f5f9;">
                                                    <div style="display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                                                        <code>75.2.60.5</code>
                                                        <button type="button" class="button button-small wpsa-inline-copy-btn" data-copy-text="75.2.60.5" title="Copiar dirección IP">
                                                            <span class="dashicons dashicons-clipboard"></span> <span>Copiar</span>
                                                        </button>
                                                        <span style="color: #64748b; font-size: 12px;">(Netlify) o IP de tu servidor</span>
                                                    </div>
                                                </td>
                                                <td style="padding: 8px 12px; border-bottom: 1px solid #f1f5f9; color: #64748b;">Enlaza tu dominio raíz principal</td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 8px 12px;"><span class="wpsa-dns-badge wpsa-dns-cname">CNAME</span></td>
                                                <td style="padding: 8px 12px;"><code>www</code></td>
                                                <td style="padding: 8px 12px;">
                                                    <div style="display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap;">
                                                        <code>tu-sitio.netlify.app</code>
                                                        <button type="button" class="button button-small wpsa-inline-copy-btn" data-copy-text="tu-sitio.netlify.app" title="Copiar destino CNAME">
                                                            <span class="dashicons dashicons-clipboard"></span> <span>Copiar</span>
                                                        </button>
                                                        <span style="color: #64748b; font-size: 12px;">/ <code>tu-sitio.pages.dev</code></span>
                                                    </div>
                                                </td>
                                                <td style="padding: 8px 12px; color: #64748b;">Apunta el subdominio www a tu proveedor CDN</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="wpsa-grid-2col">
                    <!-- Netlify Settings -->
                    <div class="wpsa-card">
                        <div class="wpsa-card-header">
                            <h2><span class="wpsa-logo-text">Netlify</span> Configuración de API</h2>
                            <p>Credenciales necesarias para consultar envíos y gestionar la purga automática.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group">
                                <label for="netlify_pat">Personal Access Token (PAT) <span class="required">*</span></label>
                                <input type="password" id="netlify_pat" name="wp_static_arquitect_netlify_pat" value="<?php echo esc_attr( $netlify_pat ); ?>" class="regular-text" placeholder="nfp_xxxxxxxxxxxxxxxxxxxx">
                                <small class="wpsa-help-text">Genera tu token en Netlify: <em>User Settings &gt; Applications &gt; Personal access tokens</em>.</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="netlify_site_id">Site API ID <span class="required">*</span></label>
                                <input type="text" id="netlify_site_id" name="wp_static_arquitect_netlify_site_id" value="<?php echo esc_attr( $netlify_site_id ); ?>" class="regular-text" placeholder="ej. 8a9b2c3d-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
                                <small class="wpsa-help-text">Encuentra tu Site ID en: <em>Site configuration &gt; General &gt; Site details</em>.</small>
                            </div>

                            <div class="wpsa-input-group" style="margin-top: 14px; padding: 10px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px;">
                                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_netlify_auto_deploy" value="1" <?php checked( $netlify_auto_deploy, '1' ); ?>>
                                    <span><strong>Despliegue Automático:</strong> Subir el sitio a Netlify automáticamente al finalizar cada exportación estática.</span>
                                </label>
                            </div>

                            <div class="wpsa-test-box">
                                <button type="button" id="btn-test-netlify" class="button button-secondary">
                                    <span class="dashicons dashicons-update"></span> Probar Conexión Netlify
                                </button>
                                <span id="netlify-test-result" class="wpsa-test-feedback"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Supabase Settings -->
                    <div class="wpsa-card">
                        <div class="wpsa-card-header">
                            <h2><span class="wpsa-logo-text">Supabase</span> Configuración de API</h2>
                            <p>Parámetros para la gestión y publicación de comentarios en tiempo real.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group">
                                <label for="supabase_url">Project URL <span class="required">*</span></label>
                                <input type="url" id="supabase_url" name="wp_static_arquitect_supabase_url" value="<?php echo esc_attr( $supabase_url ); ?>" class="regular-text" placeholder="https://xyzproject.supabase.co">
                                <small class="wpsa-help-text">Obtén la URL en: <em>Project Settings &gt; API &gt; Project URL</em>.</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="supabase_anon_key">Anon Public Key <span class="required">*</span></label>
                                <input type="password" id="supabase_anon_key" name="wp_static_arquitect_supabase_anon_key" value="<?php echo esc_attr( $supabase_anon_key ); ?>" class="regular-text" placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...">
                                <small class="wpsa-help-text">Clave pública segura inyectada en el frontend para PostgREST.</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="supabase_service_key">Management / Service Role Key <span class="optional">(opcional)</span></label>
                                <input type="password" id="supabase_service_key" name="wp_static_arquitect_supabase_service_key" value="<?php echo esc_attr( $supabase_service_k ); ?>" class="regular-text" placeholder="service_role secret token">
                                <small class="wpsa-help-text">Requerido únicamente si deseas ejecutar el bootstrap de la BD automáticamente sin copiar SQL.</small>
                            </div>

                            <div class="wpsa-test-box">
                                <button type="button" id="btn-test-supabase" class="button button-secondary">
                                    <span class="dashicons dashicons-update"></span> Probar Conexión Supabase
                                </button>
                                <span id="supabase-test-result" class="wpsa-test-feedback"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ======================================================== -->
                <!-- PANELES MULTI-HOSTING (Cloudflare Pages, GitHub, Render)  -->
                <!-- ======================================================== -->
                <div class="wpsa-grid-2col" style="margin-top: 1.5rem;">
                    <!-- Cloudflare Pages -->
                    <div class="wpsa-card" id="card-cloudflare-settings">
                        <div class="wpsa-card-header">
                            <h2><span class="dashicons dashicons-cloud" style="color: #f59e0b;"></span> Cloudflare Pages (Capacidad Ilimitada)</h2>
                            <p>Despliega en la red Anycast de Cloudflare con ancho de banda 100% ilimitado.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group">
                                <label for="cloudflare_deploy_hook"><strong>Deploy Hook URL</strong> (Recomendado)</label>
                                <input type="url" id="cloudflare_deploy_hook" name="wp_static_arquitect_cloudflare_deploy_hook" value="<?php echo esc_attr( $cloudflare_deploy_hook ); ?>" class="regular-text" placeholder="https://api.cloudflare.com/client/v4/pages/webhooks/deploy_hooks/xxxx">
                                <small class="wpsa-help-text">Configura tu Deploy Hook en Cloudflare: <em>Workers &amp; Pages &gt; Tu Proyecto &gt; Settings &gt; Builds &amp; deployments &gt; Deploy hooks</em>.</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="cloudflare_project_name">Nombre de Proyecto en Cloudflare</label>
                                <input type="text" id="cloudflare_project_name" name="wp_static_arquitect_cloudflare_project_name" value="<?php echo esc_attr( $cloudflare_project_name ); ?>" class="regular-text" placeholder="ej. mundos-simulados">
                                <small class="wpsa-help-text">El nombre de tu proyecto en Cloudflare Pages (ej. tu-proyecto.pages.dev).</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="cloudflare_account_id">Cloudflare Account ID (Opcional para Direct API)</label>
                                <input type="text" id="cloudflare_account_id" name="wp_static_arquitect_cloudflare_account_id" value="<?php echo esc_attr( $cloudflare_account_id ); ?>" class="regular-text" placeholder="Account ID de 32 caracteres">
                            </div>

                            <div class="wpsa-input-group">
                                <label for="cloudflare_api_token">Cloudflare API Token (Opcional para Direct API)</label>
                                <input type="password" id="cloudflare_api_token" name="wp_static_arquitect_cloudflare_api_token" value="<?php echo esc_attr( $cloudflare_api_token ); ?>" class="regular-text" placeholder="Token con permisos de Pages:Edit">
                            </div>
                        </div>
                    </div>

                    <!-- GitHub Pages & GitHub Actions -->
                    <div class="wpsa-card" id="card-github-settings">
                        <div class="wpsa-card-header">
                            <h2><span class="dashicons dashicons-networking" style="color: #334155;"></span> GitHub Pages &amp; Actions</h2>
                            <p>Dispara compilaciones y despliegues en repositorios GitHub mediante <code>workflow_dispatch</code>.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group">
                                <label for="github_token">GitHub Personal Access Token (PAT)</label>
                                <input type="password" id="github_token" name="wp_static_arquitect_github_token" value="<?php echo esc_attr( $github_token ); ?>" class="regular-text" placeholder="ghp_xxxxxxxxxxxxxxxxxxxx">
                                <small class="wpsa-help-text">Token con permisos <code>repo</code> o <code>workflow</code> para disparar acciones.</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="github_repo">Repositorio (usuario/repositorio)</label>
                                <input type="text" id="github_repo" name="wp_static_arquitect_github_repo" value="<?php echo esc_attr( $github_repo ); ?>" class="regular-text" placeholder="ej. juanxaviercasa/mundos-simulados">
                            </div>

                            <div class="wpsa-grid-2col">
                                <div class="wpsa-input-group">
                                    <label for="github_branch">Rama (Branch)</label>
                                    <input type="text" id="github_branch" name="wp_static_arquitect_github_branch" value="<?php echo esc_attr( $github_branch ); ?>" class="regular-text" placeholder="main">
                                </div>
                                <div class="wpsa-input-group">
                                    <label for="github_workflow">Archivo Workflow</label>
                                    <input type="text" id="github_workflow" name="wp_static_arquitect_github_workflow" value="<?php echo esc_attr( $github_workflow ); ?>" class="regular-text" placeholder="deploy.yml">
                                </div>
                            </div>

                            <div style="margin-top: 14px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
                                <button type="button" id="btn-test-github-dispatch" class="button button-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                                    <span class="dashicons dashicons-controls-play"></span>
                                    <span class="btn-text">Probar Disparo de GitHub Actions (workflow_dispatch)</span>
                                    <span class="wpsa-spinner"></span>
                                </button>
                            </div>
                            <div id="github-dispatch-feedback" class="wpsa-feedback-msg" style="margin-top: 8px;"></div>

                            <details style="margin-top: 12px; font-size: 12px; color: #475569;">
                                <summary style="cursor: pointer; font-weight: 600; color: #1e293b;">
                                    Ver flujo automático generado: <code>.github/workflows/deploy.yml</code> (Cron + Dispatch)
                                </summary>
                                <div style="margin-top: 8px; position: relative;">
                                    <pre style="background: #0f172a; color: #f8fafc; padding: 12px; border-radius: 6px; font-size: 11px; overflow-x: auto;"><code>name: Deploy Static Site to GitHub Pages
on:
  workflow_dispatch:
  schedule:
    - cron: '0 3 * * *' # Ejecución diaria automática a las 03:00 UTC (Drip-Feed)
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: "pages"
  cancel-in-progress: false
jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Pages
        uses: actions/configure-pages@v4
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: '.'
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4</code></pre>
                                    <button type="button" class="button button-small wpsa-inline-copy-btn" data-copy-text="name: Deploy Static Site to GitHub Pages&#10;on:&#10;  workflow_dispatch:&#10;  schedule:&#10;    - cron: '0 3 * * *'&#10;permissions:&#10;  contents: read&#10;  pages: write&#10;  id-token: write&#10;concurrency:&#10;  group: &quot;pages&quot;&#10;  cancel-in-progress: false&#10;jobs:&#10;  deploy:&#10;    environment:&#10;      name: github-pages&#10;      url: ${{ steps.deployment.outputs.page_url }}&#10;    runs-on: ubuntu-latest&#10;    steps:&#10;      - name: Checkout&#10;        uses: actions/checkout@v4&#10;      - name: Setup Pages&#10;        uses: actions/configure-pages@v4&#10;      - name: Upload artifact&#10;        uses: actions/upload-pages-artifact@v3&#10;        with:&#10;          path: '.'&#10;      - name: Deploy to GitHub Pages&#10;        id: deployment&#10;        uses: actions/deploy-pages@v4" style="position: absolute; top: 8px; right: 8px;">
                                        Copiar YAML
                                    </button>
                                </div>
                            </details>
                        </div>
                    </div>

                    <!-- Render -->
                    <div class="wpsa-card" id="card-render-settings">
                        <div class="wpsa-card-header">
                            <h2><span class="dashicons dashicons-admin-site-alt3" style="color: #06b6d4;"></span> Render (Deploy Hook)</h2>
                            <p>Despliega sitios estáticos en Render mediante peticiones POST instantáneas.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group">
                                <label for="render_deploy_hook"><strong>Render Deploy Hook URL</strong></label>
                                <input type="url" id="render_deploy_hook" name="wp_static_arquitect_render_deploy_hook" value="<?php echo esc_attr( $render_deploy_hook ); ?>" class="regular-text" placeholder="https://api.render.com/deploy/srv-xxxx?key=yyyy">
                                <small class="wpsa-help-text">Encuentra tu Deploy Hook en Render: <em>Tu Static Site &gt; Settings &gt; Deploy Hook</em>.</small>
                            </div>
                        </div>
                    </div>

                    <!-- Formularios Serverless, Google Sheets & Inboxes Externos -->
                    <div class="wpsa-card" id="card-forms-settings">
                        <div class="wpsa-card-header">
                            <h2><span class="dashicons dashicons-email-alt" style="color: #10b981;"></span> Formularios Serverless &amp; Google Sheets (CSV)</h2>
                            <p>Recibe contactos directamente en tu correo o en una hoja de cálculo Google Drive sin servidor PHP.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group">
                                <label for="form_provider"><strong>Manejador de Formularios</strong></label>
                                <select id="form_provider" name="wp_static_arquitect_form_provider" style="width: 100%;">
                                    <option value="auto" <?php selected( $form_provider, 'auto' ); ?>>Automático (Recomendado según el Hosting)</option>
                                    <option value="formsubmit" <?php selected( $form_provider, 'formsubmit' ); ?>>FormSubmit / Cloudflare Email Routing (Directo a tu correo con o sin dominio)</option>
                                    <option value="google_sheets" <?php selected( $form_provider, 'google_sheets' ); ?>>Google Sheets / Excel CSV (Base de Datos en Google Drive)</option>
                                    <option value="web3forms" <?php selected( $form_provider, 'web3forms' ); ?>>Web3Forms (Inbox API Gratuito sin Servidor)</option>
                                    <option value="netlify" <?php selected( $form_provider, 'netlify' ); ?>>Netlify Forms (Solo si hospedas en Netlify)</option>
                                </select>
                            </div>

                            <!-- Tip Profesional: Cloudflare Email Routing -->
                            <div style="margin-top: 10px; padding: 12px 14px; background: #fff7ed; border: 1px solid #fed7aa; border-left: 4px solid #f97316; border-radius: 6px; font-size: 12.5px; color: #9a3412;">
                                <strong style="display: flex; align-items: center; gap: 6px; color: #c2410c; margin-bottom: 4px;">
                                    <span class="dashicons dashicons-lightbulb"></span> Tip Profesional: ¿Hospedas en Cloudflare o gestionas tu dominio allí?
                                </strong>
                                <p style="margin: 0 0 6px 0; color: #7c2d12; line-height: 1.45;">
                                    No necesitas contratar servicios de correo de pago. Activa <strong>Cloudflare Email Routing</strong> en tu panel de Cloudflare para crear correos de dominio (ej. <code>contacto@tudominio.com</code>) que se reenvían gratis a tu cuenta personal de Gmail/Outlook.
                                </p>
                                <small style="color: #9a3412; font-weight: 600;">
                                    👉 Luego coloca ese correo corporativo abajo en la casilla <em>"Correo para FormSubmit"</em> y recibirás los contactos de tu sitio estático directamente en tu Gmail.
                                </small>
                            </div>

                            <!-- Configuración Google Sheets -->
                            <div class="wpsa-input-group" style="padding: 12px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; margin-top: 10px;">
                                <label for="google_sheets_url" style="color: #166534;"><strong>Google Apps Script Web App URL (Google Sheets / CSV)</strong></label>
                                <input type="url" id="google_sheets_url" name="wp_static_arquitect_google_sheets_url" value="<?php echo esc_attr( $google_sheets_url ); ?>" class="regular-text" placeholder="https://script.google.com/macros/s/xxxx/exec">
                                <small class="wpsa-help-text" style="color: #15803d;">Copia la URL del Web App desplegado en tu Google Drive. Cada contacto se guardará en una fila nueva y podrás descargar la lista en .CSV o .XLSX.</small>
                                
                                <details style="margin-top: 8px; font-size: 12px; color: #166534;">
                                    <summary style="cursor: pointer; font-weight: 600;">Ver plantilla de código para Google Apps Script</summary>
                                    <div style="margin-top: 6px; position: relative;">
                                        <pre style="background: #ffffff; padding: 10px; border-radius: 4px; font-size: 11px; overflow-x: auto; border: 1px solid #86efac; color: #1e293b;"><code>function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var p = e.parameter;
  sheet.appendRow([new Date(), p.name || p.nombre || '', p.email || p.correo || '', p.message || p.mensaje || '', p._form_name || '', p._source_url || '']);
  return ContentService.createTextOutput("OK").setMimeType(ContentService.MimeType.TEXT);
}</code></pre>
                                        <button type="button" class="button button-small wpsa-inline-copy-btn" data-copy-text="function doPost(e) { var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet(); var p = e.parameter; sheet.appendRow([new Date(), p.name || p.nombre || '', p.email || p.correo || '', p.message || p.mensaje || '', p._form_name || '', p._source_url || '']); return ContentService.createTextOutput(&quot;OK&quot;).setMimeType(ContentService.MimeType.TEXT); }" style="position: absolute; top: 6px; right: 6px;">
                                            Copiar Script
                                        </button>
                                    </div>
                                </details>
                            </div>

                            <div class="wpsa-input-group" style="margin-top: 10px;">
                                <label for="web3forms_key">Web3Forms Access Key</label>
                                <input type="text" id="web3forms_key" name="wp_static_arquitect_web3forms_key" value="<?php echo esc_attr( $web3forms_key ); ?>" class="regular-text" placeholder="ej. a1b2c3d4-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
                                <small class="wpsa-help-text">Obtén tu clave gratuita en <a href="https://web3forms.com" target="_blank" rel="noopener noreferrer">web3forms.com</a> (recibes envíos ilimitados en tu correo).</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="formsubmit_email"><strong>Correo para FormSubmit / Cloudflare Email Routing</strong></label>
                                <input type="email" id="formsubmit_email" name="wp_static_arquitect_formsubmit_email" value="<?php echo esc_attr( $formsubmit_email ); ?>" class="regular-text" placeholder="ej. contacto@tudominio.com o tu_correo@gmail.com">
                                <small class="wpsa-help-text">Dirección a donde se enviarán las notificaciones de los formularios de contacto (admite correos corporativos reenviados por Cloudflare o correos Gmail directos).</small>
                            </div>
                        </div>
                    </div>

                    <!-- ======================================================== -->
                    <!-- Pinterest Auto-Pin & Drip-Feed Editorial                  -->
                    <!-- ======================================================== -->
                    <div class="wpsa-card" id="card-pinterest-settings" style="grid-column: 1 / -1;">
                        <div class="wpsa-card-header" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                            <div>
                                <h2><span class="dashicons dashicons-share" style="color: #e60023;"></span> Pinterest Auto-Pin &amp; Drip-Feed Editorial (Publicación Humana Escalonada)</h2>
                                <p>Simula un ritmo editorial humano (3 a 5 posts/día) para posicionamiento orgánico en Google y publica automáticamente pines con imagen destacada hacia Pinterest API v5.</p>
                            </div>
                            <span class="wpsa-badge" style="background: #fee2e2; color: #b91c1c; font-weight: 700; font-size: 11.5px; padding: 4px 10px; border-radius: 12px;">
                                Tráfico Orgánico &amp; Backlinks
                            </span>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-grid-2col">
                                <!-- Drip-Feed Editorial -->
                                <div style="padding: 14px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;">
                                    <h4 style="margin: 0 0 10px 0; font-size: 14px; color: #1e293b; display: flex; align-items: center; gap: 6px;">
                                        <span class="dashicons dashicons-calendar-alt" style="color: #4f46e5;"></span> 1. Ritmo Editorial Drip-Feed (Anticípate a la IA)
                                    </h4>
                                    <div class="wpsa-input-group">
                                        <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                                            <input type="checkbox" name="wp_static_arquitect_drip_feed_enabled" value="1" <?php checked( $drip_feed_enabled, '1' ); ?> style="margin-top: 3px;">
                                            <div>
                                                <strong>Activar Publicación Escalonada Drip-Feed:</strong>
                                                <p style="margin: 3px 0 0 0; font-size: 12px; color: #64748b;">
                                                    En lugar de exportar 100 o 200 posts de golpe, libera progresivamente una cuota diaria de artículos para que Google los indexe de forma natural como un medio editorial humano.
                                                </p>
                                            </div>
                                        </label>
                                    </div>

                                    <div class="wpsa-input-group" style="margin-top: 10px;">
                                        <label for="drip_posts_count"><strong>Entradas a Publicar por Lote Diario (Drip-Feed):</strong></label>
                                        <div style="display: flex; align-items: center; gap: 10px; margin-top: 4px;">
                                            <input type="number" id="drip_posts_count" name="wp_static_arquitect_drip_posts_count" value="<?php echo esc_attr( $drip_posts_count ? $drip_posts_count : 5 ); ?>" min="1" max="20" step="1" style="width: 80px;" />
                                            <span style="font-size: 12px; color: #64748b;">artículos/día (Por defecto: <strong>5</strong>. Rango: 1 a 20).</span>
                                        </div>
                                        <small class="wpsa-help-text">Recomendamos entre 3 y 5 entradas al día para imitar fielmente el ritmo de un equipo editorial humano ante Google y evitar que se catalogue como publicación masiva de IA.</small>
                                    </div>

                                    <!-- Humanizador Editorial FIFO para Entradas Generadas con IA -->
                                    <div style="margin-top: 14px; padding: 12px; background: #ffffff; border: 1px solid #c7d2fe; border-radius: 6px;">
                                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                                            <strong style="color: #3730a3; font-size: 12.5px; display: flex; align-items: center; gap: 5px;">
                                                <span class="dashicons dashicons-clock" style="color: #4f46e5; font-size: 16px; width: 16px; height: 16px;"></span>
                                                Humanizador Editorial de Fechas (FIFO &amp; IA)
                                            </strong>
                                            <?php
                                            $post_counts_obj = wp_count_posts( 'post' );
                                            $drafts_count = isset( $post_counts_obj->draft ) ? (int) $post_counts_obj->draft : 0;
                                            $future_count = isset( $post_counts_obj->future ) ? (int) $post_counts_obj->future : 0;
                                            ?>
                                            <span style="font-size: 11px; background: #ede9fe; color: #5b21b6; font-weight: 700; padding: 2px 7px; border-radius: 10px;">
                                                <?php echo esc_html( $drafts_count ); ?> borradores en cola
                                            </span>
                                        </div>
                                        <p style="margin: 0 0 8px 0; font-size: 11.5px; color: #475569; line-height: 1.4;">
                                            Toma los borradores más antiguos creados por IA y les distribuye horas humanas aleatorias entre las 08:30 y 21:30 con variación impredecible de minutos y segundos.
                                        </p>
                                        <button type="button" id="btn-humanize-drip-posts" class="button button-secondary" style="width: 100%; justify-content: center; display: inline-flex; align-items: center; gap: 6px; font-size: 12px; font-weight: 600;">
                                            <span class="dashicons dashicons-randomize"></span>
                                            <span class="btn-text">Distribuir &amp; Humanizar Horas de Borradores Ahora</span>
                                            <span class="wpsa-spinner"></span>
                                        </button>
                                        <div id="humanize-drip-feedback" class="wpsa-feedback-msg" style="margin-top: 8px;"></div>
                                    </div>
                                </div>

                                <!-- Pinterest API v5 -->
                                <div style="padding: 14px; background: #fff1f2; border: 1px solid #fecdd3; border-radius: 8px;">
                                    <h4 style="margin: 0 0 10px 0; font-size: 14px; color: #9f1239; display: flex; align-items: center; gap: 6px;">
                                        <span class="dashicons dashicons-pinterest" style="color: #e60023;"></span> 2. Auto-Pin en Pinterest (API v5)
                                    </h4>
                                    <div class="wpsa-input-group">
                                        <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                                            <input type="checkbox" name="wp_static_arquitect_pinterest_auto_pin" value="1" <?php checked( $pinterest_auto_pin, '1' ); ?> style="margin-top: 3px;">
                                            <div>
                                                <strong>Crear Pines Automáticos al Publicar:</strong>
                                                <p style="margin: 3px 0 0 0; font-size: 12px; color: #881337;">
                                                    Dispara Pines a tu tablero de Pinterest por cada post publicado con enlace hacia tu sitio estático.
                                                </p>
                                            </div>
                                        </label>
                                    </div>

                                    <div class="wpsa-input-group" style="margin-top: 8px;">
                                        <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                                            <input type="checkbox" name="wp_static_arquitect_pinterest_multi_pin" value="1" <?php checked( '0' !== get_option( 'wp_static_arquitect_pinterest_multi_pin', '1' ), true ); ?> style="margin-top: 3px;">
                                            <div>
                                                <strong>Estrategia Multi-Pin (3 Pines por Artículo):</strong>
                                                <p style="margin: 2px 0 0 0; font-size: 11.5px; color: #881337;">
                                                    Crea 3 pines independientes por cada post (Imagen Destacada + Imagen Interna 1 + Imagen Interna 2) apuntando a la URL estática. <strong>Triplica el tráfico orgánico y los puntos de entrada desde Pinterest</strong>.
                                                </p>
                                            </div>
                                        </label>
                                    </div>

                                    <div class="wpsa-input-group" style="margin-top: 10px;">
                                        <label for="pinterest_token">Pinterest Access Token <span class="required">*</span></label>
                                        <input type="password" id="pinterest_token" name="wp_static_arquitect_pinterest_token" value="<?php echo esc_attr( $pinterest_token ); ?>" class="regular-text" placeholder="pina_xxxxxxxxxxxxxxxxxxxx">
                                        <small class="wpsa-help-text">Obtén tu token en el portal de desarrolladores: <a href="https://developers.pinterest.com" target="_blank" rel="noopener noreferrer">developers.pinterest.com</a>.</small>
                                    </div>

                                    <div class="wpsa-input-group">
                                        <label for="pinterest_board_id">Pinterest Board ID (ID del Tablero) <span class="required">*</span></label>
                                        <input type="text" id="pinterest_board_id" name="wp_static_arquitect_pinterest_board_id" value="<?php echo esc_attr( $pinterest_board_id ); ?>" class="regular-text" placeholder="ej. 123456789012345678">
                                    </div>

                                    <div style="display: flex; gap: 10px; margin-top: 12px; flex-wrap: wrap;">
                                        <button type="button" id="btn-test-pinterest" class="button button-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                                            <span class="dashicons dashicons-update"></span>
                                            <span class="btn-text">Probar Conexión Pinterest</span>
                                            <span class="wpsa-spinner"></span>
                                        </button>
                                        <button type="button" id="btn-sync-pinterest" class="button button-secondary" style="display: inline-flex; align-items: center; gap: 6px;">
                                            <span class="dashicons dashicons-cloud-upload"></span>
                                            <span class="btn-text">Sincronizar Pines Ahora</span>
                                            <span class="wpsa-spinner"></span>
                                        </button>
                                    </div>
                                    <div id="pinterest-feedback" class="wpsa-feedback-msg" style="margin-top: 8px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Opciones Globales de Exportación -->
                <div class="wpsa-card" style="margin-top: 1.5rem;">
                    <div class="wpsa-card-header">
                        <h2>Preferencias de Generación Estática</h2>
                    </div>
                    <div class="wpsa-card-body">
                        <div class="wpsa-input-group">
                            <label for="url_mode">Estructura de Enlaces Generados</label>
                            <select id="url_mode" name="wp_static_arquitect_url_mode">
                                <option value="root-relative" <?php selected( $url_mode, 'root-relative' ); ?>>Rutas Absolutas a Raíz (/sobre-nosotros/) — Recomendado para Netlify & Vercel</option>
                                <option value="relative" <?php selected( $url_mode, 'relative' ); ?>>Rutas Relativas Estrictas (../../sobre-nosotros/) — Para navegación local sin servidor</option>
                            </select>
                        </div>

                        <div class="wpsa-grid-2col" style="margin-top: 15px;">
                            <div class="wpsa-input-group">
                                <label for="netlify_custom_redirects">Reglas de Redirección Netlify (<code>_redirects</code>)</label>
                                <textarea id="netlify_custom_redirects" name="wp_static_arquitect_netlify_custom_redirects" rows="5" class="large-text code" placeholder="/antigua-url/  /nueva-url/  301&#10;/blog/*  /noticias/:splat  302"><?php echo esc_textarea( $netlify_custom_redirects ); ?></textarea>
                                <small class="wpsa-help-text">Sintaxis estándar de Netlify: <code>/origen /destino [codigo_http]</code> (una regla por línea).</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="netlify_custom_headers">Cabeceras Personalizadas Netlify (<code>_headers</code>)</label>
                                <textarea id="netlify_custom_headers" name="wp_static_arquitect_netlify_custom_headers" rows="5" class="large-text code" placeholder="/*&#10;  Access-Control-Allow-Origin: *&#10;  X-Robots-Tag: all"><?php echo esc_textarea( $netlify_custom_headers ); ?></textarea>
                                <small class="wpsa-help-text">Cabeceras HTTP añadidas al archivo <code>_headers</code> de Netlify.</small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="wpsa-form-submit">
                    <?php submit_button( 'Guardar Ajustes de API', 'primary', 'submit', false ); ?>
                </div>
            </form>
        </div>

        <!-- ==================== TAB: BUSCADOR & RUTAS AVANZADAS ==================== -->
        <div id="tab-advanced" class="wpsa-tab-pane">
            <form method="post" action="options.php" class="wpsa-form-card" id="wpsa-advanced-settings-form">
                <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>

                <div class="wpsa-grid-2col">
                    <!-- Tarjeta: Optimización GEO para IAs (llms.txt & Schema.org) -->
                    <div class="wpsa-card">
                        <div class="wpsa-card-header">
                            <h2><span class="dashicons dashicons-superhero-alt" style="color: #8b5cf6;"></span> Optimización GEO (Generative Engine Optimization)</h2>
                            <p>Prepara tu sitio estático para ser comprendido, indexado y citado con precisión por motores de IA como ChatGPT, Claude, Perplexity y Gemini.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group" style="padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px;">
                                <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_enable_geo" value="1" <?php checked( $enable_geo, '1' ); ?> style="margin-top: 3px;">
                                    <div>
                                        <strong>Activar Optimización GEO para Motores de IA:</strong>
                                        <p style="margin: 3px 0 0 0; font-size: 12.5px; color: #64748b;">
                                            Genera automáticamente el estándar <code>llms.txt</code> en la raíz del sitio, añade directivas explícitas para agentes IA (GPTBot, ClaudeBot, PerplexityBot) en <code>robots.txt</code> e inyecta metadatos estructurados Schema.org (JSON-LD) en cada página HTML.
                                        </p>
                                    </div>
                                </label>
                            </div>

                            <div class="wpsa-input-group" style="margin-top: 12px; padding: 12px; background: #f5f3ff; border: 1px solid #ddd6fe; border-radius: 6px;">
                                <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_llms_full" value="1" <?php checked( $enable_llms_full, '1' ); ?> style="margin-top: 3px;">
                                    <div>
                                        <strong>Generar también <code>llms-full.txt</code> (Contenido Extendido):</strong>
                                        <p style="margin: 3px 0 0 0; font-size: 12.5px; color: #5b21b6;">
                                            Incluye el texto completo en markdown limpio de todas las páginas y entradas públicas para permitir que los agentes lean la base de conocimiento completa sin realizar cientos de peticiones HTTP.
                                        </p>
                                    </div>
                                </label>
                            </div>

                            <div class="wpsa-info-callout" style="margin-top: 14px; padding: 12px; background: #eff6ff; border-left: 4px solid #3b82f6; border-radius: 4px;">
                                <div style="display: flex; gap: 8px;">
                                    <span class="dashicons dashicons-info" style="color: #3b82f6;"></span>
                                    <div style="font-size: 12.5px; color: #1e40af;">
                                        <strong>¿Por qué es crucial el GEO?</strong>
                                        Los motores de IA utilizan <code>/llms.txt</code> para contextualizar tu sitio de manera concisa sin consumir excesivos tokens. Además, las etiquetas Schema.org garantizan que tu negocio aparezca como fuente autorizada en respuestas generadas.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tarjeta: Buscador Estático Instantáneo -->
                    <div class="wpsa-card">
                        <div class="wpsa-card-header">
                            <h2><span class="dashicons dashicons-search" style="color: #6366f1;"></span> Buscador Estático Instantáneo (Spotlight)</h2>
                            <p>Buscador cliente ultra-rápido estilo macOS Spotlight / Alfred (Ctrl + K / ⌘ K) generado sin librerías externas ni dependencias npm.</p>
                        </div>
                        <div class="wpsa-card-body">
                            <div class="wpsa-input-group" style="padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px;">
                                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_enable_search" value="1" <?php checked( $enable_search, '1' ); ?>>
                                    <span><strong>Activar Buscador Estático en el frontend:</strong> Genera automáticamente <code>search-index.json</code> e inyecta la ventana modal Spotlight accesible mediante atajo de teclado o clic en el icono.</span>
                                </label>
                            </div>

                            <div class="wpsa-info-callout" style="margin-top: 14px; padding: 12px; background: #eff6ff; border-left: 4px solid #3b82f6; border-radius: 4px;">
                                <div style="display: flex; gap: 8px;">
                                    <span class="dashicons dashicons-info" style="color: #3b82f6;"></span>
                                    <div style="font-size: 13px; color: #1e40af;">
                                        <strong>Ventajas sobre Simply Static y Algolia:</strong>
                                        <ul style="margin: 6px 0 0 16px; list-style-type: disc;">
                                            <li><strong>0 llamadas a servidores de pago:</strong> Funciona 100% offline o en Netlify CDN.</li>
                                            <li><strong>Indexación profunda:</strong> Extrae títulos, extractos, slugs y contenido limpio de cada página durante el rastreo.</li>
                                            <li><strong>Diseño Glassmorphism:</strong> Soporte automático para temas claros y oscuros según las preferencias del sistema.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    </div>
                </div>

                <!-- Tarjeta: Sitemap XML & Robots.txt SEO -->
                <div class="wpsa-card" style="margin-top: 1.5rem;">
                    <div class="wpsa-card-header">
                        <h2><span class="dashicons dashicons-chart-line" style="color: #10b981;"></span> Generador Nativo de Sitemap & Robots.txt</h2>
                        <p>Crea automáticamente archivos de rastreo para Googlebot, Bingbot y motores de búsqueda optimizados para tu dominio estático.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <div class="wpsa-grid-2col">
                            <div class="wpsa-input-group" style="padding: 14px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;">
                                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_enable_sitemap" value="1" <?php checked( $enable_sitemap, '1' ); ?>>
                                    <span><strong>Generar <code>sitemap.xml</code> y <code>robots.txt</code>:</strong> Construye un mapa del sitio estándar con todas las URLs rastreadas y su fecha de modificación.</span>
                                </label>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="production_url"><strong>URL Canónica de Producción</strong> <span class="optional">(Recomendado para SEO)</span></label>
                                <input type="url" id="production_url" name="wp_static_arquitect_production_url" value="<?php echo esc_attr( $production_url ); ?>" class="regular-text" placeholder="https://mi-dominio-estatico.com" style="width: 100%;">
                                <small class="wpsa-help-text">Si se define, los enlaces en <code>sitemap.xml</code> usarán esta URL pública absoluta en vez del dominio de desarrollo local.</small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tarjeta Ancha: Inclusiones y Exclusiones de URLs -->
                <div class="wpsa-card" style="margin-top: 1.5rem;">
                    <div class="wpsa-card-header">
                        <h2><span class="dashicons dashicons-filter" style="color: #f59e0b;"></span> Gestor Avanzado de Inclusiones y Exclusiones</h2>
                        <p>Control granular de rutas y recursos que Simply Static no permite gestionar con facilidad.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <div class="wpsa-grid-2col">
                            <div class="wpsa-input-group">
                                <label for="additional_urls"><strong>URLs y Archivos Adicionales a Incluir</strong></label>
                                <textarea id="additional_urls" name="wp_static_arquitect_additional_urls" rows="6" class="large-text code" placeholder="/mi-catalogo.pdf&#10;/landing-secreta/&#10;/archivos/especificaciones.zip&#10;https://externo.com/recurso.css"><?php echo esc_textarea( $additional_urls ); ?></textarea>
                                <small class="wpsa-help-text">Introduce una URL o ruta por línea. Puedes incluir PDFs, subcarpetas, landings huérfanas o recursos estáticos sueltos.</small>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="excluded_urls"><strong>Reglas de Exclusión de URLs</strong></label>
                                <textarea id="excluded_urls" name="wp_static_arquitect_excluded_urls" rows="6" class="large-text code" placeholder="/wp-json/*&#10;/area-privada/&#10;regex:^/wp-content/uploads/temp/&#10;regex:\.bak$"><?php echo esc_textarea( $excluded_urls ); ?></textarea>
                                <small class="wpsa-help-text">Una regla por línea. Soporta coincidencias parciales (ej: <code>/privado/</code>) y expresiones regulares anteponiendo <code>regex:</code>.</small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="wpsa-form-submit">
                    <?php submit_button( 'Guardar Ajustes Avanzados & Buscador', 'primary', 'submit', false ); ?>
                </div>
            </form>
        </div>

        <!-- ==================== TAB: CREADOR EDITORIAL DE ENTRADAS CON IA (SEO & GEO) ==================== -->
        <div id="tab-ai-generator" class="wpsa-tab-pane">
            <div class="wpsa-card" style="margin-bottom: 20px; border-left: 4px solid #7c3aed; background: linear-gradient(to right, #ffffff, #faf5ff);">
                <div class="wpsa-card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                    <div>
                        <h2><span class="dashicons dashicons-superhero-alt" style="color: #7c3aed;"></span> Asistente Editorial de Nuevas Entradas con IA (SEO &amp; GEO en Vivo)</h2>
                        <p style="margin: 4px 0 0 0; color: #64748b;">Genera nuevos artículos de rigor científico basados en motores de búsqueda reales (Google &amp; Wikipedia), estructurados para citas en IAs generativas (Perplexity, ChatGPT Search, Google SGE) y sin duplicar jamás los artículos existentes de Mundos Simulados.</p>
                    </div>
                    <span class="wpsa-health-pill wpsa-health-pass" style="background: #ede9fe; color: #6d28d9; border-color: #c4b5fd;">
                        <span class="dashicons dashicons-saved"></span> Método Editorial 1400-1900 palabras
                    </span>
                </div>
                <div class="wpsa-card-body">
                    <!-- Selector de Modo -->
                    <div style="display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px;">
                        <button type="button" id="btn-mode-custom-idea" class="button button-primary" style="display: flex; align-items: center; gap: 6px; font-weight: 600;">
                            <span class="dashicons dashicons-edit"></span> Modo 1: Escribir mi Propia Idea / Premisa
                        </button>
                        <button type="button" id="btn-mode-auto-discover" class="button button-secondary" style="display: flex; align-items: center; gap: 6px; font-weight: 600;">
                            <span class="dashicons dashicons-search"></span> Modo 2: Descubrimiento Autónomo en Motores de Búsqueda (Cero Repeticiones)
                        </button>
                    </div>

                    <!-- Panel MODO 1: Idea Propia -->
                    <div id="wpsa-ai-panel-custom-idea">
                        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 16px;">
                            <div>
                                <label for="wpsa-ai-custom-topic" style="display: block; font-weight: 700; margin-bottom: 6px; color: #1e293b;">
                                    Premisa o Hipótesis Científica ("¿Qué pasaría si...?")
                                </label>
                                <textarea id="wpsa-ai-custom-topic" rows="4" class="large-text" placeholder="Ej: ¿Qué pasaría si la gravedad terrestre disminuyera un 10%? o ¿Qué pasaría si el Sahara se cubriera completamente de paneles solares?" style="width: 100%; border-radius: 6px; border: 1px solid #cbd5e1; padding: 10px;"></textarea>
                                <small style="display: block; margin-top: 4px; color: #64748b;">
                                    La IA buscará en Google y Wikipedia las constantes físicas y datos reales medibles antes de simular las consecuencias temporales.
                                </small>
                            </div>
                            <div>
                                <label for="wpsa-ai-custom-category" style="display: block; font-weight: 700; margin-bottom: 6px; color: #1e293b;">
                                    Categoría Editorial
                                </label>
                                <select id="wpsa-ai-custom-category" style="width: 100%; margin-bottom: 12px; height: 38px; border-radius: 6px;">
                                    <option value="astrofisica">Astrofísica y Espacio</option>
                                    <option value="tecnologia">Tecnología y Futuro</option>
                                    <option value="biosfera">Biosfera, Naturaleza y Clima</option>
                                    <option value="economia">Economía y Sociedad Global</option>
                                </select>

                                <label for="wpsa-ai-custom-keyword" style="display: block; font-weight: 700; margin-bottom: 6px; color: #1e293b;">
                                    Palabra Clave Objetivo (Opcional)
                                </label>
                                <input type="text" id="wpsa-ai-custom-keyword" placeholder="Dejar vacío para auto-optimizar" class="regular-text" style="width: 100%; border-radius: 6px;">
                                <small style="display: block; margin-top: 4px; color: #64748b;">Se integrará en el primer párrafo y subtítulos GEO.</small>
                            </div>
                        </div>
                        <div style="margin-top: 16px;">
                            <button type="button" id="btn-wpsa-generate-custom" class="button button-primary button-hero" style="display: flex; align-items: center; gap: 8px; background: #7c3aed; border-color: #6d28d9;">
                                <span class="dashicons dashicons-controls-play"></span>
                                <span class="btn-text">Investigar en Motores de Búsqueda y Crear Borrador con IA</span>
                                <span class="wpsa-spinner"></span>
                            </button>
                        </div>
                    </div>

                    <!-- Panel MODO 2: Descubrimiento Autónomo -->
                    <div id="wpsa-ai-panel-auto-discover" style="display: none;">
                        <div style="display: flex; gap: 12px; align-items: flex-end; margin-bottom: 16px; background: #f8fafc; padding: 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                            <div style="flex: 1;">
                                <label for="wpsa-ai-discover-category" style="display: block; font-weight: 700; margin-bottom: 6px; color: #1e293b;">
                                    Seleccionar Categoría a Investigar:
                                </label>
                                <select id="wpsa-ai-discover-category" style="width: 100%; height: 38px; border-radius: 6px;">
                                    <option value="astrofisica">Astrofísica y Espacio</option>
                                    <option value="tecnologia">Tecnología y Futuro</option>
                                    <option value="biosfera">Biosfera, Naturaleza y Clima</option>
                                    <option value="economia">Economía y Sociedad Global</option>
                                </select>
                            </div>
                            <div>
                                <button type="button" id="btn-wpsa-discover-topics" class="button button-primary" style="height: 38px; display: flex; align-items: center; gap: 6px; background: #2563eb; border-color: #1d4ed8; font-weight: 600;">
                                    <span class="dashicons dashicons-search"></span>
                                    <span class="btn-text">Escanear Tendencias de Búsqueda y Proponer Temas</span>
                                    <span class="wpsa-spinner"></span>
                                </button>
                            </div>
                        </div>

                        <!-- Contenedor de Propuestas Descubiertas -->
                        <div id="wpsa-discovered-topics-wrapper" style="display: none;">
                            <h4 style="margin: 16px 0 10px 0; color: #334155; font-size: 15px; display: flex; align-items: center; gap: 6px;">
                                <span class="dashicons dashicons-lightbulb" style="color: #eab308;"></span> Temas Inéditos Basados en Consultas Reales de Motores de Búsqueda (Garantía Cero Duplicados)
                            </h4>
                            <div id="wpsa-discovered-topics-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 14px;"></div>
                        </div>
                    </div>

                    <!-- Estado y Progreso en Tiempo Real -->
                    <div id="wpsa-ai-generation-progress" style="display: none; margin-top: 20px; padding: 16px; background: #faf5ff; border: 1px solid #d8b4fe; border-radius: 8px;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                            <span class="spinner is-active" style="float: none; margin: 0;"></span>
                            <strong id="wpsa-ai-progress-text" style="color: #6b21a8; font-size: 14px;">Investigando motores de búsqueda y redactando el artículo...</strong>
                        </div>
                        <p style="margin: 0; font-size: 12px; color: #7e22ce;">Este proceso consulta Google Suggest, Wikipedia y genera 1400-1900 palabras con rigor científico e interlinking. Toma aproximadamente entre 30 y 60 segundos.</p>
                    </div>

                    <!-- Tarjeta de Resultado de Publicación -->
                    <div id="wpsa-ai-generation-result" style="display: none; margin-top: 20px; padding: 18px; background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px;">
                        <div style="display: flex; align-items: flex-start; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
                            <div>
                                <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                                    <span class="dashicons dashicons-yes-alt" style="color: #16a34a; font-size: 24px; width: 24px; height: 24px;"></span>
                                    <h3 style="margin: 0; color: #166534; font-size: 16px;" id="wpsa-ai-result-title">¡Borrador Creado Exitosamente en WordPress!</h3>
                                </div>
                                <p style="margin: 4px 0 0 32px; color: #15803d; font-size: 13px;" id="wpsa-ai-result-meta">Extensión: 1,520 palabras | SEO RankMath configurado | Marcadores de imágenes incluidos</p>
                                <p style="margin: 4px 0 0 32px; color: #64748b; font-size: 12px;">El post quedó guardado en estado <strong>Borrador</strong> y listo para ser programado en la cola FIFO del Humanizador Editorial Drip-Feed.</p>
                            </div>
                            <div style="display: flex; gap: 8px;">
                                <a href="#" id="wpsa-ai-btn-edit-post" target="_blank" class="button button-primary" style="display: flex; align-items: center; gap: 6px;">
                                    <span class="dashicons dashicons-edit"></span> Editar Borrador en WP
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==================== TAB 4: NETLIFY FORMS & PURGADOR ==================== -->
        <div id="tab-netlify" class="wpsa-tab-pane">
            <div class="wpsa-grid-2col">
                <!-- Modularidad: Toggle Maestro de Formularios -->
                <div class="wpsa-card" style="grid-column: span 2; margin-bottom: 0.5rem;">
                    <div class="wpsa-card-header">
                        <h2><span class="dashicons dashicons-forms" style="color: #0ea5e9;"></span> Modularidad de Formularios Serverless (Netlify Forms)</h2>
                        <p>Habilita o deshabilita la captura de formularios según la naturaleza de tu sitio web.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <form method="post" action="options.php">
                            <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>
                            <input type="hidden" name="wp_static_arquitect_netlify_pat" value="<?php echo esc_attr( $netlify_pat ); ?>">
                            <input type="hidden" name="wp_static_arquitect_netlify_site_id" value="<?php echo esc_attr( $netlify_site_id ); ?>">

                            <div class="wpsa-input-group" style="padding: 14px; background: <?php echo '1' === $enable_forms ? '#f0fdf4' : '#f8fafc'; ?>; border: 1px solid <?php echo '1' === $enable_forms ? '#bbf7d0' : '#e2e8f0'; ?>; border-radius: 8px;">
                                <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_enable_forms" value="1" <?php checked( $enable_forms, '1' ); ?> style="margin-top: 3px;">
                                    <div>
                                        <strong>Habilitar Procesamiento de Formularios Netlify:</strong>
                                        <p style="margin: 3px 0 0 0; font-size: 13px; color: #475569;">
                                            Si tu sitio es corporativo, catálogo o meramente informativo y <strong>no utiliza formularios</strong>, desmarca esta opción. El exportador estático no alterará tus etiquetas <code>&lt;form&gt;</code> ni inyectará atributos Netlify, logrando un HTML completamente limpio y sin dependencias.
                                        </p>
                                    </div>
                                </label>
                            </div>
                            <div style="margin-top: 14px;">
                                <?php submit_button( 'Guardar Estado de Formularios', 'primary', 'submit', false ); ?>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="wpsa-card">
                    <div class="wpsa-card-header">
                        <h2>Política de Retención y Purga de Formularios</h2>
                        <p>Control de almacenamiento de envíos y adjuntos en Netlify (en Modo Creador Pro tus datos se conservan al 100% sin purga forzada).</p>
                    </div>
                    <div class="wpsa-card-body">
                        <form method="post" action="options.php">
                            <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>
                            <input type="hidden" name="wp_static_arquitect_netlify_pat" value="<?php echo esc_attr( $netlify_pat ); ?>">
                            <input type="hidden" name="wp_static_arquitect_netlify_site_id" value="<?php echo esc_attr( $netlify_site_id ); ?>">

                            <div class="wpsa-input-group">
                                <label for="threshold_count">Umbral de Alerta y Purga por Envíos</label>
                                <input type="number" id="threshold_count" name="wp_static_arquitect_netlify_threshold_count" value="<?php echo esc_attr( $threshold_count ); ?>" min="10" max="95" class="small-text">
                                <span class="description">envíos (Límite Netlify: 100 envíos. Recomendado: 80).</span>
                            </div>

                            <div class="wpsa-input-group">
                                <label for="threshold_mb">Umbral de Alerta y Purga por Tamaño de Adjuntos</label>
                                <input type="number" id="threshold_mb" name="wp_static_arquitect_netlify_threshold_mb" value="<?php echo esc_attr( $threshold_mb ); ?>" min="1" max="9" class="small-text">
                                <span class="description">MB (Límite Netlify: 10 MB. Recomendado: 8 MB).</span>
                            </div>

                            <div class="wpsa-purge-info-banner">
                                <span class="dashicons dashicons-clock"></span>
                                <div>
                                    <strong>Cron Job Semanal Programado:</strong>
                                    <p>WordPress verifica automáticamente el estado de la API de Netlify cada semana y elimina los envíos más antiguos si se sobrepasan los umbrales configurados.</p>
                                </div>
                            </div>

                            <?php submit_button( 'Guardar Umbrales de Purga', 'secondary', 'submit', false ); ?>
                        </form>
                    </div>
                </div>

                <!-- Estado en Vivo y Purga Manual -->
                <div class="wpsa-card">
                    <div class="wpsa-card-header">
                        <h2>Acción Inmediata de Purga</h2>
                        <p>Elimina los envíos más antiguos en Netlify bajo demanda.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <?php if ( $last_purge ) : ?>
                            <div class="wpsa-alert-box wpsa-alert-info">
                                <strong>Última Purga Ejecutada:</strong>
                                <ul>
                                    <li><strong>Fecha:</strong> <?php echo esc_html( $last_purge['purged_at'] ); ?></li>
                                    <li><strong>Envíos eliminados:</strong> <?php echo esc_html( $last_purge['purged_count'] ); ?></li>
                                    <li><strong>Disparador:</strong> <?php echo 'cron' === $last_purge['triggered_by'] ? 'Cron Semanal' : 'Manual'; ?></li>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="wpsa-action-box-inner">
                            <p>Si deseas liberar espacio de inmediato sin esperar al ciclo del cron, puedes forzar la purga de envíos antiguos ahora:</p>
                            <button type="button" id="btn-force-purge" class="button button-secondary wpsa-danger-btn">
                                <span class="dashicons dashicons-trash"></span>
                                <span class="btn-text">Ejecutar Purga Manual en Netlify</span>
                                <span class="wpsa-spinner"></span>
                            </button>
                            <div id="purge-feedback" class="wpsa-feedback-msg"></div>
                        </div>
                    </div>
                </div>

                <!-- Despliegue al Publicar / Despliegue Programado Diario -->
                <div class="wpsa-card" style="margin-top: 1.5rem; grid-column: span 2;">
                    <div class="wpsa-card-header">
                        <h2><span class="dashicons dashicons-controls-repeat" style="color: #0ea5e9;"></span> Automatización de Despliegues a Netlify</h2>
                        <p>Configura cómo y cuándo se sincroniza tu sitio estático: de forma instantánea al publicar, o consolidado una vez al día a una hora fija.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <form method="post" action="options.php">
                            <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>
                            <input type="hidden" name="wp_static_arquitect_netlify_pat" value="<?php echo esc_attr( $netlify_pat ); ?>">
                            <input type="hidden" name="wp_static_arquitect_netlify_site_id" value="<?php echo esc_attr( $netlify_site_id ); ?>">

                            <!-- MODO 1: Despliegue Instantáneo al Publicar -->
                            <div class="wpsa-input-group" style="padding: 14px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px;">
                                <label style="display: flex; align-items: flex-start; gap: 12px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_deploy_on_save" value="1" <?php checked( $deploy_on_save, '1' ); ?> style="margin-top: 3px;">
                                    <div>
                                        <strong style="color: #0f172a; font-size: 14px;">1. Despliegue Instantáneo (Deploy-on-Save &amp; Scheduled Posts)</strong>
                                        <p style="margin: 4px 0 0 0; color: #64748b; font-size: 13px; line-height: 1.4;">
                                            Dispara la actualización a Netlify inmediatamente cada vez que publiques o guardes una entrada, o en el instante en que WordPress libere automáticamente una <strong>entrada programada</strong>.
                                        </p>
                                    </div>
                                </label>
                            </div>

                            <!-- MODO 2: Despliegue Programado Diario a Hora Fija -->
                            <div class="wpsa-input-group" style="padding: 14px; background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; margin-top: 14px;">
                                <label style="display: flex; align-items: flex-start; gap: 12px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_scheduled_deploy_enabled" value="1" <?php checked( $scheduled_deploy_enabled, '1' ); ?> style="margin-top: 3px;">
                                    <div style="flex: 1;">
                                        <strong style="color: #166534; font-size: 14px;">2. Despliegue Diario Programado a Hora Fija (Smart Batch Deploy)</strong>
                                        <p style="margin: 4px 0 10px 0; color: #15803d; font-size: 13px; line-height: 1.4;">
                                            Ejecuta un pase diario automático a la hora que elijas. Consolida todas las entradas publicadas o editadas durante el día en un único despliegue silencioso.
                                        </p>

                                        <div style="display: flex; flex-wrap: wrap; gap: 16px; align-items: center; margin-top: 10px; padding: 10px 14px; background: #ffffff; border: 1px solid #dcfce7; border-radius: 6px;">
                                            <div>
                                                <label for="scheduled_deploy_time" style="font-weight: 600; font-size: 13px; color: #166534; display: block; margin-bottom: 4px;">
                                                    <span class="dashicons dashicons-clock" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle;"></span> Hora del Despliegue Diario:
                                                </label>
                                                <select id="scheduled_deploy_time" name="wp_static_arquitect_scheduled_deploy_time" style="padding: 4px 10px; border-radius: 6px; border-color: #86efac;">
                                                    <?php
                                                    for ( $h = 0; $h < 24; $h++ ) {
                                                        $time_val = sprintf( '%02d:00', $h );
                                                        $ampm     = $h >= 12 ? 'PM' : 'AM';
                                                        $h12      = $h % 12;
                                                        $h12      = 0 === $h12 ? 12 : $h12;
                                                        $label    = sprintf( '%s (%02d:00 %s)', $time_val, $h12, $ampm );
                                                        if ( 0 === $h ) {
                                                            $label .= ' - Medianoche';
                                                        } elseif ( 12 === $h ) {
                                                            $label .= ' - Mediodía';
                                                        } elseif ( 23 === $h ) {
                                                            $label .= ' - Noche (Por defecto)';
                                                        }
                                                        echo '<option value="' . esc_attr( $time_val ) . '" ' . selected( $scheduled_deploy_time, $time_val, false ) . '>' . esc_html( $label ) . '</option>';
                                                    }
                                                    ?>
                                                </select>
                                                <small style="display: block; color: #15803d; margin-top: 3px;">Zona horaria configurada en tu WordPress: <strong><?php echo esc_html( wp_timezone_string() ); ?></strong></small>
                                            </div>

                                            <div style="flex: 1; min-width: 240px;">
                                                <label style="display: flex; align-items: flex-start; gap: 8px; cursor: pointer; margin-top: 4px;">
                                                    <input type="checkbox" name="wp_static_arquitect_scheduled_deploy_smart_check" value="1" <?php checked( $scheduled_smart_check, '1' ); ?> style="margin-top: 2px;">
                                                    <span style="font-size: 12.5px; color: #166534; line-height: 1.3;">
                                                        <strong>Chequeo Inteligente (Smart Check):</strong> Desplegar únicamente si se detectan entradas nuevas o modificadas desde el último despliegue. Evita gastar recursos si no hubo publicaciones.
                                                    </span>
                                                </label>
                                            </div>
                                        </div>

                                        <!-- Estado de la Próxima Ejecución -->
                                        <div style="margin-top: 10px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
                                            <small style="color: #166534; font-size: 12px;">
                                                <?php if ( $next_scheduled_deploy && '1' === $scheduled_deploy_enabled ) : ?>
                                                    <span class="dashicons dashicons-calendar-alt" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span>
                                                    Próxima ejecución programada: <strong><?php echo esc_html( date_i18n( 'd/m/Y H:i', $next_scheduled_deploy ) ); ?></strong>
                                                <?php else : ?>
                                                    <span class="dashicons dashicons-info" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span>
                                                    Despliegue diario inactivo (marca la casilla arriba y guarda para activarlo).
                                                <?php endif; ?>
                                            </small>
                                            <button type="button" id="btn-check-new-content" class="button button-small" style="border-color: #86efac; color: #166534;">
                                                <span class="dashicons dashicons-search" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle;"></span> Comprobar Contenido Pendiente
                                            </button>
                                        </div>
                                        <div id="check-new-content-result" class="wpsa-test-feedback" style="margin-top: 6px;"></div>
                                    </div>
                                </label>
                            </div>

                            <!-- Build Hook Opcional -->
                            <div class="wpsa-input-group" style="margin-top: 16px;">
                                <label for="netlify_build_hook">Netlify Build Hook URL (Opcional para repositorios Git en Netlify)</label>
                                <input type="url" id="netlify_build_hook" name="wp_static_arquitect_netlify_build_hook" value="<?php echo esc_attr( $netlify_build_hook ); ?>" class="large-text" placeholder="https://api.netlify.com/build_hooks/60f7xxxxxxxxxxxx">
                                <small class="wpsa-help-text">Si no utilizas Git, puedes dejar este campo vacío; el plugin utilizará automáticamente tu <strong>Token Personal (PAT) y Site ID</strong> para exportar y desplegar el archivo ZIP a Netlify.</small>
                            </div>

                            <div class="wpsa-test-box" style="margin-top: 14px; display: flex; align-items: center; gap: 12px;">
                                <button type="button" id="btn-test-build-hook" class="button button-secondary">
                                    <span class="dashicons dashicons-rss"></span> Probar Build Hook Ahora
                                </button>
                                <span id="build-hook-test-result" class="wpsa-test-feedback"></span>
                            </div>

                            <div style="margin-top: 18px;">
                                <?php submit_button( 'Guardar Ajustes de Automatización', 'primary', 'submit', false ); ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==================== TAB 5: SUPABASE & COMENTARIOS ==================== -->
        <div id="tab-supabase" class="wpsa-tab-pane">
            <div class="wpsa-grid-2col">
                <!-- Modularidad: Toggle Maestro de Comentarios -->
                <div class="wpsa-card" style="grid-column: span 2; margin-bottom: 0.5rem;">
                    <div class="wpsa-card-header">
                        <h2><span class="dashicons dashicons-admin-comments" style="color: #10b981;"></span> Modularidad del Sistema de Comentarios (Supabase)</h2>
                        <p>Activa o elimina por completo la infraestructura de comentarios en tus entradas y páginas estáticas.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <form method="post" action="options.php">
                            <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>
                            <input type="hidden" name="wp_static_arquitect_supabase_url" value="<?php echo esc_attr( $supabase_url ); ?>">
                            <input type="hidden" name="wp_static_arquitect_supabase_anon_key" value="<?php echo esc_attr( $supabase_anon_key ); ?>">

                            <div class="wpsa-input-group" style="padding: 14px; background: <?php echo '1' === $enable_comments ? '#f0fdf4' : '#f8fafc'; ?>; border: 1px solid <?php echo '1' === $enable_comments ? '#bbf7d0' : '#e2e8f0'; ?>; border-radius: 8px;">
                                <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                                    <input type="checkbox" name="wp_static_arquitect_enable_comments" value="1" <?php checked( $enable_comments, '1' ); ?> style="margin-top: 3px;">
                                    <div>
                                        <strong>Habilitar Sistema de Comentarios Dinámicos (Supabase):</strong>
                                        <p style="margin: 3px 0 0 0; font-size: 13px; color: #475569;">
                                            Si tu sitio no requiere interacción pública o prefieres prescindir de comentarios para maximizar la velocidad, desmarca esta opción. El exportador eliminará por completo los contenedores <code>#comments</code>, <code>.comments-area</code> y <code>#respond</code> del HTML estático, y no cargará ningún script ni llamada externa a Supabase.
                                        </p>
                                    </div>
                                </label>
                            </div>
                            <div style="margin-top: 14px;">
                                <?php submit_button( 'Guardar Estado de Comentarios', 'primary', 'submit', false ); ?>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="wpsa-card">
                    <div class="wpsa-card-header">
                        <h2>Bootstrap y Moderación de Comentarios</h2>
                        <p>Inicializa la tabla requerida en Supabase y ajusta las políticas de moderación.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <form method="post" action="options.php">
                            <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>
                            <input type="hidden" name="wp_static_arquitect_supabase_url" value="<?php echo esc_attr( $supabase_url ); ?>">
                            <input type="hidden" name="wp_static_arquitect_supabase_anon_key" value="<?php echo esc_attr( $supabase_anon_key ); ?>">

                            <div class="wpsa-input-group">
                                <label for="supabase_auto_approve">Política de Publicación de Comentarios</label>
                                <select id="supabase_auto_approve" name="wp_static_arquitect_supabase_auto_approve">
                                    <option value="0" <?php selected( $supabase_auto_app, '0' ); ?>>Requiere Moderación (is_approved = false por defecto)</option>
                                    <option value="1" <?php selected( $supabase_auto_app, '1' ); ?>>Aprobación Inmediata (is_approved = true por defecto)</option>
                                </select>
                                <small class="wpsa-help-text">Si requiere moderación, podrás cambiar el campo <code>is_approved</code> a true desde el visor de tablas de Supabase.</small>
                            </div>

                            <?php submit_button( 'Guardar Preferencias de Moderación', 'secondary', 'submit', false ); ?>
                        </form>

                        <div class="wpsa-divider"></div>

                        <h3>Bootstrap Automático</h3>
                        <p>Pulsa el botón para enviar la sentencia DDL a Supabase y crear la tabla <code>comments</code> con sus políticas RLS e índices correspondientes:</p>

                        <button type="button" id="btn-run-bootstrap" class="button button-primary">
                            <span class="dashicons dashicons-database-add"></span>
                            <span class="btn-text">Ejecutar Bootstrap Automático</span>
                            <span class="wpsa-spinner"></span>
                        </button>
                        <div id="bootstrap-feedback" class="wpsa-feedback-msg"></div>
                    </div>
                </div>

                <!-- Esquema de Base de Datos Paso a Paso (DDL & RLS) -->
                <div class="wpsa-card wpsa-sql-wizard-card" style="grid-column: span 2; margin-top: 1rem;">
                    <div class="wpsa-card-header wpsa-sql-wizard-header">
                        <div>
                            <h2><span class="dashicons dashicons-database-view" style="color: #3b82f6;"></span> Esquema SQL Paso a Paso para Supabase (DDL &amp; RLS)</h2>
                            <p>Ejecuta cada bloque en secuencia en el <strong>SQL Editor</strong> de Supabase para inicializar tu base de datos de forma guiada, o copia el script completo con un solo clic:</p>
                        </div>
                        <div class="wpsa-sql-wizard-actions">
                            <button type="button" id="btn-copy-full-sql" class="button button-primary wpsa-btn-copy-master" title="Copiar el script SQL completo de una sola vez">
                                <span class="dashicons dashicons-clipboard"></span>
                                <span class="wpsa-btn-copy-label">Copiar Script Completo (Todo en 1)</span>
                            </button>
                            <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" class="button button-secondary wpsa-btn-open-supabase" title="Abrir la consola de Supabase en una pestaña nueva">
                                <span class="dashicons dashicons-external"></span>
                                <span>Abrir Supabase SQL Editor</span>
                            </a>
                        </div>
                    </div>
                    <div class="wpsa-card-body">
                        <!-- Campo oculto con el script completo para copiado maestro -->
                        <textarea id="wpsa-full-sql-raw" style="display: none;"><?php echo esc_textarea( $schema_sql ); ?></textarea>

                        <div class="wpsa-sql-steps-container">
                            <?php foreach ( $schema_steps as $step_item ) : ?>
                                <div class="wpsa-sql-step-card" id="wpsa-sql-step-<?php echo esc_attr( $step_item['step'] ); ?>">
                                    <div class="wpsa-sql-step-header">
                                        <div class="wpsa-sql-step-meta">
                                            <span class="wpsa-step-badge">Paso <?php echo esc_html( $step_item['step'] ); ?> de <?php echo esc_html( count( $schema_steps ) ); ?></span>
                                            <span class="wpsa-step-cat-badge"><?php echo esc_html( $step_item['badge'] ); ?></span>
                                            <h3 class="wpsa-sql-step-title"><?php echo esc_html( $step_item['title'] ); ?></h3>
                                        </div>
                                        <button type="button" class="button wpsa-copy-code-btn" data-clipboard-target="#wpsa-step-code-<?php echo esc_attr( $step_item['step'] ); ?>" title="Copiar sentencia SQL del Paso <?php echo esc_attr( $step_item['step'] ); ?>">
                                            <span class="dashicons dashicons-clipboard"></span>
                                            <span class="wpsa-copy-text">Copiar Paso <?php echo esc_html( $step_item['step'] ); ?></span>
                                        </button>
                                    </div>
                                    <p class="wpsa-sql-step-desc"><?php echo esc_html( $step_item['description'] ); ?></p>
                                    <div class="wpsa-sql-code-wrapper">
                                        <pre class="wpsa-sql-step-code"><code id="wpsa-step-code-<?php echo esc_attr( $step_item['step'] ); ?>"><?php echo esc_html( $step_item['sql'] ); ?></code></pre>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Cloudflare Turnstile Anti-Spam -->
                <div class="wpsa-card" style="margin-top: 1.5rem; grid-column: span 2;">
                    <div class="wpsa-card-header">
                        <h2><span class="dashicons dashicons-shield-alt" style="color: #f97316;"></span> Protección Anti-Spam Invisible con Cloudflare Turnstile</h2>
                        <p>Protege tu formulario estático de comentarios de Supabase frente a bots y spam automatizado sin captchas molestos.</p>
                    </div>
                    <div class="wpsa-card-body">
                        <form method="post" action="options.php">
                            <?php settings_fields( 'wp_static_arquitect_settings_group' ); ?>
                            <input type="hidden" name="wp_static_arquitect_supabase_url" value="<?php echo esc_attr( $supabase_url ); ?>">
                            <input type="hidden" name="wp_static_arquitect_supabase_anon_key" value="<?php echo esc_attr( $supabase_anon_key ); ?>">

                            <div class="wpsa-input-group">
                                <label for="turnstile_site_key">Cloudflare Turnstile Site Key <span class="optional">(Opcional pero recomendado)</span></label>
                                <input type="text" id="turnstile_site_key" name="wp_static_arquitect_turnstile_site_key" value="<?php echo esc_attr( $turnstile_site_key ); ?>" class="large-text" placeholder="0x4AAAAAAAx-xxxxxxxxxxxx">
                                <small class="wpsa-help-text">Obtén tu Site Key gratuita en el panel de Cloudflare: <em>Turnstile &gt; Add Site &gt; Managed (Recomendado)</em>. Si se deja en blanco, los comentarios se enviarán sin verificación de token.</small>
                            </div>

                            <div class="wpsa-info-callout" style="margin-top: 12px; padding: 10px 14px; background: #fff7ed; border-left: 4px solid #f97316; border-radius: 4px;">
                                <div style="display: flex; gap: 8px; align-items: center;">
                                    <span class="dashicons dashicons-yes-alt" style="color: #ea580c;"></span>
                                    <span style="font-size: 13px; color: #9a3412;">
                                        <strong>100% Jamstack & Privacy-Friendly:</strong> A diferencia de Google reCAPTCHA, Turnstile respeta la privacidad de los visitantes, no usa cookies invasivas y valida silenciosamente la humanidad del usuario antes de registrar el comentario en Supabase.
                                    </span>
                                </div>
                            </div>

                            <div style="margin-top: 16px;">
                                <?php submit_button( 'Guardar Clave de Turnstile', 'secondary', 'submit', false ); ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==================== TAB 5: BANDEJA DE MODERACIÓN DE COMENTARIOS ==================== -->
        <div id="tab-moderation" class="wpsa-tab-pane">
            <div class="wpsa-card">
                <div class="wpsa-card-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                    <div>
                        <h2>Moderación de Comentarios en Supabase</h2>
                        <p>Visualiza, aprueba o elimina comentarios enviados desde el frontend estático.</p>
                    </div>
                    <div class="wpsa-moderation-filters" style="display: flex; gap: 8px; align-items: center;">
                        <button type="button" class="button wpsa-filter-btn button-primary active" data-status="all">Todos</button>
                        <button type="button" class="button wpsa-filter-btn" data-status="pending">Pendientes</button>
                        <button type="button" class="button wpsa-filter-btn" data-status="approved">Aprobados</button>
                        <button type="button" id="btn-reload-comments" class="button button-secondary" title="Recargar comentarios">
                            <span class="dashicons dashicons-update"></span>
                        </button>
                    </div>
                </div>
                <div class="wpsa-card-body">
                    <div id="wpsa-comments-moderation-wrapper">
                        <div class="wpsa-loading-comments" style="text-align: center; padding: 40px; color: #64748b;">
                            <span class="dashicons dashicons-update" style="animation: wpsa-spin 1s linear infinite;"></span> Cargando comentarios de Supabase...
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==================== TAB 6: GUÍA & RECORRIDO VISUAL ==================== -->
        <div id="tab-guide" class="wpsa-tab-pane">

            <!-- Banner Oficial de Bienvenida y Arquitectura -->
            <div class="wpsa-banner-card">
                <img src="<?php echo esc_url( WP_STATIC_ARQUITECT_URL . 'admin/assets/images/banner.svg' ); ?>" alt="WP Static Architect - Guía Visual y Arquitectura" class="wpsa-banner-img">
            </div>
            
            <!-- Hero Banner de la Guía -->
            <div class="wpsa-guide-hero">
                <div class="wpsa-guide-hero-content">
                    <div class="wpsa-hero-tag">
                        <span class="dashicons dashicons-awards"></span> Arquitectura Jamstack & Serverless para WordPress
                    </div>
                    <h2>Centro de Ayuda & Recorrido Visual de WP Static Architect</h2>
                    <p>Descubre cómo convertir tu WordPress dinámico en un sitio estático ultra-rápido, 100% inmune a ataques y listo para producción en Netlify, preservando formularios de contacto y comentarios en tiempo real mediante Supabase.</p>
                    <div class="wpsa-hero-actions">
                        <button type="button" class="button button-primary button-hero wpsa-btn-start-tour">
                            <span class="dashicons dashicons-controls-play"></span> Iniciar Recorrido Interactivo Guiado
                        </button>
                        <a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer" class="button button-secondary button-hero wpsa-hero-author-link">
                            <span class="dashicons dashicons-admin-site-alt3"></span> Desarrollado por Xavier Cabello
                        </a>
                    </div>
                </div>
                <div class="wpsa-guide-hero-graphic">
                    <div class="wpsa-graphic-card">
                        <div class="wpsa-graphic-header">
                            <span class="wpsa-dot red"></span>
                            <span class="wpsa-dot yellow"></span>
                            <span class="wpsa-dot green"></span>
                            <span class="wpsa-graphic-title">wp-static-pipeline.json</span>
                        </div>
                        <div class="wpsa-graphic-body">
                            <code>{
  "crawler": "Batch Engine (Anti-Timeout)",
  "hosting": "Multi-Hosting (Netlify, CF, Vercel, GH)",
  "domain": "Zero-Code Custom Domain (DNS A/CNAME)",
  "geo_ai": "llms.txt + Schema JSON-LD + AI Bots",
  "modularity": "Pure Brochure HTML (Forms/Comments Optional)",
  "search": "Spotlight (Ctrl+K, 0 deps)",
  "deploy": "1-Click Binary Deploy API + CLI",
  "status": "Production Ready"
}</code>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pipeline de Arquitectura Visual -->
            <div class="wpsa-card wpsa-pipeline-card">
                <div class="wpsa-card-header">
                    <h2><span class="dashicons dashicons-networking"></span> Flujo de la Arquitectura Estática (5 Etapas)</h2>
                    <p>Comprende cómo fluyen tus contenidos desde WordPress hasta las redes globales edge con optimización para IAs y funciones serverless.</p>
                </div>
                <div class="wpsa-card-body">
                    <div class="wpsa-pipeline-grid">
                        <div class="wpsa-pipeline-node">
                            <div class="wpsa-node-icon bg-blue">
                                <span class="dashicons dashicons-wordpress"></span>
                            </div>
                            <span class="wpsa-node-step">Etapa 1</span>
                            <h4>WordPress Dinámico</h4>
                            <p>Tus páginas, entradas, Gutenberg, Elementor, menús y medios en tu servidor local o staging habitual.</p>
                        </div>

                        <div class="wpsa-pipeline-arrow">
                            <span class="dashicons dashicons-arrow-right-alt"></span>
                        </div>

                        <div class="wpsa-pipeline-node">
                            <div class="wpsa-node-icon bg-indigo">
                                <span class="dashicons dashicons-rest-api"></span>
                            </div>
                            <span class="wpsa-node-step">Etapa 2</span>
                            <h4>Motor Batch Anti-Timeout</h4>
                            <p>Rastreo recursivo asíncrono en bloques, reescritura DOM a enlaces relativos y optimización de assets locales.</p>
                        </div>

                        <div class="wpsa-pipeline-arrow">
                            <span class="dashicons dashicons-arrow-right-alt"></span>
                        </div>

                        <div class="wpsa-pipeline-node">
                            <div class="wpsa-node-icon bg-purple">
                                <span class="dashicons dashicons-superhero-alt"></span>
                            </div>
                            <span class="wpsa-node-step">Etapa 3</span>
                            <h4>GEO & Modularidad</h4>
                            <p>Generación de <code>llms.txt</code> para IAs, directivas en <code>robots.txt</code>, Schema JSON-LD y limpieza total de HTML para brochure.</p>
                        </div>

                        <div class="wpsa-pipeline-arrow">
                            <span class="dashicons dashicons-arrow-right-alt"></span>
                        </div>

                        <div class="wpsa-pipeline-node">
                            <div class="wpsa-node-icon bg-amber">
                                <span class="dashicons dashicons-media-archive"></span>
                            </div>
                            <span class="wpsa-node-step">Etapa 4</span>
                            <h4>Artefactos Multi-Hosting</h4>
                            <p>Empaquetado ZIP con SHA-256, <code>_routes.json</code>, <code>vercel.json</code>, <code>.nojekyll</code>, <code>CNAME</code>, <code>_redirects</code> y <code>_headers</code>.</p>
                        </div>

                        <div class="wpsa-pipeline-arrow">
                            <span class="dashicons dashicons-arrow-right-alt"></span>
                        </div>

                        <div class="wpsa-pipeline-node">
                            <div class="wpsa-node-icon bg-green">
                                <span class="dashicons dashicons-cloud-saved"></span>
                            </div>
                            <span class="wpsa-node-step">Etapa 5</span>
                            <h4>Nube Serverless Global</h4>
                            <p>1-Click Deploy a Netlify, Cloudflare Pages o Vercel, formularios con purga y comentarios Supabase RLS.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pasos Guiados Detallados -->
            <div class="wpsa-card">
                <div class="wpsa-card-header">
                    <h2><span class="dashicons dashicons-clipboard"></span> Recorrido Paso a Paso para Nuevos Usuarios (6 Fases)</h2>
                    <p>Sigue estos 6 pasos ordenados para poner en marcha tu primer sitio estático profesional en cuestión de minutos.</p>
                </div>
                <div class="wpsa-card-body">
                    <div class="wpsa-steps-list">

                        <!-- Paso 1 -->
                        <div class="wpsa-step-item">
                            <div class="wpsa-step-number">1</div>
                            <div class="wpsa-step-details">
                                <div class="wpsa-step-title-row">
                                    <h3>Configurar Destino de Hosting, Dominio Canónico & APIs</h3>
                                    <span class="wpsa-badge-pill">Esencial</span>
                                </div>
                                <p>Selecciona tu proveedor de alojamiento (Netlify, Cloudflare Pages, Vercel, GitHub Pages o Servidor Tradicional) y escribe tu dominio personalizado:</p>
                                <ul class="wpsa-checklist">
                                    <li><strong>Destino de Hosting:</strong> Configura la plataforma. El exportador generará automáticamente <code>_routes.json</code>, <code>vercel.json</code>, <code>.nojekyll</code>, <code>CNAME</code> o <code>_redirects</code>.</li>
                                    <li><strong>Dominio Sin Código & Asistente DNS:</strong> Escribe tu dominio (ej. <code>miempresa.com</code>) y consulta los registros Tipo A y CNAME a crear en tu registrador.</li>
                                    <li><strong>Credenciales Netlify & Supabase:</strong> Ingresa tus tokens para habilitar el despliegue automático, la purga de formularios y los comentarios dinámicos.</li>
                                </ul>
                                <div class="wpsa-step-action-row">
                                    <button type="button" class="button button-primary wpsa-jump-tab" data-jump="tab-config">
                                        <span class="dashicons dashicons-admin-settings"></span> Ir a Hosting, Dominio & APIs
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Paso 2 -->
                        <div class="wpsa-step-item">
                            <div class="wpsa-step-number">2</div>
                            <div class="wpsa-step-details">
                                <div class="wpsa-step-title-row">
                                    <h3>Ajustar Modularidad, Motor GEO (llms.txt) y Buscador Spotlight</h3>
                                    <span class="wpsa-badge-pill">Inteligencia Artificial</span>
                                </div>
                                <p>Prepara tu sitio para la era de la IA generativa, optimiza la búsqueda y ajusta la limpieza del código generado:</p>
                                <ul class="wpsa-checklist">
                                    <li><strong>GEO (llms.txt):</strong> Activa la generación de <code>llms.txt</code> estructurado en Markdown y directivas para GPTBot, ClaudeBot y PerplexityBot para destacar en respuestas de ChatGPT y Perplexity.</li>
                                    <li><strong>Buscador Spotlight Client-Side:</strong> Genera un índice estático <code>search-index.json</code> y una interfaz flotante tipo macOS (Ctrl+K / Cmd+K) sin dependencias externas.</li>
                                    <li><strong>Modularidad de Formularios y Comentarios:</strong> Si tu sitio es meramente corporativo, desactiva las casillas para generar un HTML 100% puro sin contenedores JS innecesarios.</li>
                                </ul>
                                <div class="wpsa-step-action-row">
                                    <button type="button" class="button button-primary wpsa-jump-tab" data-jump="tab-advanced">
                                        <span class="dashicons dashicons-superhero-alt"></span> Configurar GEO & Buscador
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Paso 3 -->
                        <div class="wpsa-step-item">
                            <div class="wpsa-step-number">3</div>
                            <div class="wpsa-step-details">
                                <div class="wpsa-step-title-row">
                                    <h3>Inicializar la Base de Datos de Comentarios en Supabase</h3>
                                    <span class="wpsa-badge-pill">Serverless PostgreSQL</span>
                                </div>
                                <p>Supabase gestiona los comentarios en tiempo real mediante PostgreSQL y PostgREST sin tocar PHP:</p>
                                <ul class="wpsa-checklist">
                                    <li><strong>Opción Automática (1 Clic):</strong> Con tu Service Role Key configurada, haz clic en el botón <em>Crear Tablas Automáticamente en Supabase</em> en la pestaña de Supabase.</li>
                                    <li><strong>Opción Manual (SQL Editor):</strong> Si prefieres ejecutarlo manualmente, copia el script SQL provisto con un solo clic y pégalo en el <em>SQL Editor</em> de Supabase.</li>
                                    <li><strong>Políticas RLS (Row Level Security):</strong> Garantizan que el público solo pueda leer comentarios marcados como aprobados (<code>is_approved = true</code>) y enviar nuevos mensajes anónimos.</li>
                                </ul>
                                <div class="wpsa-step-action-row">
                                    <button type="button" class="button button-primary wpsa-jump-tab" data-jump="tab-supabase">
                                        <span class="dashicons dashicons-admin-comments"></span> Ir a Supabase & SQL
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Paso 4 -->
                        <div class="wpsa-step-item">
                            <div class="wpsa-step-number">4</div>
                            <div class="wpsa-step-details">
                                <div class="wpsa-step-title-row">
                                    <h3>Diagnóstico de Salud (Pre-flight Check) & Exportación por Lotes</h3>
                                    <span class="wpsa-badge-pill">Anti-Timeout Engine</span>
                                </div>
                                <p>Verifica el entorno de tu servidor y genera el sitio estático sin caídas de memoria ni timeouts:</p>
                                <ul class="wpsa-checklist">
                                    <li><strong>Pre-flight Check:</strong> El panel audita automáticamente 8 parámetros de tu servidor (PHP >= 7.4, ZipArchive, DOMDocument, cURL, Mbstring, permisos de escritura y Pretty Permalinks).</li>
                                    <li><strong>Procesamiento en Chunks:</strong> El motor rastrea tu sitio en bloques recursivos comunicándose vía AJAX con WordPress Transients, evitando límites de <code>max_execution_time</code>.</li>
                                    <li><strong>Copia Directa en Disco:</strong> Las imágenes, estilos CSS, tipografías y scripts se copian directamente desde el sistema de archivos local de WordPress a máxima velocidad sin descargas HTTP innecesarias.</li>
                                    <li><strong>Generación de Artefactos de Hosting:</strong> Inyección automática de <code>_routes.json</code>, <code>vercel.json</code>, <code>.nojekyll</code>, <code>CNAME</code> o <code>_redirects</code> según el proveedor elegido.</li>
                                </ul>
                                <div class="wpsa-step-action-row">
                                    <button type="button" class="button button-primary wpsa-jump-tab" data-jump="tab-export">
                                        <span class="dashicons dashicons-media-archive"></span> Ir al Exportador Estático
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Paso 5 -->
                        <div class="wpsa-step-item">
                            <div class="wpsa-step-number">5</div>
                            <div class="wpsa-step-details">
                                <div class="wpsa-step-title-row">
                                    <h3>Despliegue Multi-Hosting (1 Clic) o Automatización por WP-CLI</h3>
                                    <span class="wpsa-badge-pill">Automatización CI/CD</span>
                                </div>
                                <p>Publica tu sitio estático en la red Edge global de Netlify, Cloudflare Pages, Vercel, GitHub Pages o tu propio servidor:</p>
                                <ul class="wpsa-checklist">
                                    <li><strong>1-Click Deploy Directo a Netlify:</strong> Pulsa <em>Desplegar ahora a Netlify</em> para transmitir el archivo ZIP generado directamente a la Deploy API v1 de Netlify con monitoreo en tiempo real.</li>
                                    <li><strong>Comando WP-CLI para Terminal y Cron:</strong> Puedes exportar y desplegar mediante línea de comandos desde SSH o cron jobs de servidor:
                                        <div class="wpsa-cli-quick-box" style="margin-top: 6px; display: inline-flex; align-items: center; gap: 8px; background: #0f172a; padding: 5px 12px; border-radius: 6px;">
                                            <code style="color: #38bdf8; background: transparent; padding: 0;">wp static-architect export --deploy</code>
                                            <button type="button" class="button button-small wpsa-inline-copy-btn" data-copy-text="wp static-architect export --deploy" title="Copiar comando WP-CLI">
                                                <span class="dashicons dashicons-clipboard"></span> <span>Copiar Comando</span>
                                            </button>
                                        </div>
                                    </li>
                                    <li><strong>Subida a Cloudflare Pages, Vercel o GitHub:</strong> Conecta tu repositorio Git con la carpeta exportada o usa Wrangler / Vercel CLI sin configuraciones complejas.</li>
                                </ul>
                                <div class="wpsa-step-action-row">
                                    <button type="button" class="button button-primary wpsa-jump-tab" data-jump="tab-netlify">
                                        <span class="dashicons dashicons-cloud-upload"></span> Ir a Netlify & Despliegue
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Paso 6 -->
                        <div class="wpsa-step-item">
                            <div class="wpsa-step-number">6</div>
                            <div class="wpsa-step-details">
                                <div class="wpsa-step-title-row">
                                    <h3>Formularios Serverless, Moderación y Purgador de Cuota</h3>
                                    <span class="wpsa-badge-pill">Gestión Continua</span>
                                </div>
                                <p>Tu sitio estático mantiene la interactividad dinámica sin necesidad de mantener un servidor PHP expuesto:</p>
                                <ul class="wpsa-checklist">
                                    <li><strong>Formularios Netlify:</strong> Cualquier formulario existente recibe automáticamente los atributos <code>data-netlify="true"</code> y campos anti-spam.</li>
                                    <li><strong>Purgador Automático:</strong> El cron job semanal previene exceder la cuota gratuita de Netlify (80 envíos o 8MB) eliminando las solicitudes más antiguas (desactivable en Modo Empresa).</li>
                                    <li><strong>Bandeja de Moderación:</strong> Revisa todos los comentarios recibidos de Supabase en la pestaña <em>Bandeja de Comentarios</em>. Filtra entre pendientes y aprobados, apruébalos o elimínalos con un solo clic.</li>
                                </ul>
                                <div class="wpsa-step-action-row">
                                    <button type="button" class="button button-primary wpsa-jump-tab" data-jump="tab-moderation">
                                        <span class="dashicons dashicons-format-chat"></span> Ir a Bandeja de Comentarios
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Preguntas Frecuentes y Consejos Pro -->
            <div class="wpsa-card">
                <div class="wpsa-card-header">
                    <h2><span class="dashicons dashicons-editor-help"></span> Preguntas Frecuentes y Consejos Pro</h2>
                    <p>Respuestas rápidas a las consultas más comunes al trabajar con sitios estáticos en WordPress.</p>
                </div>
                <div class="wpsa-card-body">
                    <div class="wpsa-faq-list">
                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <strong>¿Qué ocurre si publico un nuevo post o edito una página en WordPress?</strong>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p>Tu sitio estático en Netlify es independiente de tu WordPress dinámico. Para reflejar cambios o nuevo contenido, simplemente dirígete a la pestaña <strong>Exportador Estático</strong>, pulsa <strong>Iniciar Exportación Estática</strong> y luego <strong>Desplegar ahora a Netlify</strong> (o activa el auto-despliegue para que ocurra solo).</p>
                            </div>
                        </div>

                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <strong>¿Mis formularios de Contact Form 7, WPForms o Elementor funcionarán sin PHP?</strong>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p>¡Sí! El analizador DOM de WP Static Architect detecta las etiquetas <code>&lt;form&gt;</code> e inyecta los atributos necesarios para que Netlify capture automáticamente los envíos directamente en su panel de control, enviándote notificaciones por email o webhooks sin requerir PHP ni plugins activos en el frontend.</p>
                            </div>
                        </div>

                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <strong>¿Es seguro exponer la Anon Key de Supabase en los archivos estáticos?</strong>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p>Absolutamente. La <code>anon_key</code> está diseñada específicamente por Supabase para uso público en el navegador. La seguridad de los datos está blindada por las políticas de seguridad a nivel de fila (Row Level Security - RLS). La <code>service_role_key</code> (clave maestra) nunca se incluye en el sitio estático y permanece almacenada exclusivamente en tu servidor WordPress para la moderación administrativa.</p>
                            </div>
                        </div>

                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <strong>¿Cómo se gestionan las páginas de error 404 y redirecciones en Netlify?</strong>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p>WP Static Architect captura automáticamente el diseño nativo de la plantilla 404 de tu tema activo de WordPress y crea un archivo <code>404.html</code> estático. Además, genera automáticamente los archivos <code>_redirects</code> y <code>_headers</code> con caché optimizada y cabeceras de seguridad para Netlify.</p>
                            </div>
                        </div>

                        <!-- Pregunta 6 -->
                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <h4>¿Qué es la Optimización GEO y por qué se genera <code>llms.txt</code>?</h4>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p><strong>GEO (Generative Engine Optimization)</strong> es la evolución del SEO tradicional para modelos de Inteligencia Artificial como <strong>ChatGPT, Claude, Perplexity y Gemini</strong>. El estándar <code>llms.txt</code> proporciona un resumen conciso y enlaces prioritarios en Markdown limpio para que los modelos de lenguaje procesen tu sitio sin sobrecargar sus ventanas de contexto. Además, WP Static Architect inyecta datos estructurados Schema.org (JSON-LD) y directivas específicas en <code>robots.txt</code> para que las IAs atribuyan tus contenidos con máxima precisión.</p>
                            </div>
                        </div>

                        <!-- Pregunta 7 -->
                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <h4>¿Puedo exportar a Cloudflare Pages, Vercel o GitHub Pages además de Netlify?</h4>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p><strong>¡Sí, totalmente!</strong> En la pestaña <em>Hosting, Dominio & APIs</em> puedes seleccionar tu destino favorito. El plugin empaquetará automáticamente los archivos requeridos por cada proveedor: <code>_routes.json</code> para Cloudflare Pages, <code>vercel.json</code> con <code>cleanUrls</code> para Vercel, <code>.nojekyll</code> y <code>CNAME</code> para GitHub Pages, o <code>.htaccess</code> para servidores Apache tradicionales.</p>
                            </div>
                        </div>

                        <!-- Pregunta 8 -->
                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <h4>¿Cómo funciona el Gestor de Dominio Personalizado Sin Código?</h4>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p>Solo tienes que escribir tu dominio (ej. <code>miempresa.com</code>) en la pestaña de Hosting. El plugin generará el archivo <code>CNAME</code>, reescribirá el <code>sitemap.xml</code>, <code>robots.txt</code>, OpenGraph y datos estructurados Schema.org con esta URL canónica. Además, incluye una tabla visual con los registros DNS necesarios (Tipo A y CNAME) y un botón de <strong>1 Clic</strong> para vincularlo automáticamente a tu cuenta de Netlify mediante su API oficial.</p>
                            </div>
                        </div>

                        <!-- Pregunta 9 -->
                        <div class="wpsa-faq-item">
                            <div class="wpsa-faq-question">
                                <h4>¿Puedo generar un sitio corporativo o de catálogo 100% limpio sin formularios ni comentarios?</h4>
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                            </div>
                            <div class="wpsa-faq-answer">
                                <p><strong>Por supuesto.</strong> WP Static Architect es 100% modular. Si tu web es un catálogo o brochure institucional y no requiere captura de leads ni foros, simplemente desmarca las casillas de formularios o comentarios. El exportador no modificará tus etiquetas <code>&lt;form&gt;</code>, eliminará por completo los contenedores <code>#comments</code> del HTML y omitirá la carga de cualquier script de Supabase, obteniendo un sitio ultraligero y con cero código muerto.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tarjeta Estratégica del Desarrollador -->
            <div class="wpsa-card wpsa-developer-showcase-card">
                <div class="wpsa-dev-card-inner">
                    <div class="wpsa-dev-avatar-box">
                        <div class="wpsa-dev-avatar">
                            <span class="dashicons dashicons-businessman"></span>
                        </div>
                        <div class="wpsa-dev-badge-verified">
                            <span class="dashicons dashicons-yes"></span> Creador Oficial
                        </div>
                    </div>
                    <div class="wpsa-dev-info">
                        <div class="wpsa-dev-header">
                            <div>
                                <span class="wpsa-dev-subtitle">Arquitectura y Desarrollo de Software</span>
                                <h2 class="wpsa-dev-name">Desarrollado por Xavier Cabello</h2>
                            </div>
                            <a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer" class="button button-primary wpsa-dev-visit-btn">
                                <span class="dashicons dashicons-admin-site-alt3"></span>
                                <span>juan.cabellosalirrosas.com</span>
                                <span class="dashicons dashicons-external"></span>
                            </a>
                        </div>
                        <p class="wpsa-dev-bio">
                            Especialista en ingeniería de rendimiento web, arquitecturas Jamstack, soluciones sin servidor (*serverless*) y modernización de infraestructuras WordPress. <strong>WP Static Architect</strong> fue concebido y desarrollado para ofrecer una transición fluida y de grado profesional desde WordPress monolítico hacia la velocidad y seguridad del hosting estático distribuido.
                        </p>
                        <div class="wpsa-dev-links">
                            <a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer" class="wpsa-dev-link-pill">
                                <span class="dashicons dashicons-laptop"></span> Sitio Web Oficial: <strong>juan.cabellosalirrosas.com</strong>
                            </a>
                            <span class="wpsa-dev-link-pill pill-tech">
                                <span class="dashicons dashicons-admin-generic"></span> WordPress &bull; Netlify &bull; Supabase &bull; Jamstack
                            </span>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <!-- Terminal de Logs de Actividad en Tiempo Real -->
    <div class="wpsa-card wpsa-console-card">
        <div class="wpsa-card-header wpsa-console-header">
            <div>
                <h3><span class="dashicons dashicons-terminal"></span> Registro de Actividad y Salida de Procesos</h3>
            </div>
            <div class="wpsa-console-actions">
                <button type="button" id="btn-refresh-logs" class="button button-small">
                    <span class="dashicons dashicons-update"></span> Actualizar
                </button>
                <button type="button" id="btn-clear-logs" class="button button-small">
                    <span class="dashicons dashicons-trash"></span> Limpiar
                </button>
            </div>
        </div>
        <div class="wpsa-console-body">
            <div id="wpsa-terminal-log" class="wpsa-terminal">
                <?php
                $logs = WP_Static_Arquitect::get_recent_logs();
                if ( ! empty( $logs ) ) :
                    foreach ( array_reverse( $logs ) as $log ) :
                        $type_class = 'log-' . sanitize_html_class( $log['type'] );
                        ?>
                        <div class="wpsa-log-row <?php echo esc_attr( $type_class ); ?>">
                            <span class="log-time">[<?php echo esc_html( $log['time'] ); ?>]</span>
                            <span class="log-badge">[<?php echo esc_html( strtoupper( $log['type'] ) ); ?>]</span>
                            <span class="log-msg"><?php echo esc_html( $log['message'] ); ?></span>
                        </div>
                        <?php
                    endforeach;
                else :
                    ?>
                    <div class="wpsa-log-empty">No hay registros de actividad aún. Inicia una exportación o purga para ver la salida aquí.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- ==================== MODAL DE RECORRIDO VISUAL INTERACTIVO ==================== -->
    <div id="wpsa-tour-modal-backdrop" class="wpsa-modal-backdrop" style="display:none;">
        <div class="wpsa-tour-modal-container">
            <div class="wpsa-tour-modal">
                <div class="wpsa-tour-modal-header">
                    <div class="wpsa-tour-header-title">
                        <span class="dashicons dashicons-welcome-learn-more"></span>
                        <h3>Recorrido Guiado: WP Static Architect</h3>
                    </div>
                    <button type="button" class="wpsa-tour-close-btn" id="btn-close-tour" title="Cerrar recorrido">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>

                <div class="wpsa-tour-modal-body">
                    
                    <!-- Diapositiva 1 -->
                    <div class="wpsa-tour-slide active" data-slide="1">
                        <div class="wpsa-tour-banner-preview" style="margin-bottom: 16px; border-radius: 10px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 4px 12px rgba(0,0,0,0.06);">
                            <img src="<?php echo esc_url( WP_STATIC_ARQUITECT_URL . 'admin/assets/images/banner.svg' ); ?>" alt="WP Static Architect" style="width: 100%; height: auto; display: block;">
                        </div>
                        <div class="wpsa-slide-badge">Paso 1 de 6</div>
                        <div class="wpsa-slide-icon bg-indigo">
                            <span class="dashicons dashicons-cloud-saved"></span>
                        </div>
                        <h3>¡Bienvenido a WP Static Architect!</h3>
                        <p class="wpsa-slide-desc">
                            Este plugin transforma tu WordPress dinámico en un paquete <strong>100% estático</strong> (HTML, CSS, JS e imágenes). Obtén <strong>máxima velocidad de carga</strong>, <strong>inmunidad total ante hackeos</strong> y costes de infraestructura mínimos o nulos.
                        </p>
                        <div class="wpsa-slide-feature-box">
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-yes-alt"></span> <strong>Multi-Hosting:</strong> Compatible con Netlify, Cloudflare Pages, Vercel y GitHub Pages.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-yes-alt"></span> <strong>GEO para IAs:</strong> Genera <code>llms.txt</code> y prepara tu contenido para ChatGPT, Claude y Perplexity.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-yes-alt"></span> <strong>Modularidad Absoluta:</strong> Desactiva formularios o comentarios si tu sitio es puramente informativo.
                            </div>
                        </div>
                    </div>

                    <!-- Diapositiva 2 -->
                    <div class="wpsa-tour-slide" data-slide="2">
                        <div class="wpsa-slide-badge">Paso 2 de 6</div>
                        <div class="wpsa-slide-icon bg-blue">
                            <span class="dashicons dashicons-networking"></span>
                        </div>
                        <h3>Multi-Hosting & Dominio Sin Código</h3>
                        <p class="wpsa-slide-desc">
                            Elige tu destino de alojamiento estático favorito y define tu propio dominio canónico directamente desde el panel sin tocar archivos de configuración.
                        </p>
                        <div class="wpsa-slide-feature-box">
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Adaptadores Automáticos:</strong> Genera <code>_redirects</code>/<code>_headers</code> (Netlify), <code>_routes.json</code> (Cloudflare), <code>vercel.json</code> (Vercel) o <code>.nojekyll</code>/<code>CNAME</code> (GitHub).
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Asistente Visual DNS:</strong> Consulta la guía de registros Tipo A y CNAME para tu proveedor de dominio.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>1-Clic Netlify Link:</strong> Registra tu dominio automáticamente en la API de Netlify con un solo botón.
                            </div>
                        </div>
                        <div class="wpsa-slide-action">
                            <button type="button" class="button button-secondary wpsa-jump-tab" data-jump="tab-config">Ir a Hosting & Dominio</button>
                        </div>
                    </div>

                    <!-- Diapositiva 3 -->
                    <div class="wpsa-tour-slide" data-slide="3">
                        <div class="wpsa-slide-badge">Paso 3 de 6</div>
                        <div class="wpsa-slide-icon bg-purple">
                            <span class="dashicons dashicons-superhero-alt"></span>
                        </div>
                        <h3>Optimización GEO (Generative Engine Optimization)</h3>
                        <p class="wpsa-slide-desc">
                            Prepara tu web para que los motores de Inteligencia Artificial (ChatGPT Search, Claude, Perplexity y Gemini) descubran, comprendan y citen tus contenidos con autoridad.
                        </p>
                        <div class="wpsa-slide-feature-box">
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Estándar <code>llms.txt</code>:</strong> Genera un mapa semántico en markdown limpio en la raíz de tu web.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Rastreadores de IA:</strong> Reglas claras en <code>robots.txt</code> para GPTBot, ClaudeBot, PerplexityBot y Applebot.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Schema.org JSON-LD:</strong> Inyección automática de metadatos estructurados en cada página HTML.
                            </div>
                        </div>
                        <div class="wpsa-slide-action">
                            <button type="button" class="button button-secondary wpsa-jump-tab" data-jump="tab-advanced">Configurar GEO & SEO</button>
                        </div>
                    </div>

                    <!-- Diapositiva 4 -->
                    <div class="wpsa-tour-slide" data-slide="4">
                        <div class="wpsa-slide-badge">Paso 4 de 6</div>
                        <div class="wpsa-slide-icon bg-amber">
                            <span class="dashicons dashicons-filter"></span>
                        </div>
                        <h3>Modularidad & Perfiles de Cuota</h3>
                        <p class="wpsa-slide-desc">
                            Adapta el exportador a las necesidades exactas de tu proyecto:
                        </p>
                        <div class="wpsa-slide-feature-box">
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Sitios Corporativos / Brochure:</strong> Desactiva formularios o comentarios para exportar un HTML puro sin scripts ni contenedores vacíos.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Modo Creador Pro (Ilimitado):</strong> Máxima potencia desbloqueada de extremo a extremo, sin límites de cuotas, retención histórica completa y aceleración de empaquetado.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Perfil Estándar:</strong> Optimizado para planes con purga preventiva programada para no saturar cuotas en plataformas de terceros.
                            </div>
                        </div>
                        <div class="wpsa-slide-action">
                            <button type="button" class="button button-secondary wpsa-jump-tab" data-jump="tab-config">Ajustar Perfil de Servicio</button>
                        </div>
                    </div>

                    <!-- Diapositiva 5 -->
                    <div class="wpsa-tour-slide" data-slide="5">
                        <div class="wpsa-slide-badge">Paso 5 de 6</div>
                        <div class="wpsa-slide-icon bg-blue">
                            <span class="dashicons dashicons-search"></span>
                        </div>
                        <h3>Buscador Spotlight & Comentarios Supabase</h3>
                        <p class="wpsa-slide-desc">
                            Funcionalidades dinámicas de última generación sin librerías pesadas ni dependencias npm:
                        </p>
                        <div class="wpsa-slide-feature-box">
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Buscador Spotlight (Ctrl + K):</strong> Búsqueda cliente instantánea indexada en <code>search-index.json</code> con diseño Glassmorphism claro/oscuro.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Comentarios en Tiempo Real:</strong> Conectados a Supabase PostgREST con políticas de seguridad RLS.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Anti-Spam Cloudflare Turnstile:</strong> Verificación silenciosa e invisible sin captchas molestos.
                            </div>
                        </div>
                        <div class="wpsa-slide-action">
                            <button type="button" class="button button-secondary wpsa-jump-tab" data-jump="tab-advanced">Ver Buscador Spotlight</button>
                        </div>
                    </div>

                    <!-- Diapositiva 6 -->
                    <div class="wpsa-tour-slide" data-slide="6">
                        <div class="wpsa-slide-badge">Paso 6 de 6</div>
                        <div class="wpsa-slide-icon bg-green">
                            <span class="dashicons dashicons-airplane"></span>
                        </div>
                        <h3>Motor por Lotes Anti-Timeout & Despliegue Directo</h3>
                        <p class="wpsa-slide-desc">
                            Exporta sitios grandes sin caídas de servidor y publica en la nube con 1 solo clic:
                        </p>
                        <div class="wpsa-slide-feature-box">
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Procesamiento Asíncrono:</strong> Procesa URLs por bloques con barra de progreso y consola de logs en vivo.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>Pre-Flight Check:</strong> Diagnóstico integrado que verifica los 8 requisitos de tu servidor antes de iniciar.
                            </div>
                            <div class="wpsa-feature-item">
                                <span class="dashicons dashicons-arrow-right"></span> <strong>1-Click Deploy API & WP-CLI:</strong> Despliega directo a Netlify o automatiza con el comando <code>wp static-architect export</code>.
                            </div>
                        </div>
                        <div class="wpsa-slide-action">
                            <button type="button" class="button button-primary wpsa-jump-tab" data-jump="tab-export">¡Iniciar Mi Primera Exportación!</button>
                        </div>
                    </div>

                </div>

                <div class="wpsa-tour-modal-footer">
                    <div class="wpsa-tour-dots">
                        <span class="wpsa-tour-dot active" data-slide="1"></span>
                        <span class="wpsa-tour-dot" data-slide="2"></span>
                        <span class="wpsa-tour-dot" data-slide="3"></span>
                        <span class="wpsa-tour-dot" data-slide="4"></span>
                        <span class="wpsa-tour-dot" data-slide="5"></span>
                        <span class="wpsa-tour-dot" data-slide="6"></span>
                    </div>
                    <div class="wpsa-tour-nav-btns">
                        <button type="button" class="button button-secondary" id="btn-tour-prev" disabled>
                            <span class="dashicons dashicons-arrow-left-alt2"></span> Anterior
                        </button>
                        <button type="button" class="button button-primary" id="btn-tour-next">
                            Siguiente <span class="dashicons dashicons-arrow-right-alt2"></span>
                        </button>
                        <button type="button" class="button button-primary" id="btn-tour-finish" style="display:none;">
                            <span class="dashicons dashicons-yes"></span> ¡Entendido, Empezar!
                        </button>
                    </div>
                </div>
            </div><!-- /.wpsa-tour-modal -->
        </div><!-- /.wpsa-tour-modal-container -->
    </div><!-- /#wpsa-tour-modal-backdrop -->

    <!-- Pie de Página del Plugin con Crédito de Xavier Cabello -->
    <footer class="wpsa-admin-footer">
        <div class="wpsa-footer-left">
            <span class="dashicons dashicons-cloud-saved"></span>
            <span><strong>WP Static Architect</strong> v<?php echo esc_html( WP_STATIC_ARQUITECT_VERSION ); ?></span>
            <span class="wpsa-footer-sep">&bull;</span>
            <span>Generador estático y serverless de alto rendimiento</span>
        </div>
        <div class="wpsa-footer-right">
            <span>Desarrollado por <a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer" class="wpsa-author-link"><strong>Xavier Cabello</strong></a></span>
            <span class="wpsa-footer-sep">&bull;</span>
            <a href="https://juan.cabellosalirrosas.com" target="_blank" rel="noopener noreferrer" class="wpsa-author-globe" title="Visitar juan.cabellosalirrosas.com">
                <span class="dashicons dashicons-admin-site-alt3"></span>
                <span>juan.cabellosalirrosas.com</span>
            </a>
        </div>
    </footer>
</div>
