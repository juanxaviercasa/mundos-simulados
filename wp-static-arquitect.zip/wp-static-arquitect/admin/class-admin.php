<?php
/**
 * Controlador de la interfaz de administración y endpoints AJAX.
 *
 * @package WP_Static_Arquitect
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WP_Static_Arquitect_Admin {

	/**
	 * Instancia principal.
	 *
	 * @var WP_Static_Arquitect
	 */
	private $main;

	/**
	 * Slug de la página de menú.
	 */
	const MENU_SLUG = 'wp-static-arquitect';

	/**
	 * Constructor.
	 *
	 * @param WP_Static_Arquitect $main
	 */
	public function __construct( WP_Static_Arquitect $main ) {
		$this->main = $main;

		add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// Endpoints AJAX
		add_action( 'wp_ajax_wpsa_test_netlify', array( $this, 'ajax_test_netlify' ) );
		add_action( 'wp_ajax_wpsa_test_build_hook', array( $this, 'ajax_test_build_hook' ) );
		add_action( 'wp_ajax_wpsa_test_supabase', array( $this, 'ajax_test_supabase' ) );
		add_action( 'wp_ajax_wpsa_bootstrap_supabase', array( $this, 'ajax_bootstrap_supabase' ) );
		add_action( 'wp_ajax_wpsa_start_export', array( $this, 'ajax_start_export' ) );
		add_action( 'wp_ajax_wpsa_batch_init', array( $this, 'ajax_batch_init' ) );
		add_action( 'wp_ajax_wpsa_batch_step', array( $this, 'ajax_batch_step' ) );
		add_action( 'wp_ajax_wpsa_batch_finalize', array( $this, 'ajax_batch_finalize' ) );
		add_action( 'wp_ajax_wpsa_batch_status', array( $this, 'ajax_batch_status' ) );
		add_action( 'wp_ajax_wpsa_deploy_to_netlify', array( $this, 'ajax_deploy_to_netlify' ) );
		add_action( 'wp_ajax_wpsa_deploy_to_provider', array( $this, 'ajax_deploy_to_provider' ) );
		add_action( 'wp_ajax_wpsa_run_site_analyzer', array( $this, 'ajax_run_site_analyzer' ) );
		add_action( 'wp_ajax_wpsa_analyze_with_gemini', array( $this, 'ajax_analyze_with_gemini' ) );
		add_action( 'wp_ajax_wpsa_set_hosting_provider', array( $this, 'ajax_set_hosting_provider' ) );
		add_action( 'wp_ajax_wpsa_apply_combo', array( $this, 'ajax_apply_combo' ) );
		add_action( 'wp_ajax_wpsa_test_pinterest', array( $this, 'ajax_test_pinterest' ) );
		add_action( 'wp_ajax_wpsa_trigger_pinterest_sync', array( $this, 'ajax_trigger_pinterest_sync' ) );
		add_action( 'wp_ajax_wpsa_check_deploy_status', array( $this, 'ajax_check_deploy_status' ) );
		add_action( 'wp_ajax_wpsa_load_admin_comments', array( $this, 'ajax_load_admin_comments' ) );
		add_action( 'wp_ajax_wpsa_moderate_comment', array( $this, 'ajax_moderate_comment' ) );
		add_action( 'wp_ajax_wpsa_delete_comment', array( $this, 'ajax_delete_comment' ) );
		add_action( 'wp_ajax_wpsa_purge_netlify', array( $this, 'ajax_purge_netlify' ) );
		add_action( 'wp_ajax_wpsa_check_new_content', array( $this, 'ajax_check_new_content' ) );
		add_action( 'wp_ajax_wpsa_link_custom_domain_netlify', array( $this, 'ajax_link_custom_domain_netlify' ) );
		add_action( 'wp_ajax_wpsa_get_logs', array( $this, 'ajax_get_logs' ) );
		add_action( 'wp_ajax_wpsa_clear_logs', array( $this, 'ajax_clear_logs' ) );
		add_action( 'wp_ajax_wpsa_test_github_dispatch', array( $this, 'ajax_test_github_dispatch' ) );
		add_action( 'wp_ajax_wpsa_humanize_drip_posts', array( $this, 'ajax_humanize_drip_posts' ) );
		add_action( 'wp_ajax_wpsa_ai_discover_topics', array( $this, 'ajax_ai_discover_topics' ) );
		add_action( 'wp_ajax_wpsa_ai_generate_article', array( $this, 'ajax_ai_generate_article' ) );
		add_action( 'wp_ajax_wpsa_delete_export', array( $this, 'ajax_delete_export' ) );
	}

	/**
	 * Registra el menú de administración en WordPress.
	 */
	public function register_admin_menu() {
		add_menu_page(
			__( 'WP Static Architect', 'wp-static-arquitect' ),
			__( 'Static Architect', 'wp-static-arquitect' ),
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_admin_page' ),
			'dashicons-cloud-saved',
			99
		);
	}

	/**
	 * Registra las opciones de configuración en WordPress.
	 */
	public function register_settings() {
		$settings = array(
			'wp_static_arquitect_netlify_pat',
			'wp_static_arquitect_netlify_site_id',
			'wp_static_arquitect_netlify_threshold_count',
			'wp_static_arquitect_netlify_threshold_mb',
			'wp_static_arquitect_netlify_auto_deploy',
			'wp_static_arquitect_netlify_custom_redirects',
			'wp_static_arquitect_netlify_custom_headers',
			'wp_static_arquitect_supabase_url',
			'wp_static_arquitect_supabase_anon_key',
			'wp_static_arquitect_supabase_service_key',
			'wp_static_arquitect_supabase_auto_approve',
			'wp_static_arquitect_url_mode',
			'wp_static_arquitect_enable_search',
			'wp_static_arquitect_additional_urls',
			'wp_static_arquitect_excluded_urls',
			'wp_static_arquitect_enable_sitemap',
			'wp_static_arquitect_production_url',
			'wp_static_arquitect_deploy_on_save',
			'wp_static_arquitect_netlify_build_hook',
			'wp_static_arquitect_turnstile_site_key',
			'wp_static_arquitect_enable_geo',
			'wp_static_arquitect_llms_full',
			'wp_static_arquitect_enable_forms',
			'wp_static_arquitect_enable_comments',
			'wp_static_arquitect_service_tier',
			'wp_static_arquitect_hosting_provider',
			'wp_static_arquitect_custom_domain',
			'wp_static_arquitect_scheduled_deploy_enabled',
			'wp_static_arquitect_scheduled_deploy_time',
			'wp_static_arquitect_scheduled_deploy_smart_check',
			// Cloudflare Pages
			'wp_static_arquitect_cloudflare_deploy_hook',
			'wp_static_arquitect_cloudflare_account_id',
			'wp_static_arquitect_cloudflare_project_name',
			'wp_static_arquitect_cloudflare_api_token',
			// GitHub Pages / Actions
			'wp_static_arquitect_github_token',
			'wp_static_arquitect_github_repo',
			'wp_static_arquitect_github_branch',
			'wp_static_arquitect_github_workflow',
			// Render
			'wp_static_arquitect_render_deploy_hook',
			// Serverless Forms & Google Sheets
			'wp_static_arquitect_form_provider',
			'wp_static_arquitect_google_sheets_url',
			'wp_static_arquitect_web3forms_key',
			'wp_static_arquitect_formsubmit_email',
			// Pinterest Auto-Pin & Drip-Feed
			'wp_static_arquitect_pinterest_token',
			'wp_static_arquitect_pinterest_board_id',
			'wp_static_arquitect_pinterest_auto_pin',
			'wp_static_arquitect_pinterest_multi_pin',
			'wp_static_arquitect_drip_feed_enabled',
			'wp_static_arquitect_drip_posts_count',
			// Google AI Studio (Gemini)
			'wp_static_arquitect_gemini_api_key',
		);

		foreach ( $settings as $setting ) {
			register_setting( 'wp_static_arquitect_settings_group', $setting );
		}
	}

	/**
	 * Carga estilos y scripts en el panel del plugin.
	 *
	 * @param string $hook
	 */
	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		$asset_version = WP_STATIC_ARQUITECT_VERSION . '.' . ( file_exists( WP_STATIC_ARQUITECT_PATH . 'admin/assets/js/admin.js' ) ? filemtime( WP_STATIC_ARQUITECT_PATH . 'admin/assets/js/admin.js' ) : time() );

		wp_enqueue_style(
			'wpsa-admin-css',
			WP_STATIC_ARQUITECT_URL . 'admin/assets/css/admin.css',
			array(),
			$asset_version
		);

		wp_enqueue_script(
			'wpsa-admin-js',
			WP_STATIC_ARQUITECT_URL . 'admin/assets/js/admin.js',
			array( 'jquery' ),
			$asset_version,
			true
		);

		$stats = $this->main->site_analyzer->gather_site_stats();

		wp_localize_script(
			'wpsa-admin-js',
			'wpsaData',
			array(
				'ajaxUrl'              => admin_url( 'admin-ajax.php' ),
				'nonce'                => wp_create_nonce( 'wpsa_admin_nonce' ),
				'hasForms'             => ! empty( $stats['has_forms'] ),
				'hostingProvider'      => get_option( 'wp_static_arquitect_hosting_provider', 'netlify' ),
				'formProvider'         => get_option( 'wp_static_arquitect_form_provider', 'auto' ),
				'googleSheetsUrl'      => get_option( 'wp_static_arquitect_google_sheets_url', '' ),
				'web3formsKey'         => get_option( 'wp_static_arquitect_web3forms_key', '' ),
				'formsubmitEmail'      => get_option( 'wp_static_arquitect_formsubmit_email', get_option( 'admin_email' ) ),
				'githubToken'          => get_option( 'wp_static_arquitect_github_token', '' ),
				'githubRepo'           => get_option( 'wp_static_arquitect_github_repo', '' ),
				'cloudflareDeployHook' => get_option( 'wp_static_arquitect_cloudflare_deploy_hook', '' ),
				'renderDeployHook'     => get_option( 'wp_static_arquitect_render_deploy_hook', '' ),
				'netlifySiteId'        => get_option( 'wp_static_arquitect_netlify_site_id', '' ),
				'netlifyPat'           => get_option( 'wp_static_arquitect_netlify_pat', '' ),
				'compatibilityMatrix'  => $this->main->site_analyzer->get_compatibility_matrix(),
				'homeUrl'              => untrailingslashit( home_url() ),
				'customDomain'         => get_option( 'wp_static_arquitect_custom_domain', '' ),
				'strings' => array(
					'confirmPurge'     => __( '¿Estás seguro de que deseas purgar envíos antiguos de Netlify ahora?', 'wp-static-arquitect' ),
					'exportInProgress' => __( 'Exportando sitio a estático... Esto puede tomar unos minutos.', 'wp-static-arquitect' ),
					'copySuccess'      => __( '¡Código SQL copiado al portapapeles!', 'wp-static-arquitect' ),
				),
			)
		);
	}

	/**
	 * Renderiza la vista principal del panel de administración.
	 */
	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'No tienes permisos suficientes para acceder a esta página.', 'wp-static-arquitect' ) );
		}

		// Desactivar textos del pie de página nativo de WordPress para evitar que se solapen
		// sobre las tarjetas del panel (el plugin ya cuenta con su propio footer y créditos dedicados).
		add_filter( 'admin_footer_text', '__return_empty_string', 999 );
		add_filter( 'update_footer', '__return_empty_string', 999 );

		require_once WP_STATIC_ARQUITECT_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Realiza un diagnóstico del entorno del servidor y requisitos del sistema.
	 *
	 * @return array
	 */
	public static function get_system_health() {
		$upload_dir = WP_Static_Arquitect::get_upload_dir();
		$memory_limit = ini_get( 'memory_limit' );
		$memory_bytes = wp_convert_hr_to_bytes( $memory_limit );
		$permalink_structure = get_option( 'permalink_structure' );

		$checks = array(
			'php_version' => array(
				'label'   => 'Versión de PHP',
				'value'   => PHP_VERSION,
				'pass'    => version_compare( PHP_VERSION, '7.4', '>=' ),
				'message' => version_compare( PHP_VERSION, '7.4', '>=' ) ? 'Compatible (>= 7.4)' : 'Requiere PHP 7.4 o superior.',
			),
			'ext_zip' => array(
				'label'   => 'Extensión ZipArchive',
				'value'   => class_exists( 'ZipArchive' ) ? 'Instalada' : 'No detectada',
				'pass'    => class_exists( 'ZipArchive' ),
				'message' => class_exists( 'ZipArchive' ) ? 'Generación de .ZIP habilitada' : 'Necesaria para comprimir el paquete estático.',
			),
			'ext_dom' => array(
				'label'   => 'Extensión DOM & LibXML',
				'value'   => class_exists( 'DOMDocument' ) ? 'Instalada' : 'No detectada',
				'pass'    => class_exists( 'DOMDocument' ),
				'message' => class_exists( 'DOMDocument' ) ? 'Reescritura de enlaces activa' : 'Indispensable para el analizador DOM de HTML.',
			),
			'ext_curl' => array(
				'label'   => 'Extensión cURL',
				'value'   => function_exists( 'curl_init' ) ? 'Instalada' : 'No detectada',
				'pass'    => function_exists( 'curl_init' ),
				'message' => function_exists( 'curl_init' ) ? 'Conexiones a APIs activas' : 'Requerida para Netlify y Supabase.',
			),
			'ext_mbstring' => array(
				'label'   => 'Extensión Mbstring',
				'value'   => extension_loaded( 'mbstring' ) ? 'Instalada' : 'No detectada',
				'pass'    => extension_loaded( 'mbstring' ),
				'message' => extension_loaded( 'mbstring' ) ? 'Codificación UTF-8 segura' : 'Recomendada para soporte de acentos y caracteres especiales.',
			),
			'uploads_writable' => array(
				'label'   => 'Directorio de Almacenamiento',
				'value'   => wp_is_writable( $upload_dir ) ? 'Escribible' : 'Solo lectura',
				'pass'    => wp_is_writable( $upload_dir ),
				'message' => wp_is_writable( $upload_dir ) ? 'Permisos correctos en uploads' : 'El directorio de uploads no tiene permisos de escritura.',
			),
			'memory_limit' => array(
				'label'   => 'Límite de Memoria PHP',
				'value'   => $memory_limit,
				'pass'    => $memory_bytes >= 128 * 1024 * 1024,
				'message' => $memory_bytes >= 128 * 1024 * 1024 ? 'Capacidad óptima (>= 128M)' : 'Se recomienda un mínimo de 128M para sitios grandes.',
			),
			'permalinks' => array(
				'label'   => 'Enlaces Permanentes',
				'value'   => ! empty( $permalink_structure ) ? 'Estructurados' : 'Simples (?p=123)',
				'pass'    => ! empty( $permalink_structure ),
				'message' => ! empty( $permalink_structure ) ? 'URLs amigables activas' : 'Se recomienda configurar enlaces permanentes (ej. /%postname%/) para URLs limpias.',
			),
		);

		$total = count( $checks );
		$passed = 0;
		foreach ( $checks as $check ) {
			if ( $check['pass'] ) {
				$passed++;
			}
		}

		return array(
			'checks' => $checks,
			'total'  => $total,
			'passed' => $passed,
			'all_ok' => ( $passed === $total ),
		);
	}

	/**
	 * AJAX: Probar credenciales de Netlify.
	 */
	public function ajax_test_netlify() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		// Permitir probar valores recién introducidos antes de guardar
		if ( isset( $_POST['pat'] ) && isset( $_POST['site_id'] ) ) {
			update_option( 'wp_static_arquitect_netlify_pat', sanitize_text_field( wp_unslash( $_POST['pat'] ) ) );
			update_option( 'wp_static_arquitect_netlify_site_id', sanitize_text_field( wp_unslash( $_POST['site_id'] ) ) );
		}

		$stats = $this->main->netlify_forms->get_submissions_stats();
		if ( $stats['success'] ) {
			wp_send_json_success(
				array(
					'message' => sprintf(
						'¡Conexión exitosa con Netlify! Envíos actuales: %d (%.2f MB en adjuntos).',
						$stats['total_count'],
						$stats['total_mb']
					),
					'stats'   => $stats,
				)
			);
		} else {
			wp_send_json_error( array( 'message' => $stats['message'] ) );
		}
	}

	/**
	 * AJAX: Probar disparador Build Hook de Netlify.
	 */
	public function ajax_test_build_hook() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$hook_url = isset( $_POST['build_hook'] ) ? esc_url_raw( wp_unslash( $_POST['build_hook'] ) ) : get_option( 'wp_static_arquitect_netlify_build_hook', '' );
		if ( empty( $hook_url ) ) {
			wp_send_json_error( array( 'message' => 'Por favor, introduce la URL del Build Hook de Netlify.' ) );
		}

		// Si viene en el POST, guardarlo también
		if ( isset( $_POST['build_hook'] ) ) {
			update_option( 'wp_static_arquitect_netlify_build_hook', $hook_url );
		}

		$result = $this->main->netlify_forms->trigger_build_hook( $hook_url );
		if ( $result['success'] ) {
			wp_send_json_success( array( 'message' => '¡Éxito! Netlify recibió la señal HTTP del Build Hook y ha iniciado un despliegue.' ) );
		} else {
			wp_send_json_error( array( 'message' => 'Error al disparar el Hook: ' . $result['message'] ) );
		}
	}

	/**
	 * AJAX: Vincular dominio personalizado en Netlify API.
	 */
	public function ajax_link_custom_domain_netlify() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$domain = isset( $_POST['domain'] ) ? sanitize_text_field( wp_unslash( $_POST['domain'] ) ) : get_option( 'wp_static_arquitect_custom_domain', '' );
		$domain = preg_replace( '#^https?://#', '', rtrim( $domain, '/' ) );

		if ( empty( $domain ) ) {
			wp_send_json_error( array( 'message' => 'Por favor, ingresa un nombre de dominio válido (ej. miempresa.com).' ) );
		}

		$pat     = get_option( 'wp_static_arquitect_netlify_pat', '' );
		$site_id = get_option( 'wp_static_arquitect_netlify_site_id', '' );

		if ( empty( $pat ) || empty( $site_id ) ) {
			wp_send_json_error( array( 'message' => 'Falta configurar el Personal Access Token (PAT) o el Site ID de Netlify.' ) );
		}

		// Guardar opción
		update_option( 'wp_static_arquitect_custom_domain', $domain );

		$endpoint = 'https://api.netlify.com/api/v1/sites/' . rawurlencode( $site_id );
		$response = wp_remote_request(
			$endpoint,
			array(
				'method'  => 'PATCH',
				'timeout' => 20,
				'headers' => array(
					'Authorization' => 'Bearer ' . $pat,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( array( 'custom_domain' => $domain ) ),
			)
		);

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => 'Error de conexión HTTP: ' . $response->get_error_message() ) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 === $code ) {
			WP_Static_Arquitect::log( sprintf( 'Dominio personalizado "%s" vinculado exitosamente en Netlify.', $domain ), 'success' );
			wp_send_json_success( array( 'message' => sprintf( '¡Éxito! El dominio "%s" fue vinculado a tu sitio en Netlify.', $domain ) ) );
		} else {
			$body = wp_remote_retrieve_body( $response );
			wp_send_json_error( array( 'message' => sprintf( 'Error de Netlify (HTTP %d): %s', $code, substr( $body, 0, 200 ) ) ) );
		}
	}

	/**
	 * AJAX: Probar conexión con Supabase.
	 */
	public function ajax_test_supabase() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		if ( isset( $_POST['url'] ) && isset( $_POST['anon_key'] ) ) {
			update_option( 'wp_static_arquitect_supabase_url', esc_url_raw( wp_unslash( $_POST['url'] ) ) );
			update_option( 'wp_static_arquitect_supabase_anon_key', sanitize_text_field( wp_unslash( $_POST['anon_key'] ) ) );
		}

		$res = $this->main->supabase_comments->test_connection();
		if ( $res['success'] ) {
			wp_send_json_success( array( 'message' => $res['message'] ) );
		} else {
			wp_send_json_error( array( 'message' => $res['message'] ) );
		}
	}

	/**
	 * AJAX: Ejecutar bootstrap de la base de datos de Supabase.
	 */
	public function ajax_bootstrap_supabase() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		if ( isset( $_POST['url'] ) && isset( $_POST['anon_key'] ) ) {
			update_option( 'wp_static_arquitect_supabase_url', esc_url_raw( wp_unslash( $_POST['url'] ) ) );
			update_option( 'wp_static_arquitect_supabase_anon_key', sanitize_text_field( wp_unslash( $_POST['anon_key'] ) ) );
		}
		if ( isset( $_POST['service_key'] ) ) {
			update_option( 'wp_static_arquitect_supabase_service_key', sanitize_text_field( wp_unslash( $_POST['service_key'] ) ) );
		}

		$res = $this->main->supabase_comments->run_bootstrap();
		if ( $res['success'] ) {
			wp_send_json_success( array( 'message' => $res['message'] ) );
		} else {
			wp_send_json_error(
				array(
					'message'    => $res['message'],
					'manual_sql' => isset( $res['manual_sql'] ) ? $res['manual_sql'] : false,
					'sql_code'   => isset( $res['sql_code'] ) ? $res['sql_code'] : $this->main->supabase_comments->get_schema_sql(),
				)
			);
		}
	}

	/**
	 * AJAX: Iniciar exportación estática completa (Crawl + Parse + ZIP).
	 */
	public function ajax_start_export() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		// Aumentar límites temporales para el proceso de rastreo
		if ( ! ini_get( 'safe_mode' ) ) {
			@set_time_limit( 300 );
		}
		@ini_set( 'memory_limit', '512M' );

		$temp_dir = WP_Static_Arquitect::get_upload_dir( 'temp/export_' . time() );

		$custom_domain = isset( $_POST['custom_domain'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_domain'] ) ) : '';
		if ( ! empty( $custom_domain ) ) {
			$clean = preg_replace( '#^https?://#', '', rtrim( $custom_domain, '/' ) );
			update_option( 'wp_static_arquitect_custom_domain', 'https://' . $clean );
		}

		try {
			WP_Static_Arquitect::log( '=== Inicio de exportación estática manual ===', 'info' );

			// 1. Rastreo y extracción de recursos
			$crawl_stats = $this->main->crawler->run( $temp_dir );

			// 2. Empaquetado ZIP
			$zip_name = 'static-export-' . current_time( 'Y-m-d-His' ) . '.zip';
			$arch_res = $this->main->archiver->create_archive( $temp_dir, $zip_name );

			// 3. Limpiar directorio temporal
			$this->delete_directory( $temp_dir );

			if ( ! $arch_res['success'] ) {
				wp_send_json_error( array( 'message' => $arch_res['message'] ) );
			}

			WP_Static_Arquitect::log( '=== Proceso de exportación concluido exitosamente ===', 'success' );

			$auto_deploy   = '1' === get_option( 'wp_static_arquitect_netlify_auto_deploy', '0' );
			$deploy_result = null;

			if ( $auto_deploy ) {
				$provider = get_option( 'wp_static_arquitect_hosting_provider', 'netlify' );
				WP_Static_Arquitect::log( sprintf( 'Auto-despliegue activado. Desplegando hacia %s...', strtoupper( $provider ) ), 'info' );
				$deploy_result = $this->main->multi_deployer->deploy( $arch_res['data']['file_path'] );
			}

			wp_send_json_success(
				array(
					'message'       => '¡Exportación completada exitosamente!' . ( $auto_deploy && ! empty( $deploy_result['success'] ) ? ' Desplegado hacia ' . strtoupper( isset( $deploy_result['provider'] ) ? $deploy_result['provider'] : 'hosting' ) . '.' : '' ),
					'crawl_stats'   => $crawl_stats,
					'archive'       => $arch_res['data'],
					'deploy_result' => $deploy_result,
				)
			);
		} catch ( Exception $e ) {
			WP_Static_Arquitect::log( 'Excepción durante exportación: ' . $e->getMessage(), 'error' );
			$this->delete_directory( $temp_dir );
			wp_send_json_error( array( 'message' => 'Error: ' . $e->getMessage() ) );
		}
	}

	/**
	 * AJAX: Desplegar archivo ZIP a Netlify bajo demanda (1-Click Deploy).
	 */
	public function ajax_deploy_to_netlify() {
		return $this->ajax_deploy_to_provider();
	}

	/**
	 * AJAX: Desplegar hacia el proveedor de hosting activo (Cloudflare Pages, Netlify, GitHub, Render).
	 */
	public function ajax_deploy_to_provider() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$provider_override = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$last_export       = get_option( 'wp_static_arquitect_last_export_info', null );
		$zip_path          = ( ! empty( $last_export ) && ! empty( $last_export['file_path'] ) && file_exists( $last_export['file_path'] ) )
			? $last_export['file_path']
			: '';

		$deploy_res = $this->main->multi_deployer->deploy( $zip_path, $provider_override );

		if ( ! empty( $deploy_res['success'] ) ) {
			wp_send_json_success( $deploy_res );
		} else {
			wp_send_json_error( $deploy_res );
		}
	}

	/**
	 * AJAX: Ejecutar el análisis inteligente del sitio y obtener recomendaciones.
	 */
	public function ajax_run_site_analyzer() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$result = $this->main->site_analyzer->analyze_site();
		wp_send_json_success( $result );
	}

	/**
	 * AJAX: Establecer rápidamente el proveedor de hosting recomendado.
	 */
	public function ajax_set_hosting_provider() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$allowed  = array( 'netlify', 'cloudflare', 'github', 'render', 'vercel', 'custom' );

		if ( ! in_array( $provider, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => 'Proveedor no válido.' ) );
		}

		update_option( 'wp_static_arquitect_hosting_provider', $provider );
		WP_Static_Arquitect::log( sprintf( 'Proveedor de hosting cambiado a: %s', strtoupper( $provider ) ), 'info' );

		wp_send_json_success( array(
			'message'  => sprintf( 'Destino de hosting actualizado a %s.', strtoupper( $provider ) ),
			'provider' => $provider,
		) );
	}

	/**
	 * AJAX: Aplicar un Combo recomendado (Hosting + Proveedor de Formularios/Email).
	 */
	public function ajax_apply_combo() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$hosting = isset( $_POST['hosting'] ) ? sanitize_key( wp_unslash( $_POST['hosting'] ) ) : '';
		$form    = isset( $_POST['form_provider'] ) ? sanitize_key( wp_unslash( $_POST['form_provider'] ) ) : '';

		if ( ! empty( $hosting ) ) {
			update_option( 'wp_static_arquitect_hosting_provider', $hosting );
		}
		if ( ! empty( $form ) ) {
			update_option( 'wp_static_arquitect_form_provider', $form );
		}

		WP_Static_Arquitect::log( sprintf( 'Combo aplicado con éxito: Hosting %s + Formulario %s', strtoupper( $hosting ), strtoupper( $form ) ), 'success' );

		wp_send_json_success( array(
			'message'       => sprintf( '¡Combo aplicado! Hosting configurado a %s y Formularios a %s.', strtoupper( $hosting ), strtoupper( $form ) ),
			'hosting'       => $hosting,
			'form_provider' => $form,
		) );
	}

	/**
	 * AJAX: Probar disparo de GitHub Actions (workflow_dispatch).
	 */
	public function ajax_test_github_dispatch() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$token    = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$repo     = isset( $_POST['repo'] ) ? sanitize_text_field( wp_unslash( $_POST['repo'] ) ) : '';
		$branch   = isset( $_POST['branch'] ) ? sanitize_text_field( wp_unslash( $_POST['branch'] ) ) : 'main';
		$workflow = isset( $_POST['workflow'] ) ? sanitize_text_field( wp_unslash( $_POST['workflow'] ) ) : 'deploy.yml';

		if ( ! empty( $token ) ) {
			update_option( 'wp_static_arquitect_github_token', $token );
		}
		if ( ! empty( $repo ) ) {
			update_option( 'wp_static_arquitect_github_repo', $repo );
		}
		if ( ! empty( $branch ) ) {
			update_option( 'wp_static_arquitect_github_branch', $branch );
		}
		if ( ! empty( $workflow ) ) {
			update_option( 'wp_static_arquitect_github_workflow', $workflow );
		}

		$result = $this->main->multi_deployer->deploy_to_github( '', $token, $repo, $branch, $workflow );
		if ( ! empty( $result['success'] ) ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	/**
	 * AJAX: Ejecutar Humanizador Editorial de Fechas y Horas para Borradores (FIFO Drip-Feed).
	 */
	public function ajax_humanize_drip_posts() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$count       = isset( $_POST['count'] ) ? (int) $_POST['count'] : (int) get_option( 'wp_static_arquitect_drip_posts_count', 5 );
		$publish_now = ! isset( $_POST['publish_now'] ) || 'false' !== $_POST['publish_now'];

		$res = $this->main->humanize_drip_feed_posts( $count, null, $publish_now );
		if ( ! empty( $res['success'] ) ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Probar conexión con Pinterest API v5.
	 */
	public function ajax_test_pinterest() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$token    = isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$board_id = isset( $_POST['board_id'] ) ? sanitize_text_field( wp_unslash( $_POST['board_id'] ) ) : '';

		$res = $this->main->pinterest_publisher->test_connection( $token, $board_id );
		if ( ! empty( $res['success'] ) ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Disparar sincronización manual de pines hacia Pinterest.
	 */
	public function ajax_trigger_pinterest_sync() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$limit = isset( $_POST['limit'] ) ? (int) $_POST['limit'] : 3;
		$force = ! empty( $_POST['force'] );

		$res = $this->main->pinterest_publisher->sync_recent_posts( $limit, $force );
		if ( ! empty( $res['success'] ) ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Verificar estado de un despliegue en Netlify.
	 */
	public function ajax_check_deploy_status() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$deploy_id = isset( $_POST['deploy_id'] ) ? sanitize_text_field( wp_unslash( $_POST['deploy_id'] ) ) : '';
		if ( empty( $deploy_id ) ) {
			wp_send_json_error( array( 'message' => 'ID de despliegue no proporcionado.' ) );
		}

		$res = $this->main->netlify_forms->check_deploy_status( $deploy_id );
		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Comprobar contenido nuevo o modificado desde el último despliegue.
	 */
	public function ajax_check_new_content() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$diff = $this->main->get_content_changes_since_last_deploy();

		if ( empty( $diff['last_deploy'] ) ) {
			wp_send_json_success(
				array(
					'has_changes' => true,
					'message'     => __( 'Aún no se ha realizado ningún despliegue previo en Netlify. Todo el contenido público está listo para ser exportado.', 'wp-static-arquitect' ),
					'new_count'   => $diff['new_count'],
					'mod_count'   => $diff['modified_count'],
				)
			);
		}

		if ( $diff['has_changes'] ) {
			$msg = sprintf(
				/* translators: 1: new posts count, 2: modified posts count, 3: last deploy date */
				__( '¡Cambios detectados! %1$d entrada(s) nueva(s) y %2$d modificada(s) desde el último despliegue (%3$s). El lote diario las publicará automáticamente.', 'wp-static-arquitect' ),
				$diff['new_count'],
				$diff['modified_count'],
				$diff['last_deploy']
			);
			wp_send_json_success(
				array(
					'has_changes' => true,
					'message'     => $msg,
					'new_count'   => $diff['new_count'],
					'mod_count'   => $diff['modified_count'],
				)
			);
		} else {
			$msg = sprintf(
				/* translators: %s: last deploy date */
				__( 'El sitio estático está 100%% al día con Netlify. No se han detectado entradas nuevas ni modificadas desde el último despliegue (%s).', 'wp-static-arquitect' ),
				$diff['last_deploy']
			);
			wp_send_json_success(
				array(
					'has_changes' => false,
					'message'     => $msg,
					'new_count'   => 0,
					'mod_count'   => 0,
				)
			);
		}
	}

	/**
	 * AJAX: Purgar formularios de Netlify manualmente.
	 */
	public function ajax_purge_netlify() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$res = $this->main->netlify_forms->purge_submissions( true );
		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Obtener registros de actividad recientes.
	 */
	public function ajax_get_logs() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		wp_send_json_success(
			array(
				'logs' => WP_Static_Arquitect::get_recent_logs(),
			)
		);
	}

	/**
	 * AJAX: Limpiar logs.
	 */
	public function ajax_clear_logs() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		WP_Static_Arquitect::clear_logs();
		wp_send_json_success( array( 'message' => 'Logs limpiados con éxito.' ) );
	}

	/**
	 * AJAX: Cargar comentarios de Supabase para la bandeja de moderación.
	 */
	public function ajax_load_admin_comments() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$status = isset( $_POST['status'] ) ? sanitize_text_field( wp_unslash( $_POST['status'] ) ) : 'all';
		$res    = $this->main->supabase_comments->get_admin_comments( $status );

		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Aprobar o desaprobar un comentario de Supabase.
	 */
	public function ajax_moderate_comment() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$comment_id  = isset( $_POST['comment_id'] ) ? sanitize_text_field( wp_unslash( $_POST['comment_id'] ) ) : '';
		$is_approved = isset( $_POST['is_approved'] ) && '1' === $_POST['is_approved'];

		if ( empty( $comment_id ) ) {
			wp_send_json_error( array( 'message' => 'ID de comentario no especificado.' ) );
		}

		$res = $this->main->supabase_comments->update_comment_status( $comment_id, $is_approved );
		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Eliminar un comentario de Supabase.
	 */
	public function ajax_delete_comment() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$comment_id = isset( $_POST['comment_id'] ) ? sanitize_text_field( wp_unslash( $_POST['comment_id'] ) ) : '';
		if ( empty( $comment_id ) ) {
			wp_send_json_error( array( 'message' => 'ID de comentario no especificado.' ) );
		}

		$res = $this->main->supabase_comments->delete_comment( $comment_id );
		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Iniciar sesión de exportación por lotes.
	 */
	public function ajax_batch_init() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$custom_domain = isset( $_POST['custom_domain'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_domain'] ) ) : '';
		$save_perm     = ! empty( $_POST['save_perm'] );

		if ( ! empty( $custom_domain ) ) {
			$clean = preg_replace( '#^https?://#', '', rtrim( $custom_domain, '/' ) );
			update_option( 'wp_static_arquitect_custom_domain', 'https://' . $clean );
		} elseif ( isset( $_POST['custom_domain'] ) && '' === $custom_domain && $save_perm ) {
			delete_option( 'wp_static_arquitect_custom_domain' );
		}

		$res = $this->main->crawler->init_batch_session();
		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Procesar un bloque (chunk) de URLs en la sesión activa.
	 */
	public function ajax_batch_step() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$session_id = isset( $_POST['session_id'] ) ? sanitize_text_field( wp_unslash( $_POST['session_id'] ) ) : '';
		$batch_size = isset( $_POST['batch_size'] ) ? (int) $_POST['batch_size'] : 3;

		if ( empty( $session_id ) ) {
			wp_send_json_error( array( 'message' => 'ID de sesión no proporcionado.' ) );
		}

		$res = $this->main->crawler->process_batch_step( $session_id, $batch_size );
		if ( $res['success'] ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Finalizar la sesión por lotes (fases: prepare, compress, o all).
	 */
	public function ajax_batch_finalize() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$session_id = isset( $_POST['session_id'] ) ? sanitize_text_field( wp_unslash( $_POST['session_id'] ) ) : '';
		if ( empty( $session_id ) ) {
			wp_send_json_error( array( 'message' => 'ID de sesión no proporcionado.' ) );
		}

		$phase = isset( $_POST['phase'] ) ? sanitize_text_field( wp_unslash( $_POST['phase'] ) ) : 'all';

		$res = $this->main->crawler->finalize_batch_session( $session_id, $phase );
		if ( ! empty( $res['success'] ) ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Comprobar el estado en tiempo real de una sesión de exportación / compresión.
	 */
	public function ajax_batch_status() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$session_id = isset( $_POST['session_id'] ) ? sanitize_text_field( wp_unslash( $_POST['session_id'] ) ) : '';
		if ( empty( $session_id ) ) {
			wp_send_json_error( array( 'message' => 'ID de sesión no proporcionado.' ) );
		}

		$session_data = $this->main->crawler->get_session_data( $session_id );

		// 1. Si la sesión ya se encuentra completada
		if ( $session_data && ! empty( $session_data['status'] ) && 'completed' === $session_data['status'] && ! empty( $session_data['archive'] ) ) {
			wp_send_json_success( array(
				'is_complete'   => true,
				'archive'       => $session_data['archive'],
				'deploy_result' => isset( $session_data['deploy'] ) ? $session_data['deploy'] : null,
			) );
		}

		wp_send_json_success( array(
			'is_complete' => false,
			'status'      => $session_data ? ( isset( $session_data['status'] ) ? $session_data['status'] : 'processing' ) : 'unknown',
		) );
	}

	/**
	 * AJAX: Ejecutar análisis semántico y editorial con Google AI Studio (Gemini).
	 */
	public function ajax_analyze_with_gemini() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}
		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';
		if ( ! empty( $api_key ) ) {
			update_option( 'wp_static_arquitect_gemini_api_key', $api_key );
		}
		$result = $this->main->site_analyzer->analyze_with_gemini( $api_key );
		if ( ! empty( $result['success'] ) ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}


	/**
	 * AJAX: Descubre nuevos temas inéditos mediante motores de búsqueda e IA.
	 */
	public function ajax_ai_discover_topics() {
		check_ajax_referer( 'wp_static_arquitect_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$category = isset( $_POST['category'] ) ? sanitize_key( $_POST['category'] ) : 'astrofisica';
		$count    = isset( $_POST['count'] ) ? (int) $_POST['count'] : 6;

		$generator = $this->main->get_ai_article_generator();
		if ( ! $generator ) {
			wp_send_json_error( array( 'message' => 'El generador de artículos con IA no está inicializado.' ) );
		}

		$res = $generator->discover_topics( $category, $count );
		if ( ! empty( $res['success'] ) ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Redacta y publica un artículo completo como borrador en WordPress (SEO & GEO).
	 */
	public function ajax_ai_generate_article() {
		check_ajax_referer( 'wp_static_arquitect_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$topic    = isset( $_POST['topic'] ) ? sanitize_text_field( wp_unslash( $_POST['topic'] ) ) : '';
		$category = isset( $_POST['category'] ) ? sanitize_key( $_POST['category'] ) : 'astrofisica';
		$keyword  = isset( $_POST['keyword'] ) ? sanitize_text_field( wp_unslash( $_POST['keyword'] ) ) : '';

		if ( empty( $topic ) ) {
			wp_send_json_error( array( 'message' => 'Debes ingresar un tema o premisa para el artículo.' ) );
		}

		$generator = $this->main->get_ai_article_generator();
		if ( ! $generator ) {
			wp_send_json_error( array( 'message' => 'El generador de artículos con IA no está inicializado.' ) );
		}

		$res = $generator->generate_article( $topic, $category, $keyword );
		if ( ! empty( $res['success'] ) ) {
			wp_send_json_success( $res );
		} else {
			wp_send_json_error( $res );
		}
	}

	/**
	 * AJAX: Eliminar el paquete estático ZIP anterior y resetear el estado del panel.
	 */
	public function ajax_delete_export() {
		check_ajax_referer( 'wpsa_admin_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permiso denegado.' ) );
		}

		$last_export = get_option( 'wp_static_arquitect_last_export_info', null );
		if ( ! empty( $last_export ) && ! empty( $last_export['file_path'] ) && file_exists( $last_export['file_path'] ) ) {
			@unlink( $last_export['file_path'] );
		}

		// Limpiar todos los archivos ZIP residuales en uploads/wp-static-arquitect/exports
		$exports_dir = WP_Static_Arquitect::get_upload_dir( 'exports' );
		if ( is_dir( $exports_dir ) ) {
			$files = glob( trailingslashit( $exports_dir ) . '*.zip' );
			if ( is_array( $files ) ) {
				foreach ( $files as $file ) {
					if ( is_file( $file ) ) {
						@unlink( $file );
					}
				}
			}
		}

		delete_option( 'wp_static_arquitect_last_export_info' );
		delete_option( 'wp_static_arquitect_last_deploy_info' );

		WP_Static_Arquitect::log( 'Paquete estático anterior eliminado y descartado por el usuario.', 'info' );

		wp_send_json_success( array(
			'message' => 'Paquete anterior eliminado correctamente. Puedes generar tu exportación completa cuando desees.',
		) );
	}

	/**
	 * Elimina recursivamente un directorio.
	 *
	 * @param string $dir
	 */
	private function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}
		$files = array_diff( scandir( $dir ), array( '.', '..' ) );
		foreach ( $files as $file ) {
			$path = $dir . DIRECTORY_SEPARATOR . $file;
			is_dir( $path ) ? $this->delete_directory( $path ) : @unlink( $path );
		}
		@rmdir( $dir );
	}
}
